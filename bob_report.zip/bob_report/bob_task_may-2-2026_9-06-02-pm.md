**User:**

<task>
'frontend/src/page/invoice/index.tsx' (see below for file content) remove the mock data and implement the real data from the routes
</task>

<file_content path="frontend/src/page/invoice/index.tsx">
  1 | import { useState, useEffect } from 'react';
  2 | import { Eye, FileText, Calendar, User, Mail, Phone, DollarSign, FileCheck } from 'lucide-react';
  3 | import { Card, CardContent } from '@/components/ui/card';
  4 | import { Button } from '@/components/ui/button';
  5 | import { Badge } from '@/components/ui/badge';
  6 | import {
  7 |     Dialog,
  8 |     DialogContent,
  9 |     DialogHeader,
 10 |     DialogTitle,
 11 |     DialogDescription,
 12 | } from '@/components/ui/dialog';
 13 | import { getPaginatedInvoices, getInvoiceById as getMockInvoiceById } from '@/data/mockInvoices';
 14 | 
 15 | interface Invoice {
 16 |     id: string;
 17 |     invoice_number: string;
 18 |     invoice_date: string;
 19 |     customer_name: string;
 20 |     customer_email?: string;
 21 |     customer_phone?: string;
 22 |     total_amount: number;
 23 |     payment_status: string;
 24 |     status: string;
 25 |     notes?: string;
 26 |     created_at?: string;
 27 |     updated_at?: string;
 28 | }
 29 | 
 30 | const Invoice = () => {
 31 |     const [invoices, setInvoices] = useState<Invoice[]>([]);
 32 |     const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
 33 |     const [isDialogOpen, setIsDialogOpen] = useState(false);
 34 |     const [loading, setLoading] = useState(true);
 35 |     const [page, setPage] = useState(1);
 36 |     const [totalPages, setTotalPages] = useState(1);
 37 | 
 38 |     // Fetch invoices
 39 |     useEffect(() => {
 40 |         fetchInvoices();
 41 |     }, [page]);
 42 | 
 43 |     const fetchInvoices = async () => {
 44 |         try {
 45 |             setLoading(true);
 46 |             // Using mock data instead of API call
 47 |             const response = getPaginatedInvoices(page, 10);
 48 |             setInvoices(response.data || []);
 49 |             setTotalPages(response.pagination?.totalPages || 1);
 50 |         } catch (error) {
 51 |             console.error('Error fetching invoices:', error);
 52 |         } finally {
 53 |             setLoading(false);
 54 |         }
 55 |     };
 56 | 
 57 |     // View invoice details
 58 |     const handleViewInvoice = async (invoiceId: string) => {
 59 |         try {
 60 |             // Using mock data instead of API call
 61 |             const invoice = getMockInvoiceById(invoiceId);
 62 |             if (invoice) {
 63 |                 setSelectedInvoice(invoice);
 64 |                 setIsDialogOpen(true);
 65 |             }
 66 |         } catch (error) {
 67 |             console.error('Error fetching invoice details:', error);
 68 |         }
 69 |     };
 70 | 
 71 |     // Get payment status badge variant
 72 |     const getPaymentStatusVariant = (status: string) => {
 73 |         switch (status?.toLowerCase()) {
 74 |             case 'paid':
 75 |                 return 'default';
 76 |             case 'pending':
 77 |                 return 'secondary';
 78 |             case 'overdue':
 79 |                 return 'destructive';
 80 |             default:
 81 |                 return 'outline';
 82 |         }
 83 |     };
 84 | 
 85 |     // Get status badge variant
 86 |     const getStatusVariant = (status: string) => {
 87 |         switch (status?.toLowerCase()) {
 88 |             case 'active':
 89 |                 return 'default';
 90 |             case 'draft':
 91 |                 return 'secondary';
 92 |             case 'cancelled':
 93 |                 return 'destructive';
 94 |             default:
 95 |                 return 'outline';
 96 |         }
 97 |     };
 98 | 
 99 |     // Format date
100 |     const formatDate = (dateString: string) => {
101 |         if (!dateString) return 'N/A';
102 |         return new Date(dateString).toLocaleDateString('en-US', {
103 |             year: 'numeric',
104 |             month: 'short',
105 |             day: 'numeric',
106 |         });
107 |     };
108 | 
109 |     // Format currency
110 |     const formatCurrency = (amount: number) => {
111 |         return new Intl.NumberFormat('en-US', {
112 |             style: 'currency',
113 |             currency: 'USD',
114 |         }).format(amount);
115 |     };
116 | 
117 |     return (
118 |         <div className="mx-auto py-8 px-4 max-w-7xl">
119 |             <div className="mb-6">
120 |                 <h1 className="text-3xl font-bold">Invoices</h1>
121 |                 <p className="text-muted-foreground mt-1">
122 |                     View and manage your invoices
123 |                 </p>
124 |             </div>
125 | 
126 |             {loading ? (
127 |                 <Card>
128 |                     <CardContent className="py-12 text-center">
129 |                         <p className="text-muted-foreground">Loading invoices...</p>
130 |                     </CardContent>
131 |                 </Card>
132 |             ) : invoices.length === 0 ? (
133 |                 <Card>
134 |                     <CardContent className="py-12 text-center">
135 |                         <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
136 |                         <h3 className="text-lg font-semibold mb-2">No invoices found</h3>
137 |                         <p className="text-muted-foreground">
138 |                             You don't have any invoices yet
139 |                         </p>
140 |                     </CardContent>
141 |                 </Card>
142 |             ) : (
143 |                 <>
144 |                     {/* Invoice Table */}
145 |                     <Card>
146 |                         <CardContent className="p-0">
147 |                             <div className="overflow-x-auto">
148 |                                 <table className="w-full">
149 |                                     <thead className="bg-muted/50 border-b">
150 |                                         <tr>
151 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
152 |                                                 Invoice #
153 |                                             </th>
154 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
155 |                                                 Customer
156 |                                             </th>
157 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
158 |                                                 Date
159 |                                             </th>
160 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
161 |                                                 Amount
162 |                                             </th>
163 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
164 |                                                 Payment Status
165 |                                             </th>
166 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
167 |                                                 Status
168 |                                             </th>
169 |                                             <th className="px-6 py-4 text-center text-sm font-semibold">
170 |                                                 Actions
171 |                                             </th>
172 |                                         </tr>
173 |                                     </thead>
174 |                                     <tbody className="divide-y">
175 |                                         {invoices.map((invoice) => (
176 |                                             <tr
177 |                                                 key={invoice.id}
178 |                                                 className="hover:bg-muted/30 transition-colors"
179 |                                             >
180 |                                                 <td className="px-6 py-4">
181 |                                                     <span className="font-medium">
182 |                                                         {invoice.invoice_number}
183 |                                                     </span>
184 |                                                 </td>
185 |                                                 <td className="px-6 py-4">
186 |                                                     <div>
187 |                                                         <p className="font-medium">
188 |                                                             {invoice.customer_name}
189 |                                                         </p>
190 |                                                         {invoice.customer_email && (
191 |                                                             <p className="text-sm text-muted-foreground">
192 |                                                                 {invoice.customer_email}
193 |                                                             </p>
194 |                                                         )}
195 |                                                     </div>
196 |                                                 </td>
197 |                                                 <td className="px-6 py-4 text-sm">
198 |                                                     {formatDate(invoice.invoice_date)}
199 |                                                 </td>
200 |                                                 <td className="px-6 py-4 font-semibold">
201 |                                                     {formatCurrency(invoice.total_amount)}
202 |                                                 </td>
203 |                                                 <td className="px-6 py-4">
204 |                                                     <Badge
205 |                                                         variant={getPaymentStatusVariant(
206 |                                                             invoice.payment_status
207 |                                                         )}
208 |                                                     >
209 |                                                         {invoice.payment_status}
210 |                                                     </Badge>
211 |                                                 </td>
212 |                                                 <td className="px-6 py-4">
213 |                                                     <Badge
214 |                                                         variant={getStatusVariant(invoice.status)}
215 |                                                     >
216 |                                                         {invoice.status}
217 |                                                     </Badge>
218 |                                                 </td>
219 |                                                 <td className="px-6 py-4 text-center">
220 |                                                     <Button
221 |                                                         variant="ghost"
222 |                                                         size="sm"
223 |                                                         onClick={() => handleViewInvoice(invoice.id)}
224 |                                                     >
225 |                                                         <Eye className="h-4 w-4 mr-2" />
226 |                                                         View
227 |                                                     </Button>
228 |                                                 </td>
229 |                                             </tr>
230 |                                         ))}
231 |                                     </tbody>
232 |                                 </table>
233 |                             </div>
234 |                         </CardContent>
235 |                     </Card>
236 | 
237 |                     {/* Pagination */}
238 |                     {totalPages > 1 && (
239 |                         <div className="mt-6 flex justify-center gap-2">
240 |                             <Button
241 |                                 variant="outline"
242 |                                 onClick={() => setPage((p) => Math.max(1, p - 1))}
243 |                                 disabled={page === 1}
244 |                             >
245 |                                 Previous
246 |                             </Button>
247 |                             <div className="flex items-center px-4">
248 |                                 <span className="text-sm text-muted-foreground">
249 |                                     Page {page} of {totalPages}
250 |                                 </span>
251 |                             </div>
252 |                             <Button
253 |                                 variant="outline"
254 |                                 onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
255 |                                 disabled={page === totalPages}
256 |                             >
257 |                                 Next
258 |                             </Button>
259 |                         </div>
260 |                     )}
261 |                 </>
262 |             )}
263 | 
264 |             {/* View Invoice Dialog */}
265 |             <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
266 |                 <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
267 |                     <DialogHeader>
268 |                         <DialogTitle className="flex items-center gap-2">
269 |                             <FileCheck className="h-5 w-5" />
270 |                             Invoice Details
271 |                         </DialogTitle>
272 |                         <DialogDescription>
273 |                             Complete information about this invoice
274 |                         </DialogDescription>
275 |                     </DialogHeader>
276 | 
277 |                     {selectedInvoice && (
278 |                         <div className="space-y-6 mt-4">
279 |                             {/* Invoice Header */}
280 |                             <div className="flex justify-between items-start pb-4 border-b">
281 |                                 <div>
282 |                                     <h3 className="text-2xl font-bold">
283 |                                         {selectedInvoice.invoice_number}
284 |                                     </h3>
285 |                                     <p className="text-sm text-muted-foreground mt-1">
286 |                                         Invoice Date: {formatDate(selectedInvoice.invoice_date)}
287 |                                     </p>
288 |                                 </div>
289 |                                 <div className="text-right">
290 |                                     <p className="text-sm text-muted-foreground mb-2">
291 |                                         Total Amount
292 |                                     </p>
293 |                                     <p className="text-2xl font-bold">
294 |                                         {formatCurrency(selectedInvoice.total_amount)}
295 |                                     </p>
296 |                                 </div>
297 |                             </div>
298 | 
299 |                             {/* Status Badges */}
300 |                             <div className="flex gap-3">
301 |                                 <div>
302 |                                     <p className="text-sm text-muted-foreground mb-2">
303 |                                         Payment Status
304 |                                     </p>
305 |                                     <Badge
306 |                                         variant={getPaymentStatusVariant(
307 |                                             selectedInvoice.payment_status
308 |                                         )}
309 |                                         className="text-sm px-3 py-1"
310 |                                     >
311 |                                         {selectedInvoice.payment_status}
312 |                                     </Badge>
313 |                                 </div>
314 |                                 <div>
315 |                                     <p className="text-sm text-muted-foreground mb-2">
316 |                                         Invoice Status
317 |                                     </p>
318 |                                     <Badge
319 |                                         variant={getStatusVariant(selectedInvoice.status)}
320 |                                         className="text-sm px-3 py-1"
321 |                                     >
322 |                                         {selectedInvoice.status}
323 |                                     </Badge>
324 |                                 </div>
325 |                             </div>
326 | 
327 |                             {/* Customer Information */}
328 |                             <div>
329 |                                 <h4 className="font-semibold mb-3 flex items-center gap-2">
330 |                                     <User className="h-4 w-4" />
331 |                                     Customer Information
332 |                                 </h4>
333 |                                 <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
334 |                                     <div className="flex items-start gap-3">
335 |                                         <User className="h-5 w-5 text-muted-foreground mt-0.5" />
336 |                                         <div>
337 |                                             <p className="text-sm font-medium text-muted-foreground">
338 |                                                 Name
339 |                                             </p>
340 |                                             <p className="text-base">
341 |                                                 {selectedInvoice.customer_name}
342 |                                             </p>
343 |                                         </div>
344 |                                     </div>
345 | 
346 |                                     {selectedInvoice.customer_email && (
347 |                                         <div className="flex items-start gap-3">
348 |                                             <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
349 |                                             <div>
350 |                                                 <p className="text-sm font-medium text-muted-foreground">
351 |                                                     Email
352 |                                                 </p>
353 |                                                 <p className="text-base">
354 |                                                     {selectedInvoice.customer_email}
355 |                                                 </p>
356 |                                             </div>
357 |                                         </div>
358 |                                     )}
359 | 
360 |                                     {selectedInvoice.customer_phone && (
361 |                                         <div className="flex items-start gap-3">
362 |                                             <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
363 |                                             <div>
364 |                                                 <p className="text-sm font-medium text-muted-foreground">
365 |                                                     Phone
366 |                                                 </p>
367 |                                                 <p className="text-base">
368 |                                                     {selectedInvoice.customer_phone}
369 |                                                 </p>
370 |                                             </div>
371 |                                         </div>
372 |                                     )}
373 |                                 </div>
374 |                             </div>
375 | 
376 |                             {/* Additional Details */}
377 |                             <div>
378 |                                 <h4 className="font-semibold mb-3 flex items-center gap-2">
379 |                                     <FileText className="h-4 w-4" />
380 |                                     Additional Details
381 |                                 </h4>
382 |                                 <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
383 |                                     <div className="flex items-start gap-3">
384 |                                         <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
385 |                                         <div>
386 |                                             <p className="text-sm font-medium text-muted-foreground">
387 |                                                 Invoice Date
388 |                                             </p>
389 |                                             <p className="text-base">
390 |                                                 {formatDate(selectedInvoice.invoice_date)}
391 |                                             </p>
392 |                                         </div>
393 |                                     </div>
394 | 
395 |                                     <div className="flex items-start gap-3">
396 |                                         <DollarSign className="h-5 w-5 text-muted-foreground mt-0.5" />
397 |                                         <div>
398 |                                             <p className="text-sm font-medium text-muted-foreground">
399 |                                                 Total Amount
400 |                                             </p>
401 |                                             <p className="text-base font-semibold">
402 |                                                 {formatCurrency(selectedInvoice.total_amount)}
403 |                                             </p>
404 |                                         </div>
405 |                                     </div>
406 | 
407 |                                     {selectedInvoice.notes && (
408 |                                         <div className="flex items-start gap-3">
409 |                                             <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
410 |                                             <div>
411 |                                                 <p className="text-sm font-medium text-muted-foreground">
412 |                                                     Notes
413 |                                                 </p>
414 |                                                 <p className="text-base">{selectedInvoice.notes}</p>
415 |                                             </div>
416 |                                         </div>
417 |                                     )}
418 |                                 </div>
419 |                             </div>
420 | 
421 |                             {/* Timestamps */}
422 |                             {(selectedInvoice.created_at || selectedInvoice.updated_at) && (
423 |                                 <div className="pt-4 border-t text-sm text-muted-foreground">
424 |                                     {selectedInvoice.created_at && (
425 |                                         <p>
426 |                                             Created: {formatDate(selectedInvoice.created_at)}
427 |                                         </p>
428 |                                     )}
429 |                                     {selectedInvoice.updated_at && (
430 |                                         <p>
431 |                                             Last Updated: {formatDate(selectedInvoice.updated_at)}
432 |                                         </p>
433 |                                     )}
434 |                                 </div>
435 |                             )}
436 |                         </div>
437 |                     )}
438 |                 </DialogContent>
439 |             </Dialog>
440 |         </div>
441 |     );
442 | };
443 | 
444 | export default Invoice;
445 | 
446 | // Made with Bob

</file_content>
<environment_details>
# VSCode Visible Files
frontend/src/page/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx,frontend/src/page/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:35:40.992Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.00

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
backend/.editorconfig
backend/.env.example
backend/.gitattributes
backend/.gitignore
backend/.prettierignore
backend/.prettierrc.json
backend/.yarnrc.yml
backend/eslint.config.js
backend/package.json
backend/README.md
backend/tsconfig.json
backend/yarn.lock
backend/.yarn/
backend/src/
backend/src/index.ts
backend/src/config/
backend/src/config/db.ts
backend/src/config/env.ts
backend/src/controller/
backend/src/controller/auth/
backend/src/controller/auth/index.ts
backend/src/controller/billing_detail/
backend/src/controller/billing_detail/index.ts
backend/src/controller/invoice/
backend/src/controller/invoice/index.ts
backend/src/controller/payment_methods/
backend/src/controller/payment_methods/index.ts
backend/src/controller/transaction/
backend/src/controller/transaction/index.ts
backend/src/controller/user/
backend/src/controller/user/index.ts
backend/src/middleware/
backend/src/middleware/auth.ts
backend/src/middleware/error.ts
backend/src/middleware/permission.ts
backend/src/models/
backend/src/models/billing_detail.ts
backend/src/models/index.ts
backend/src/models/invoice.ts
backend/src/models/otp.ts
backend/src/models/payment_method.ts
backend/src/models/transaction.ts
backend/src/models/user.ts
backend/src/routes/
backend/src/routes/index.ts
backend/src/routes/auth/
backend/src/routes/auth/index.ts
backend/src/routes/billing_details/
backend/src/routes/billing_details/index.ts
backend/src/routes/invoice/
backend/src/routes/invoice/index.ts
backend/src/routes/payment_methods/
backend/src/routes/payment_methods/index.ts
backend/src/routes/transaction/
backend/src/routes/transaction/index.ts
backend/src/routes/user/
backend/src/routes/user/index.ts
backend/src/services/
backend/src/services/smtp.ts
backend/src/utils/
backend/src/utils/bcrypt.ts
backend/src/utils/error.ts
backend/src/utils/generate-otp.ts
backend/src/utils/jwt.ts
backend/src/utils/logger.ts
backend/src/utils/reminder.ts
backend/src/views/
backend/src/views/auth/
backend/src/views/auth/forgot-password.ejs
backend/src/views/auth/login.ejs
backend/src/views/auth/signup.ejs
backend/src/views/invoice/
backend/src/views/invoice/invoice.ejs
backend/src/views/reminder/
backend/src/views/reminder/reminder.ejs
frontend/
frontend/.env.example
frontend/.gitignore
frontend/.prettierignore
frontend/.prettierrc.json
frontend/.yarnrc.yml
frontend/components.json
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/postcss.config.js
frontend/README.md
frontend/tailwind.config.js
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
frontend/src/components/
frontend/src/components/custom/
frontend/src/components/custom/navbar/
frontend/src/components/custom/navbar/index.tsx
frontend/src/components/custom/page-loader/
frontend/src/components/custom/page-loader/index.tsx
frontend/src/components/custom/sidebar/
frontend/src/components/custom/sidebar/index.tsx
frontend/src/components/ui/
frontend/src/components/ui/accordion.tsx
frontend/src/components/ui/alert.tsx
frontend/src/components/ui/badge.tsx
frontend/src/components/ui/button.tsx
frontend/src/components/ui/card.tsx
frontend/src/components/ui/checkbox.tsx
frontend/src/components/ui/dialog.tsx
frontend/src/components/ui/dropdown-menu.tsx
frontend/src/components/ui/form.tsx
frontend/src/components/ui/index.ts
frontend/src/components/ui/input.tsx
frontend/src/components/ui/label.tsx
frontend/src/components/ui/radio-group.tsx
frontend/src/components/ui/select.tsx
frontend/src/components/ui/switch.tsx
frontend/src/components/ui/tabs.tsx
frontend/src/components/ui/textarea.tsx
frontend/src/components/ui/tooltip.tsx
frontend/src/data/
frontend/src/data/mockInvoices.ts
frontend/src/lib/
frontend/src/lib/utils.ts
frontend/src/page/
frontend/src/page/layout.tsx
frontend/src/page/admin/
frontend/src/page/admin/invoice/
frontend/src/page/admin/invoice/index.tsx
frontend/src/page/admin/manage_employee/
frontend/src/page/admin/manage_employee/index.tsx
frontend/src/page/admin/payment_method/
frontend/src/page/admin/payment_method/index.tsx
frontend/src/page/admin/transcation/
frontend/src/page/admin/transcation/index.tsx
frontend/src/page/auth/
frontend/src/page/auth/forgot-password/
frontend/src/page/auth/forgot-password/index.tsx
frontend/src/page/auth/login/
frontend/src/page/auth/login/index.tsx
frontend/src/page/auth/signup/
frontend/src/page/auth/signup/index.tsx
frontend/src/page/billing_detail/
frontend/src/page/billing_detail/index.tsx
frontend/src/page/billing_detail/new/
frontend/src/page/billing_detail/new/index.tsx
frontend/src/page/home/
frontend/src/page/home/index.tsx
frontend/src/page/invoice/
frontend/src/page/invoice/index.tsx
frontend/src/page/payment_method/
frontend/src/page/payment_method/index.tsx
frontend/src/page/payment_method/new/
frontend/src/page/payment_method/new/index.tsx
frontend/src/page/profile/
frontend/src/page/profile/index.tsx
frontend/src/page/transaction/
frontend/src/page/transaction/index.tsx
frontend/src/service/
frontend/src/service/api.ts
frontend/src/service/auth/
frontend/src/service/auth/index.ts
frontend/src/service/auth/interface.ts
frontend/src/service/billing_details/
frontend/src/service/billing_details/index.ts
frontend/src/service/billing_details/interface.ts
frontend/src/service/invoice/
frontend/src/service/invoice/index.ts
frontend/src/service/invoice/interface.ts
frontend/src/service/payment_methods/
frontend/src/service/payment_methods/index.ts
frontend/src/service/payment_methods/interface.ts
frontend/src/service/transaction/
frontend/src/service/transaction/index.ts
frontend/src/service/transaction/interface.ts
frontend/src/service/user/
frontend/src/service/user/index.ts
frontend/src/service/user/interface.ts
frontend/src/store/
frontend/src/store/index.ts
frontend/src/store/auth/
frontend/src/store/auth/index.ts
frontend/src/store/nav-toggle/index.ts
frontend/src/utils/AutoRedirect.tsx
frontend/src/utils/PermissionRoute.tsx
frontend/src/utils/ProtectedRoute.tsx

(File list truncated. Use list_files on specific subdirectories if you need to explore further.)
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I'll help you replace the mock data with real API calls in the invoice page. Let me first examine the related files to understand the API structure.

<read_file>
<args>
<file>
<path>frontend/src/service/invoice/index.ts</path>
</file>
<file>
<path>frontend/src/service/invoice/interface.ts</path>
</file>
<file>
<path>frontend/src/data/mockInvoices.ts</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 'frontend/src/service/invoice/index.ts', 'frontend/src/service/invoice/interface.ts', 'frontend/src/data/mockInvoices.ts'] Result:
<files>
<file><path>frontend/src/service/invoice/index.ts</path>
<content lines="1-84">
 1 | import api from "../api";
 2 | import type {
 3 |     ICreateInvoice,
 4 |     IAdminCreateInvoice,
 5 |     IUpdateInvoice,
 6 |     IGetAllInvoicesQuery,
 7 |     IGetUserInvoicesQuery
 8 | } from "./interface";
 9 | 
10 | // Admin: Get all invoices with pagination
11 | const getAllInvoices = async (query?: IGetAllInvoicesQuery) => {
12 |     const params = new URLSearchParams();
13 |     if (query?.page) params.append('page', query.page.toString());
14 |     if (query?.limit) params.append('limit', query.limit.toString());
15 |     
16 |     const response = await api.get(`/invoice/admin?${params.toString()}`);
17 |     return response.data;
18 | }
19 | 
20 | // User: Get user's invoices with pagination
21 | const getUserInvoices = async (query?: IGetUserInvoicesQuery) => {
22 |     const params = new URLSearchParams();
23 |     if (query?.page) params.append('page', query.page.toString());
24 |     if (query?.limit) params.append('limit', query.limit.toString());
25 |     
26 |     const response = await api.get(`/invoice?${params.toString()}`);
27 |     return response.data;
28 | }
29 | 
30 | // User: Get invoice by ID
31 | const getInvoiceById = async (id: string) => {
32 |     const response = await api.get(`/invoice/${id}`);
33 |     return response.data;
34 | }
35 | 
36 | // User: Create invoice
37 | const createInvoice = async (payload: ICreateInvoice) => {
38 |     const response = await api.post(`/invoice`, payload);
39 |     return response.data;
40 | }
41 | 
42 | // Admin: Create invoice for any user
43 | const adminCreateInvoice = async (payload: IAdminCreateInvoice) => {
44 |     const response = await api.post(`/invoice/admin`, payload);
45 |     return response.data;
46 | }
47 | 
48 | // User: Update invoice
49 | const updateInvoice = async (id: string, payload: IUpdateInvoice) => {
50 |     const response = await api.put(`/invoice/${id}`, payload);
51 |     return response.data;
52 | }
53 | 
54 | // User: Delete invoice
55 | const deleteInvoice = async (id: string) => {
56 |     const response = await api.delete(`/invoice/${id}`);
57 |     return response.data;
58 | }
59 | 
60 | // Admin: Update any invoice
61 | const adminUpdateInvoice = async (id: string, payload: IUpdateInvoice) => {
62 |     const response = await api.put(`/invoice/admin/${id}`, payload);
63 |     return response.data;
64 | }
65 | 
66 | // Admin: Delete any invoice
67 | const adminDeleteInvoice = async (id: string) => {
68 |     const response = await api.delete(`/invoice/admin/${id}`);
69 |     return response.data;
70 | }
71 | 
72 | export {
73 |     getAllInvoices,
74 |     getUserInvoices,
75 |     getInvoiceById,
76 |     createInvoice,
77 |     adminCreateInvoice,
78 |     updateInvoice,
79 |     deleteInvoice,
80 |     adminUpdateInvoice,
81 |     adminDeleteInvoice
82 | }
83 | 
84 | // Made with Bob
</content>
</file>
<file><path>frontend/src/service/invoice/interface.ts</path>
<content lines="1-39">
 1 | export interface ICreateInvoice {
 2 |     invoice_number: string;
 3 |     invoice_date?: string;
 4 |     customer_name: string;
 5 |     customer_email?: string;
 6 |     customer_phone?: string;
 7 |     total_amount: number;
 8 |     payment_status?: string;
 9 |     notes?: string;
10 |     status?: string;
11 | }
12 | 
13 | export interface IAdminCreateInvoice extends ICreateInvoice {
14 |     userId: string;
15 | }
16 | 
17 | export interface IUpdateInvoice {
18 |     invoice_number?: string;
19 |     invoice_date?: string;
20 |     customer_name?: string;
21 |     customer_email?: string;
22 |     customer_phone?: string;
23 |     total_amount?: number;
24 |     payment_status?: string;
25 |     notes?: string;
26 |     status?: string;
27 | }
28 | 
29 | export interface IGetAllInvoicesQuery {
30 |     page?: number;
31 |     limit?: number;
32 | }
33 | 
34 | export interface IGetUserInvoicesQuery {
35 |     page?: number;
36 |     limit?: number;
37 | }
38 | 
39 | // Made with Bob
</content>
</file>
<file><path>frontend/src/data/mockInvoices.ts</path>
<content lines="1-398">
  1 | // Mock Invoice Data for Testing and Development
  2 | // This file contains sample invoice data with various statuses and scenarios
  3 | 
  4 | export interface MockInvoice {
  5 |     id: string;
  6 |     invoice_number: string;
  7 |     invoice_date: string;
  8 |     customer_name: string;
  9 |     customer_email?: string;
 10 |     customer_phone?: string;
 11 |     total_amount: number;
 12 |     payment_status: 'pending' | 'partial' | 'paid' | 'overdue' | 'cancelled';
 13 |     status: 'draft' | 'sent' | 'viewed' | 'paid' | 'cancelled';
 14 |     notes?: string;
 15 |     created_at: string;
 16 |     updated_at: string;
 17 |     userId: string;
 18 | }
 19 | 
 20 | // Helper function to generate dates
 21 | const getDate = (daysAgo: number): string => {
 22 |     const date = new Date();
 23 |     date.setDate(date.getDate() - daysAgo);
 24 |     return date.toISOString();
 25 | };
 26 | 
 27 | // Mock user ID
 28 | const MOCK_USER_ID = '550e8400-e29b-41d4-a716-446655440000';
 29 | 
 30 | export const mockInvoices: MockInvoice[] = [
 31 |     // Recent paid invoices
 32 |     {
 33 |         id: '1a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
 34 |         invoice_number: 'INV-2026-001',
 35 |         invoice_date: getDate(5),
 36 |         customer_name: 'Acme Corporation',
 37 |         customer_email: 'billing@acmecorp.com',
 38 |         customer_phone: '+1-555-0101',
 39 |         total_amount: 5250.00,
 40 |         payment_status: 'paid',
 41 |         status: 'paid',
 42 |         notes: 'Website development services - Q1 2026',
 43 |         created_at: getDate(10),
 44 |         updated_at: getDate(5),
 45 |         userId: MOCK_USER_ID,
 46 |     },
 47 |     {
 48 |         id: '2b3c4d5e-6f7g-8h9i-0j1k-2l3m4n5o6p7q',
 49 |         invoice_number: 'INV-2026-002',
 50 |         invoice_date: getDate(3),
 51 |         customer_name: 'TechStart Inc.',
 52 |         customer_email: 'accounts@techstart.io',
 53 |         customer_phone: '+1-555-0102',
 54 |         total_amount: 3800.50,
 55 |         payment_status: 'paid',
 56 |         status: 'paid',
 57 |         notes: 'Mobile app UI/UX design',
 58 |         created_at: getDate(8),
 59 |         updated_at: getDate(3),
 60 |         userId: MOCK_USER_ID,
 61 |     },
 62 | 
 63 |     // Pending invoices
 64 |     {
 65 |         id: '3c4d5e6f-7g8h-9i0j-1k2l-3m4n5o6p7q8r',
 66 |         invoice_number: 'INV-2026-003',
 67 |         invoice_date: getDate(2),
 68 |         customer_name: 'Global Solutions Ltd',
 69 |         customer_email: 'finance@globalsolutions.com',
 70 |         customer_phone: '+1-555-0103',
 71 |         total_amount: 12500.00,
 72 |         payment_status: 'pending',
 73 |         status: 'sent',
 74 |         notes: 'Enterprise software license - Annual subscription',
 75 |         created_at: getDate(7),
 76 |         updated_at: getDate(2),
 77 |         userId: MOCK_USER_ID,
 78 |     },
 79 |     {
 80 |         id: '4d5e6f7g-8h9i-0j1k-2l3m-4n5o6p7q8r9s',
 81 |         invoice_number: 'INV-2026-004',
 82 |         invoice_date: getDate(1),
 83 |         customer_name: 'Creative Agency Co.',
 84 |         customer_email: 'billing@creativeagency.com',
 85 |         customer_phone: '+1-555-0104',
 86 |         total_amount: 2750.75,
 87 |         payment_status: 'pending',
 88 |         status: 'viewed',
 89 |         notes: 'Logo design and branding package',
 90 |         created_at: getDate(5),
 91 |         updated_at: getDate(1),
 92 |         userId: MOCK_USER_ID,
 93 |     },
 94 | 
 95 |     // Overdue invoices
 96 |     {
 97 |         id: '5e6f7g8h-9i0j-1k2l-3m4n-5o6p7q8r9s0t',
 98 |         invoice_number: 'INV-2026-005',
 99 |         invoice_date: getDate(45),
100 |         customer_name: 'Retail Mart LLC',
101 |         customer_email: 'payments@retailmart.com',
102 |         customer_phone: '+1-555-0105',
103 |         total_amount: 8900.00,
104 |         payment_status: 'overdue',
105 |         status: 'sent',
106 |         notes: 'E-commerce platform development - OVERDUE',
107 |         created_at: getDate(50),
108 |         updated_at: getDate(40),
109 |         userId: MOCK_USER_ID,
110 |     },
111 |     {
112 |         id: '6f7g8h9i-0j1k-2l3m-4n5o-6p7q8r9s0t1u',
113 |         invoice_number: 'INV-2026-006',
114 |         invoice_date: getDate(35),
115 |         customer_name: 'Startup Ventures',
116 |         customer_email: 'admin@startupventures.com',
117 |         customer_phone: '+1-555-0106',
118 |         total_amount: 4200.00,
119 |         payment_status: 'overdue',
120 |         status: 'viewed',
121 |         notes: 'Consulting services - March 2026',
122 |         created_at: getDate(40),
123 |         updated_at: getDate(30),
124 |         userId: MOCK_USER_ID,
125 |     },
126 | 
127 |     // Partial payment
128 |     {
129 |         id: '7g8h9i0j-1k2l-3m4n-5o6p-7q8r9s0t1u2v',
130 |         invoice_number: 'INV-2026-007',
131 |         invoice_date: getDate(15),
132 |         customer_name: 'Manufacturing Pro',
133 |         customer_email: 'finance@manufacturingpro.com',
134 |         customer_phone: '+1-555-0107',
135 |         total_amount: 15000.00,
136 |         payment_status: 'partial',
137 |         status: 'sent',
138 |         notes: 'Custom ERP system - Phase 1 (50% paid)',
139 |         created_at: getDate(20),
140 |         updated_at: getDate(10),
141 |         userId: MOCK_USER_ID,
142 |     },
143 | 
144 |     // Draft invoices
145 |     {
146 |         id: '8h9i0j1k-2l3m-4n5o-6p7q-8r9s0t1u2v3w',
147 |         invoice_number: 'INV-2026-008',
148 |         invoice_date: getDate(0),
149 |         customer_name: 'Digital Marketing Hub',
150 |         customer_email: 'contact@digitalmarketinghub.com',
151 |         customer_phone: '+1-555-0108',
152 |         total_amount: 6500.00,
153 |         payment_status: 'pending',
154 |         status: 'draft',
155 |         notes: 'SEO optimization services - Draft',
156 |         created_at: getDate(1),
157 |         updated_at: getDate(0),
158 |         userId: MOCK_USER_ID,
159 |     },
160 |     {
161 |         id: '9i0j1k2l-3m4n-5o6p-7q8r-9s0t1u2v3w4x',
162 |         invoice_number: 'INV-2026-009',
163 |         invoice_date: getDate(0),
164 |         customer_name: 'Healthcare Systems Inc.',
165 |         customer_email: 'billing@healthcaresystems.com',
166 |         customer_phone: '+1-555-0109',
167 |         total_amount: 22000.00,
168 |         payment_status: 'pending',
169 |         status: 'draft',
170 |         notes: 'Patient management system - Pending approval',
171 |         created_at: getDate(2),
172 |         updated_at: getDate(0),
173 |         userId: MOCK_USER_ID,
174 |     },
175 | 
176 |     // Cancelled invoices
177 |     {
178 |         id: '0j1k2l3m-4n5o-6p7q-8r9s-0t1u2v3w4x5y',
179 |         invoice_number: 'INV-2026-010',
180 |         invoice_date: getDate(20),
181 |         customer_name: 'Budget Stores',
182 |         customer_email: 'accounts@budgetstores.com',
183 |         customer_phone: '+1-555-0110',
184 |         total_amount: 1500.00,
185 |         payment_status: 'cancelled',
186 |         status: 'cancelled',
187 |         notes: 'Project cancelled by client',
188 |         created_at: getDate(25),
189 |         updated_at: getDate(18),
190 |         userId: MOCK_USER_ID,
191 |     },
192 | 
193 |     // More recent invoices with various amounts
194 |     {
195 |         id: '1k2l3m4n-5o6p-7q8r-9s0t-1u2v3w4x5y6z',
196 |         invoice_number: 'INV-2026-011',
197 |         invoice_date: getDate(7),
198 |         customer_name: 'Fashion Boutique',
199 |         customer_email: 'info@fashionboutique.com',
200 |         customer_phone: '+1-555-0111',
201 |         total_amount: 950.00,
202 |         payment_status: 'paid',
203 |         status: 'paid',
204 |         notes: 'Social media content creation',
205 |         created_at: getDate(12),
206 |         updated_at: getDate(7),
207 |         userId: MOCK_USER_ID,
208 |     },
209 |     {
210 |         id: '2l3m4n5o-6p7q-8r9s-0t1u-2v3w4x5y6z7a',
211 |         invoice_number: 'INV-2026-012',
212 |         invoice_date: getDate(4),
213 |         customer_name: 'Construction Co.',
214 |         customer_email: 'billing@constructionco.com',
215 |         customer_phone: '+1-555-0112',
216 |         total_amount: 18500.00,
217 |         payment_status: 'pending',
218 |         status: 'sent',
219 |         notes: 'Project management software implementation',
220 |         created_at: getDate(9),
221 |         updated_at: getDate(4),
222 |         userId: MOCK_USER_ID,
223 |     },
224 |     {
225 |         id: '3m4n5o6p-7q8r-9s0t-1u2v-3w4x5y6z7a8b',
226 |         invoice_number: 'INV-2026-013',
227 |         invoice_date: getDate(6),
228 |         customer_name: 'Food Delivery Service',
229 |         customer_email: 'payments@fooddelivery.com',
230 |         customer_phone: '+1-555-0113',
231 |         total_amount: 7200.00,
232 |         payment_status: 'paid',
233 |         status: 'paid',
234 |         notes: 'Mobile app development - iOS & Android',
235 |         created_at: getDate(11),
236 |         updated_at: getDate(6),
237 |         userId: MOCK_USER_ID,
238 |     },
239 |     {
240 |         id: '4n5o6p7q-8r9s-0t1u-2v3w-4x5y6z7a8b9c',
241 |         invoice_number: 'INV-2026-014',
242 |         invoice_date: getDate(8),
243 |         customer_name: 'Education Platform',
244 |         customer_email: 'finance@eduplatform.com',
245 |         customer_phone: '+1-555-0114',
246 |         total_amount: 11000.00,
247 |         payment_status: 'pending',
248 |         status: 'viewed',
249 |         notes: 'Learning management system customization',
250 |         created_at: getDate(13),
251 |         updated_at: getDate(8),
252 |         userId: MOCK_USER_ID,
253 |     },
254 |     {
255 |         id: '5o6p7q8r-9s0t-1u2v-3w4x-5y6z7a8b9c0d',
256 |         invoice_number: 'INV-2026-015',
257 |         invoice_date: getDate(12),
258 |         customer_name: 'Travel Agency Plus',
259 |         customer_email: 'accounts@travelagencyplus.com',
260 |         customer_phone: '+1-555-0115',
261 |         total_amount: 5600.00,
262 |         payment_status: 'paid',
263 |         status: 'paid',
264 |         notes: 'Booking system integration',
265 |         created_at: getDate(17),
266 |         updated_at: getDate(12),
267 |         userId: MOCK_USER_ID,
268 |     },
269 |     {
270 |         id: '6p7q8r9s-0t1u-2v3w-4x5y-6z7a8b9c0d1e',
271 |         invoice_number: 'INV-2026-016',
272 |         invoice_date: getDate(25),
273 |         customer_name: 'Real Estate Group',
274 |         customer_email: 'billing@realestategroup.com',
275 |         customer_phone: '+1-555-0116',
276 |         total_amount: 9800.00,
277 |         payment_status: 'overdue',
278 |         status: 'sent',
279 |         notes: 'Property listing website - Payment overdue',
280 |         created_at: getDate(30),
281 |         updated_at: getDate(20),
282 |         userId: MOCK_USER_ID,
283 |     },
284 |     {
285 |         id: '7q8r9s0t-1u2v-3w4x-5y6z-7a8b9c0d1e2f',
286 |         invoice_number: 'INV-2026-017',
287 |         invoice_date: getDate(3),
288 |         customer_name: 'Fitness Center',
289 |         customer_email: 'admin@fitnesscenter.com',
290 |         customer_phone: '+1-555-0117',
291 |         total_amount: 3200.00,
292 |         payment_status: 'pending',
293 |         status: 'sent',
294 |         notes: 'Member management system',
295 |         created_at: getDate(8),
296 |         updated_at: getDate(3),
297 |         userId: MOCK_USER_ID,
298 |     },
299 |     {
300 |         id: '8r9s0t1u-2v3w-4x5y-6z7a-8b9c0d1e2f3g',
301 |         invoice_number: 'INV-2026-018',
302 |         invoice_date: getDate(1),
303 |         customer_name: 'Legal Services LLC',
304 |         customer_email: 'billing@legalservices.com',
305 |         customer_phone: '+1-555-0118',
306 |         total_amount: 14500.00,
307 |         payment_status: 'pending',
308 |         status: 'viewed',
309 |         notes: 'Case management software development',
310 |         created_at: getDate(6),
311 |         updated_at: getDate(1),
312 |         userId: MOCK_USER_ID,
313 |     },
314 |     {
315 |         id: '9s0t1u2v-3w4x-5y6z-7a8b-9c0d1e2f3g4h',
316 |         invoice_number: 'INV-2026-019',
317 |         invoice_date: getDate(10),
318 |         customer_name: 'Automotive Parts Co.',
319 |         customer_email: 'finance@autoparts.com',
320 |         customer_phone: '+1-555-0119',
321 |         total_amount: 6750.00,
322 |         payment_status: 'paid',
323 |         status: 'paid',
324 |         notes: 'Inventory management system',
325 |         created_at: getDate(15),
326 |         updated_at: getDate(10),
327 |         userId: MOCK_USER_ID,
328 |     },
329 |     {
330 |         id: '0t1u2v3w-4x5y-6z7a-8b9c-0d1e2f3g4h5i',
331 |         invoice_number: 'INV-2026-020',
332 |         invoice_date: getDate(0),
333 |         customer_name: 'Pet Care Services',
334 |         customer_email: 'contact@petcareservices.com',
335 |         customer_phone: '+1-555-0120',
336 |         total_amount: 2100.00,
337 |         payment_status: 'pending',
338 |         status: 'draft',
339 |         notes: 'Appointment booking system - In progress',
340 |         created_at: getDate(1),
341 |         updated_at: getDate(0),
342 |         userId: MOCK_USER_ID,
343 |     },
344 | ];
345 | 
346 | // Summary statistics
347 | export const mockInvoiceStats = {
348 |     total: mockInvoices.length,
349 |     paid: mockInvoices.filter(inv => inv.payment_status === 'paid').length,
350 |     pending: mockInvoices.filter(inv => inv.payment_status === 'pending').length,
351 |     overdue: mockInvoices.filter(inv => inv.payment_status === 'overdue').length,
352 |     partial: mockInvoices.filter(inv => inv.payment_status === 'partial').length,
353 |     cancelled: mockInvoices.filter(inv => inv.payment_status === 'cancelled').length,
354 |     totalAmount: mockInvoices.reduce((sum, inv) => sum + inv.total_amount, 0),
355 |     paidAmount: mockInvoices
356 |         .filter(inv => inv.payment_status === 'paid')
357 |         .reduce((sum, inv) => sum + inv.total_amount, 0),
358 |     pendingAmount: mockInvoices
359 |         .filter(inv => inv.payment_status === 'pending')
360 |         .reduce((sum, inv) => sum + inv.total_amount, 0),
361 |     overdueAmount: mockInvoices
362 |         .filter(inv => inv.payment_status === 'overdue')
363 |         .reduce((sum, inv) => sum + inv.total_amount, 0),
364 | };
365 | 
366 | // Helper function to get paginated invoices
367 | export const getPaginatedInvoices = (page: number = 1, limit: number = 10) => {
368 |     const startIndex = (page - 1) * limit;
369 |     const endIndex = startIndex + limit;
370 |     const paginatedData = mockInvoices.slice(startIndex, endIndex);
371 |     
372 |     return {
373 |         data: paginatedData,
374 |         pagination: {
375 |             currentPage: page,
376 |             totalPages: Math.ceil(mockInvoices.length / limit),
377 |             totalItems: mockInvoices.length,
378 |             itemsPerPage: limit,
379 |         },
380 |     };
381 | };
382 | 
383 | // Helper function to get invoice by ID
384 | export const getInvoiceById = (id: string): MockInvoice | undefined => {
385 |     return mockInvoices.find(invoice => invoice.id === id);
386 | };
387 | 
388 | // Helper function to filter invoices by status
389 | export const getInvoicesByStatus = (status: string) => {
390 |     return mockInvoices.filter(invoice => invoice.status === status);
391 | };
392 | 
393 | // Helper function to filter invoices by payment status
394 | export const getInvoicesByPaymentStatus = (paymentStatus: string) => {
395 |     return mockInvoices.filter(invoice => invoice.payment_status === paymentStatus);
396 | };
397 | 
398 | // Made with Bob
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/src/page/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx,frontend/src/page/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:35:45.210Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.03

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

Now I'll update the invoice page to use real API calls instead of mock data. I'll replace the mock data imports and functions with the actual API service calls.

<apply_diff>
<path>frontend/src/page/invoice/index.tsx</path>
<diff>
<<<<<<< SEARCH
:start_line:1
-------
import { useState, useEffect } from 'react';
import { Eye, FileText, Calendar, User, Mail, Phone, DollarSign, FileCheck } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from '@/components/ui/dialog';
import { getPaginatedInvoices, getInvoiceById as getMockInvoiceById } from '@/data/mockInvoices';
=======
import { useState, useEffect } from 'react';
import { Eye, FileText, Calendar, User, Mail, Phone, DollarSign, FileCheck } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from '@/components/ui/dialog';
import { getUserInvoices, getInvoiceById } from '@/service/invoice';
>>>>>>> REPLACE
<<<<<<< SEARCH
:start_line:43
-------
    const fetchInvoices = async () => {
        try {
            setLoading(true);
            // Using mock data instead of API call
            const response = getPaginatedInvoices(page, 10);
            setInvoices(response.data || []);
            setTotalPages(response.pagination?.totalPages || 1);
        } catch (error) {
            console.error('Error fetching invoices:', error);
        } finally {
            setLoading(false);
        }
    };
=======
    const fetchInvoices = async () => {
        try {
            setLoading(true);
            const response = await getUserInvoices({ page, limit: 10 });
            setInvoices(response.data || []);
            setTotalPages(response.pagination?.totalPages || 1);
        } catch (error) {
            console.error('Error fetching invoices:', error);
        } finally {
            setLoading(false);
        }
    };
>>>>>>> REPLACE
<<<<<<< SEARCH
:start_line:58
-------
    const handleViewInvoice = async (invoiceId: string) => {
        try {
            // Using mock data instead of API call
            const invoice = getMockInvoiceById(invoiceId);
            if (invoice) {
                setSelectedInvoice(invoice);
                setIsDialogOpen(true);
            }
        } catch (error) {
            console.error('Error fetching invoice details:', error);
        }
    };
=======
    const handleViewInvoice = async (invoiceId: string) => {
        try {
            const response = await getInvoiceById(invoiceId);
            if (response.data) {
                setSelectedInvoice(response.data);
                setIsDialogOpen(true);
            }
        } catch (error) {
            console.error('Error fetching invoice details:', error);
        }
    };
>>>>>>> REPLACE
</diff>
</apply_diff>

---

**User:**

[apply_diff for 'frontend/src/page/invoice/index.tsx'] Result:
<file_write_result>
<path>frontend/src/page/invoice/index.tsx</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<environment_details>
# VSCode Visible Files
frontend/src/page/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx,frontend/src/page/invoice/index.tsx

# Recently Modified Files
These files have been modified since you last accessed them (file was just edited so you may need to re-read it before editing):
frontend/src/page/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:35:57.765Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.08

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

<attempt_completion>
<result>
Successfully replaced mock data with real API calls in the invoice page:

**Changes made:**
1. Removed mock data import: `getPaginatedInvoices` and `getMockInvoiceById` from `@/data/mockInvoices`
2. Added real API service imports: `getUserInvoices` and `getInvoiceById` from `@/service/invoice`
3. Updated `fetchInvoices()` function to use `getUserInvoices()` API call with pagination parameters
4. Updated `handleViewInvoice()` function to use `getInvoiceById()` API call and properly handle the response data structure

The invoice page now fetches real data from the backend API routes instead of using mock data.
</result>
</attempt_completion>

