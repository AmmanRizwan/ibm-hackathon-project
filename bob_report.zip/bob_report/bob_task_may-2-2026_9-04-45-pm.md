**User:**

<task>
In the Total Amount it will give an $NaN fix this issue
</task>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:34:28.322Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.00

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
backend/.editorconfig
backend/.env.example
backend/.gitattributes
backend/.gitignore
backend/.prettierignore
backend/.prettierrc.json
backend/.yarnrc.yml
backend/eslint.config.js
backend/package.json
backend/README.md
backend/tsconfig.json
backend/yarn.lock
backend/.yarn/
backend/src/
backend/src/index.ts
backend/src/config/
backend/src/config/db.ts
backend/src/config/env.ts
backend/src/controller/
backend/src/controller/auth/
backend/src/controller/auth/index.ts
backend/src/controller/billing_detail/
backend/src/controller/billing_detail/index.ts
backend/src/controller/invoice/
backend/src/controller/invoice/index.ts
backend/src/controller/payment_methods/
backend/src/controller/payment_methods/index.ts
backend/src/controller/transaction/
backend/src/controller/transaction/index.ts
backend/src/controller/user/
backend/src/controller/user/index.ts
backend/src/middleware/
backend/src/middleware/auth.ts
backend/src/middleware/error.ts
backend/src/middleware/permission.ts
backend/src/models/
backend/src/models/billing_detail.ts
backend/src/models/index.ts
backend/src/models/invoice.ts
backend/src/models/otp.ts
backend/src/models/payment_method.ts
backend/src/models/transaction.ts
backend/src/models/user.ts
backend/src/routes/
backend/src/routes/index.ts
backend/src/routes/auth/
backend/src/routes/auth/index.ts
backend/src/routes/billing_details/
backend/src/routes/billing_details/index.ts
backend/src/routes/invoice/
backend/src/routes/invoice/index.ts
backend/src/routes/payment_methods/
backend/src/routes/payment_methods/index.ts
backend/src/routes/transaction/
backend/src/routes/transaction/index.ts
backend/src/routes/user/
backend/src/routes/user/index.ts
backend/src/services/
backend/src/services/smtp.ts
backend/src/utils/
backend/src/utils/bcrypt.ts
backend/src/utils/error.ts
backend/src/utils/generate-otp.ts
backend/src/utils/jwt.ts
backend/src/utils/logger.ts
backend/src/utils/reminder.ts
backend/src/views/
backend/src/views/auth/
backend/src/views/auth/forgot-password.ejs
backend/src/views/auth/login.ejs
backend/src/views/auth/signup.ejs
backend/src/views/invoice/
backend/src/views/invoice/invoice.ejs
backend/src/views/reminder/
backend/src/views/reminder/reminder.ejs
frontend/
frontend/.env.example
frontend/.gitignore
frontend/.prettierignore
frontend/.prettierrc.json
frontend/.yarnrc.yml
frontend/components.json
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/postcss.config.js
frontend/README.md
frontend/tailwind.config.js
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
frontend/src/components/
frontend/src/components/custom/
frontend/src/components/custom/navbar/
frontend/src/components/custom/navbar/index.tsx
frontend/src/components/custom/page-loader/
frontend/src/components/custom/page-loader/index.tsx
frontend/src/components/custom/sidebar/
frontend/src/components/custom/sidebar/index.tsx
frontend/src/components/ui/
frontend/src/components/ui/accordion.tsx
frontend/src/components/ui/alert.tsx
frontend/src/components/ui/badge.tsx
frontend/src/components/ui/button.tsx
frontend/src/components/ui/card.tsx
frontend/src/components/ui/checkbox.tsx
frontend/src/components/ui/dialog.tsx
frontend/src/components/ui/dropdown-menu.tsx
frontend/src/components/ui/form.tsx
frontend/src/components/ui/index.ts
frontend/src/components/ui/input.tsx
frontend/src/components/ui/label.tsx
frontend/src/components/ui/radio-group.tsx
frontend/src/components/ui/select.tsx
frontend/src/components/ui/switch.tsx
frontend/src/components/ui/tabs.tsx
frontend/src/components/ui/textarea.tsx
frontend/src/components/ui/tooltip.tsx
frontend/src/data/
frontend/src/data/mockInvoices.ts
frontend/src/lib/
frontend/src/lib/utils.ts
frontend/src/page/
frontend/src/page/layout.tsx
frontend/src/page/admin/
frontend/src/page/admin/invoice/
frontend/src/page/admin/invoice/index.tsx
frontend/src/page/admin/manage_employee/
frontend/src/page/admin/manage_employee/index.tsx
frontend/src/page/admin/payment_method/
frontend/src/page/admin/payment_method/index.tsx
frontend/src/page/admin/transcation/
frontend/src/page/admin/transcation/index.tsx
frontend/src/page/auth/
frontend/src/page/auth/forgot-password/
frontend/src/page/auth/forgot-password/index.tsx
frontend/src/page/auth/login/
frontend/src/page/auth/login/index.tsx
frontend/src/page/auth/signup/
frontend/src/page/auth/signup/index.tsx
frontend/src/page/billing_detail/
frontend/src/page/billing_detail/index.tsx
frontend/src/page/billing_detail/new/
frontend/src/page/billing_detail/new/index.tsx
frontend/src/page/home/
frontend/src/page/home/index.tsx
frontend/src/page/invoice/
frontend/src/page/invoice/index.tsx
frontend/src/page/payment_method/
frontend/src/page/payment_method/index.tsx
frontend/src/page/payment_method/new/
frontend/src/page/payment_method/new/index.tsx
frontend/src/page/profile/
frontend/src/page/profile/index.tsx
frontend/src/page/transaction/
frontend/src/page/transaction/index.tsx
frontend/src/service/
frontend/src/service/api.ts
frontend/src/service/auth/
frontend/src/service/auth/index.ts
frontend/src/service/auth/interface.ts
frontend/src/service/billing_details/
frontend/src/service/billing_details/index.ts
frontend/src/service/billing_details/interface.ts
frontend/src/service/invoice/
frontend/src/service/invoice/index.ts
frontend/src/service/invoice/interface.ts
frontend/src/service/payment_methods/
frontend/src/service/payment_methods/index.ts
frontend/src/service/payment_methods/interface.ts
frontend/src/service/transaction/
frontend/src/service/transaction/index.ts
frontend/src/service/transaction/interface.ts
frontend/src/service/user/
frontend/src/service/user/index.ts
frontend/src/service/user/interface.ts
frontend/src/store/
frontend/src/store/index.ts
frontend/src/store/auth/
frontend/src/store/auth/index.ts
frontend/src/store/nav-toggle/index.ts
frontend/src/utils/AutoRedirect.tsx
frontend/src/utils/PermissionRoute.tsx
frontend/src/utils/ProtectedRoute.tsx

(File list truncated. Use list_files on specific subdirectories if you need to explore further.)
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I'll help you fix the NaN issue in the Total Amount. Let me first examine the invoice file to understand the problem.

<read_file>
<args>
<file>
<path>frontend/src/page/admin/invoice/index.tsx</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 'frontend/src/page/admin/invoice/index.tsx'. Reading multiple files at once is more efficient for the LLM. If other files are relevant to your current task, please read them simultaneously.] Result:
<files>
<file><path>frontend/src/page/admin/invoice/index.tsx</path>
<content lines="1-855">
  1 | import { useEffect, useState } from 'react';
  2 | import { getAllInvoices, adminUpdateInvoice, adminDeleteInvoice } from '@/service/invoice';
  3 | import {
  4 |     Card,
  5 |     CardContent,
  6 |     CardDescription,
  7 |     CardHeader,
  8 |     CardTitle,
  9 | } from '@/components/ui/card';
 10 | import { Badge } from '@/components/ui/badge';
 11 | import { Button } from '@/components/ui/button';
 12 | import {
 13 |     Dialog,
 14 |     DialogContent,
 15 |     DialogDescription,
 16 |     DialogFooter,
 17 |     DialogHeader,
 18 |     DialogTitle,
 19 | } from '@/components/ui/dialog';
 20 | import { Input } from '@/components/ui/input';
 21 | import { Label } from '@/components/ui/label';
 22 | import { Textarea } from '@/components/ui/textarea';
 23 | import {
 24 |     Select,
 25 |     SelectContent,
 26 |     SelectItem,
 27 |     SelectTrigger,
 28 |     SelectValue,
 29 | } from '@/components/ui/select';
 30 | import {
 31 |     FileText,
 32 |     Eye,
 33 |     Edit,
 34 |     Trash2,
 35 |     Loader2,
 36 |     User,
 37 |     Mail,
 38 |     Phone,
 39 |     RefreshCw,
 40 | } from 'lucide-react';
 41 | 
 42 | interface Invoice {
 43 |     id: string;
 44 |     invoice_number: string;
 45 |     invoice_date: string;
 46 |     customer_name: string;
 47 |     customer_email?: string;
 48 |     customer_phone?: string;
 49 |     total_amount: number;
 50 |     payment_status: 'pending' | 'partial' | 'paid' | 'overdue' | 'cancelled';
 51 |     status: 'draft' | 'sent' | 'viewed' | 'paid' | 'cancelled';
 52 |     notes?: string;
 53 |     userId: string;
 54 |     user?: {
 55 |         id: string;
 56 |         name: string;
 57 |         email: string;
 58 |         phone: string;
 59 |     };
 60 |     createdAt: string;
 61 |     updatedAt: string;
 62 | }
 63 | 
 64 | interface PaginationData {
 65 |     currentPage: number;
 66 |     totalPages: number;
 67 |     totalCount: number;
 68 |     limit: number;
 69 |     hasNextPage: boolean;
 70 |     hasPreviousPage: boolean;
 71 | }
 72 | 
 73 | const AdminInvoice = () => {
 74 |     const [invoices, setInvoices] = useState<Invoice[]>([]);
 75 |     const [loading, setLoading] = useState(true);
 76 |     const [error, setError] = useState<string | null>(null);
 77 |     const [successMessage, setSuccessMessage] = useState<string | null>(null);
 78 |     const [pagination, setPagination] = useState<PaginationData>({
 79 |         currentPage: 1,
 80 |         totalPages: 1,
 81 |         totalCount: 0,
 82 |         limit: 10,
 83 |         hasNextPage: false,
 84 |         hasPreviousPage: false,
 85 |     });
 86 | 
 87 |     // Dialog states
 88 |     const [viewDialogOpen, setViewDialogOpen] = useState(false);
 89 |     const [editDialogOpen, setEditDialogOpen] = useState(false);
 90 |     const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
 91 |     const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
 92 | 
 93 |     // Form states
 94 |     const [editForm, setEditForm] = useState({
 95 |         invoice_number: '',
 96 |         invoice_date: '',
 97 |         customer_name: '',
 98 |         customer_email: '',
 99 |         customer_phone: '',
100 |         total_amount: '',
101 |         payment_status: '',
102 |         status: '',
103 |         notes: '',
104 |     });
105 | 
106 |     const [submitting, setSubmitting] = useState(false);
107 | 
108 |     useEffect(() => {
109 |         fetchInvoices();
110 |     }, [pagination.currentPage]);
111 | 
112 |     const fetchInvoices = async () => {
113 |         try {
114 |             setLoading(true);
115 |             setError(null);
116 |             const response = await getAllInvoices({
117 |                 page: pagination.currentPage,
118 |                 limit: pagination.limit,
119 |             });
120 |             setInvoices(response.data || []);
121 |             if (response.pagination) {
122 |                 setPagination(response.pagination);
123 |             }
124 |         } catch (err: any) {
125 |             setError(err.response?.data?.message || 'Failed to fetch invoices');
126 |         } finally {
127 |             setLoading(false);
128 |         }
129 |     };
130 | 
131 |     const handleViewInvoice = (invoice: Invoice) => {
132 |         setSelectedInvoice(invoice);
133 |         setViewDialogOpen(true);
134 |     };
135 | 
136 |     const handleEditInvoice = (invoice: Invoice) => {
137 |         setSelectedInvoice(invoice);
138 |         setEditForm({
139 |             invoice_number: invoice.invoice_number,
140 |             invoice_date: invoice.invoice_date.split('T')[0],
141 |             customer_name: invoice.customer_name,
142 |             customer_email: invoice.customer_email || '',
143 |             customer_phone: invoice.customer_phone || '',
144 |             total_amount: invoice.total_amount.toString(),
145 |             payment_status: invoice.payment_status,
146 |             status: invoice.status,
147 |             notes: invoice.notes || '',
148 |         });
149 |         setEditDialogOpen(true);
150 |     };
151 | 
152 |     const handleDeleteInvoice = (invoice: Invoice) => {
153 |         setSelectedInvoice(invoice);
154 |         setDeleteDialogOpen(true);
155 |     };
156 | 
157 |     const handleUpdateSubmit = async () => {
158 |         if (!selectedInvoice) return;
159 | 
160 |         try {
161 |             setSubmitting(true);
162 |             setError(null);
163 |             await adminUpdateInvoice(selectedInvoice.id, {
164 |                 invoice_number: editForm.invoice_number,
165 |                 invoice_date: editForm.invoice_date,
166 |                 customer_name: editForm.customer_name,
167 |                 customer_email: editForm.customer_email || undefined,
168 |                 customer_phone: editForm.customer_phone || undefined,
169 |                 total_amount: parseFloat(editForm.total_amount),
170 |                 payment_status: editForm.payment_status,
171 |                 status: editForm.status,
172 |                 notes: editForm.notes || undefined,
173 |             });
174 |             setSuccessMessage('Invoice updated successfully');
175 |             setEditDialogOpen(false);
176 |             fetchInvoices();
177 |             setTimeout(() => setSuccessMessage(null), 3000);
178 |         } catch (err: any) {
179 |             setError(err.response?.data?.message || 'Failed to update invoice');
180 |         } finally {
181 |             setSubmitting(false);
182 |         }
183 |     };
184 | 
185 |     const handleDeleteSubmit = async () => {
186 |         if (!selectedInvoice) return;
187 | 
188 |         try {
189 |             setSubmitting(true);
190 |             setError(null);
191 |             await adminDeleteInvoice(selectedInvoice.id);
192 |             setSuccessMessage('Invoice deleted successfully');
193 |             setDeleteDialogOpen(false);
194 |             fetchInvoices();
195 |             setTimeout(() => setSuccessMessage(null), 3000);
196 |         } catch (err: any) {
197 |             setError(err.response?.data?.message || 'Failed to delete invoice');
198 |         } finally {
199 |             setSubmitting(false);
200 |         }
201 |     };
202 | 
203 |     const formatDate = (dateString: string) => {
204 |         return new Date(dateString).toLocaleDateString('en-US', {
205 |             year: 'numeric',
206 |             month: 'short',
207 |             day: 'numeric',
208 |         });
209 |     };
210 | 
211 |     const formatCurrency = (amount: number) => {
212 |         return new Intl.NumberFormat('en-US', {
213 |             style: 'currency',
214 |             currency: 'USD',
215 |         }).format(amount);
216 |     };
217 | 
218 |     const getPaymentStatusVariant = (
219 |         status: string
220 |     ): 'default' | 'secondary' | 'destructive' | 'outline' => {
221 |         switch (status.toLowerCase()) {
222 |             case 'paid':
223 |                 return 'default';
224 |             case 'pending':
225 |             case 'partial':
226 |                 return 'secondary';
227 |             case 'overdue':
228 |             case 'cancelled':
229 |                 return 'destructive';
230 |             default:
231 |                 return 'outline';
232 |         }
233 |     };
234 | 
235 |     const getStatusVariant = (
236 |         status: string
237 |     ): 'default' | 'secondary' | 'destructive' | 'outline' => {
238 |         switch (status.toLowerCase()) {
239 |             case 'paid':
240 |             case 'sent':
241 |             case 'viewed':
242 |                 return 'default';
243 |             case 'draft':
244 |                 return 'secondary';
245 |             case 'cancelled':
246 |                 return 'destructive';
247 |             default:
248 |                 return 'outline';
249 |         }
250 |     };
251 | 
252 |     if (loading) {
253 |         return (
254 |             <div className="flex items-center justify-center min-h-[400px]">
255 |                 <div className="text-center">
256 |                     <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
257 |                     <p className="mt-4 text-muted-foreground">Loading invoices...</p>
258 |                 </div>
259 |             </div>
260 |         );
261 |     }
262 | 
263 |     return (
264 |         <div className="container mx-auto py-6 px-4 max-w-7xl">
265 |             {/* Success Message */}
266 |             {successMessage && (
267 |                 <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md">
268 |                     {successMessage}
269 |                 </div>
270 |             )}
271 | 
272 |             {/* Error Message */}
273 |             {error && (
274 |                 <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
275 |                     {error}
276 |                 </div>
277 |             )}
278 | 
279 |             <div className="mb-6 space-y-4">
280 |                 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
281 |                     <div>
282 |                         <h1 className="text-3xl font-bold tracking-tight">All Invoices</h1>
283 |                         <p className="text-muted-foreground mt-2">
284 |                             View and manage all invoices from all users
285 |                         </p>
286 |                     </div>
287 |                     <Button
288 |                         variant="outline"
289 |                         size="sm"
290 |                         onClick={fetchInvoices}
291 |                         className="gap-2"
292 |                     >
293 |                         <RefreshCw className="h-4 w-4" />
294 |                         Refresh
295 |                     </Button>
296 |                 </div>
297 | 
298 |                 {/* Summary Cards */}
299 |                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
300 |                     <Card>
301 |                         <CardHeader className="pb-2">
302 |                             <CardDescription>Total Invoices</CardDescription>
303 |                             <CardTitle className="text-2xl">{pagination.totalCount}</CardTitle>
304 |                         </CardHeader>
305 |                     </Card>
306 |                     <Card>
307 |                         <CardHeader className="pb-2">
308 |                             <CardDescription>Total Amount</CardDescription>
309 |                             <CardTitle className="text-2xl">
310 |                                 {formatCurrency(
311 |                                     invoices.reduce((sum, inv) => sum + inv.total_amount, 0)
312 |                                 )}
313 |                             </CardTitle>
314 |                         </CardHeader>
315 |                     </Card>
316 |                     <Card>
317 |                         <CardHeader className="pb-2">
318 |                             <CardDescription>Paid</CardDescription>
319 |                             <CardTitle className="text-2xl text-green-600">
320 |                                 {invoices.filter((inv) => inv.payment_status === 'paid').length}
321 |                             </CardTitle>
322 |                         </CardHeader>
323 |                     </Card>
324 |                     <Card>
325 |                         <CardHeader className="pb-2">
326 |                             <CardDescription>Pending</CardDescription>
327 |                             <CardTitle className="text-2xl text-yellow-600">
328 |                                 {invoices.filter((inv) => inv.payment_status === 'pending').length}
329 |                             </CardTitle>
330 |                         </CardHeader>
331 |                     </Card>
332 |                 </div>
333 |             </div>
334 | 
335 |             {/* Invoices Table */}
336 |             <Card>
337 |                 <CardHeader>
338 |                     <CardTitle>Invoice List</CardTitle>
339 |                     <CardDescription>
340 |                         Showing {invoices.length} of {pagination.totalCount} invoices
341 |                     </CardDescription>
342 |                 </CardHeader>
343 |                 <CardContent>
344 |                     {invoices.length === 0 ? (
345 |                         <div className="text-center py-12 text-muted-foreground">
346 |                             <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
347 |                             <p>No invoices found</p>
348 |                         </div>
349 |                     ) : (
350 |                         <div className="overflow-x-auto">
351 |                             <table className="w-full border-collapse">
352 |                                 <thead>
353 |                                     <tr className="border-b bg-muted/50">
354 |                                         <th className="text-left p-4 font-semibold">Invoice #</th>
355 |                                         <th className="text-left p-4 font-semibold">Customer</th>
356 |                                         <th className="text-left p-4 font-semibold">User</th>
357 |                                         <th className="text-left p-4 font-semibold">Date</th>
358 |                                         <th className="text-left p-4 font-semibold">Amount</th>
359 |                                         <th className="text-left p-4 font-semibold">Payment</th>
360 |                                         <th className="text-left p-4 font-semibold">Status</th>
361 |                                         <th className="text-center p-4 font-semibold">Actions</th>
362 |                                     </tr>
363 |                                 </thead>
364 |                                 <tbody>
365 |                                     {invoices.map((invoice) => (
366 |                                         <tr
367 |                                             key={invoice.id}
368 |                                             className="border-b hover:bg-muted/30 transition-colors"
369 |                                         >
370 |                                             <td className="p-4 font-medium">
371 |                                                 {invoice.invoice_number}
372 |                                             </td>
373 |                                             <td className="p-4">
374 |                                                 <div>
375 |                                                     <p className="font-medium">
376 |                                                         {invoice.customer_name}
377 |                                                     </p>
378 |                                                     {invoice.customer_email && (
379 |                                                         <p className="text-sm text-muted-foreground">
380 |                                                             {invoice.customer_email}
381 |                                                         </p>
382 |                                                     )}
383 |                                                 </div>
384 |                                             </td>
385 |                                             <td className="p-4">
386 |                                                 {invoice.user && (
387 |                                                     <div>
388 |                                                         <p className="font-medium text-sm">
389 |                                                             {invoice.user.name}
390 |                                                         </p>
391 |                                                         <p className="text-xs text-muted-foreground">
392 |                                                             {invoice.user.email}
393 |                                                         </p>
394 |                                                     </div>
395 |                                                 )}
396 |                                             </td>
397 |                                             <td className="p-4 text-sm">
398 |                                                 {formatDate(invoice.invoice_date)}
399 |                                             </td>
400 |                                             <td className="p-4 font-semibold">
401 |                                                 {formatCurrency(invoice.total_amount)}
402 |                                             </td>
403 |                                             <td className="p-4">
404 |                                                 <Badge
405 |                                                     variant={getPaymentStatusVariant(
406 |                                                         invoice.payment_status
407 |                                                     )}
408 |                                                     className="capitalize"
409 |                                                 >
410 |                                                     {invoice.payment_status}
411 |                                                 </Badge>
412 |                                             </td>
413 |                                             <td className="p-4">
414 |                                                 <Badge
415 |                                                     variant={getStatusVariant(invoice.status)}
416 |                                                     className="capitalize"
417 |                                                 >
418 |                                                     {invoice.status}
419 |                                                 </Badge>
420 |                                             </td>
421 |                                             <td className="p-4">
422 |                                                 <div className="flex justify-center gap-2">
423 |                                                     <Button
424 |                                                         variant="ghost"
425 |                                                         size="sm"
426 |                                                         onClick={() => handleViewInvoice(invoice)}
427 |                                                     >
428 |                                                         <Eye className="h-4 w-4" />
429 |                                                     </Button>
430 |                                                     <Button
431 |                                                         variant="ghost"
432 |                                                         size="sm"
433 |                                                         onClick={() => handleEditInvoice(invoice)}
434 |                                                     >
435 |                                                         <Edit className="h-4 w-4" />
436 |                                                     </Button>
437 |                                                     <Button
438 |                                                         variant="ghost"
439 |                                                         size="sm"
440 |                                                         onClick={() => handleDeleteInvoice(invoice)}
441 |                                                     >
442 |                                                         <Trash2 className="h-4 w-4 text-destructive" />
443 |                                                     </Button>
444 |                                                 </div>
445 |                                             </td>
446 |                                         </tr>
447 |                                     ))}
448 |                                 </tbody>
449 |                             </table>
450 |                         </div>
451 |                     )}
452 |                 </CardContent>
453 |             </Card>
454 | 
455 |             {/* Pagination */}
456 |             {pagination.totalPages > 1 && (
457 |                 <div className="mt-6 flex justify-center gap-2">
458 |                     <Button
459 |                         variant="outline"
460 |                         onClick={() =>
461 |                             setPagination((prev) => ({
462 |                                 ...prev,
463 |                                 currentPage: prev.currentPage - 1,
464 |                             }))
465 |                         }
466 |                         disabled={!pagination.hasPreviousPage}
467 |                     >
468 |                         Previous
469 |                     </Button>
470 |                     <div className="flex items-center px-4">
471 |                         <span className="text-sm text-muted-foreground">
472 |                             Page {pagination.currentPage} of {pagination.totalPages}
473 |                         </span>
474 |                     </div>
475 |                     <Button
476 |                         variant="outline"
477 |                         onClick={() =>
478 |                             setPagination((prev) => ({
479 |                                 ...prev,
480 |                                 currentPage: prev.currentPage + 1,
481 |                             }))
482 |                         }
483 |                         disabled={!pagination.hasNextPage}
484 |                     >
485 |                         Next
486 |                     </Button>
487 |                 </div>
488 |             )}
489 | 
490 |             {/* View Invoice Dialog */}
491 |             <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
492 |                 <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
493 |                     <DialogHeader>
494 |                         <DialogTitle className="flex items-center gap-2">
495 |                             <FileText className="h-5 w-5" />
496 |                             Invoice Details
497 |                         </DialogTitle>
498 |                         <DialogDescription>Complete invoice information</DialogDescription>
499 |                     </DialogHeader>
500 |                     {selectedInvoice && (
501 |                         <div className="space-y-6 mt-4">
502 |                             {/* Invoice Header */}
503 |                             <div className="flex justify-between items-start pb-4 border-b">
504 |                                 <div>
505 |                                     <h3 className="text-2xl font-bold">
506 |                                         {selectedInvoice.invoice_number}
507 |                                     </h3>
508 |                                     <p className="text-sm text-muted-foreground mt-1">
509 |                                         {formatDate(selectedInvoice.invoice_date)}
510 |                                     </p>
511 |                                 </div>
512 |                                 <div className="text-right">
513 |                                     <p className="text-sm text-muted-foreground mb-2">
514 |                                         Total Amount
515 |                                     </p>
516 |                                     <p className="text-2xl font-bold">
517 |                                         {formatCurrency(selectedInvoice.total_amount)}
518 |                                     </p>
519 |                                 </div>
520 |                             </div>
521 | 
522 |                             {/* Status Badges */}
523 |                             <div className="flex gap-3">
524 |                                 <div>
525 |                                     <p className="text-sm text-muted-foreground mb-2">
526 |                                         Payment Status
527 |                                     </p>
528 |                                     <Badge
529 |                                         variant={getPaymentStatusVariant(
530 |                                             selectedInvoice.payment_status
531 |                                         )}
532 |                                         className="text-sm px-3 py-1 capitalize"
533 |                                     >
534 |                                         {selectedInvoice.payment_status}
535 |                                     </Badge>
536 |                                 </div>
537 |                                 <div>
538 |                                     <p className="text-sm text-muted-foreground mb-2">
539 |                                         Invoice Status
540 |                                     </p>
541 |                                     <Badge
542 |                                         variant={getStatusVariant(selectedInvoice.status)}
543 |                                         className="text-sm px-3 py-1 capitalize"
544 |                                     >
545 |                                         {selectedInvoice.status}
546 |                                     </Badge>
547 |                                 </div>
548 |                             </div>
549 | 
550 |                             {/* Customer Information */}
551 |                             <div>
552 |                                 <h4 className="font-semibold mb-3 flex items-center gap-2">
553 |                                     <User className="h-4 w-4" />
554 |                                     Customer Information
555 |                                 </h4>
556 |                                 <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
557 |                                     <div className="flex items-start gap-3">
558 |                                         <User className="h-5 w-5 text-muted-foreground mt-0.5" />
559 |                                         <div>
560 |                                             <p className="text-sm font-medium text-muted-foreground">
561 |                                                 Name
562 |                                             </p>
563 |                                             <p className="text-base">
564 |                                                 {selectedInvoice.customer_name}
565 |                                             </p>
566 |                                         </div>
567 |                                     </div>
568 |                                     {selectedInvoice.customer_email && (
569 |                                         <div className="flex items-start gap-3">
570 |                                             <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
571 |                                             <div>
572 |                                                 <p className="text-sm font-medium text-muted-foreground">
573 |                                                     Email
574 |                                                 </p>
575 |                                                 <p className="text-base">
576 |                                                     {selectedInvoice.customer_email}
577 |                                                 </p>
578 |                                             </div>
579 |                                         </div>
580 |                                     )}
581 |                                     {selectedInvoice.customer_phone && (
582 |                                         <div className="flex items-start gap-3">
583 |                                             <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
584 |                                             <div>
585 |                                                 <p className="text-sm font-medium text-muted-foreground">
586 |                                                     Phone
587 |                                                 </p>
588 |                                                 <p className="text-base">
589 |                                                     {selectedInvoice.customer_phone}
590 |                                                 </p>
591 |                                             </div>
592 |                                         </div>
593 |                                     )}
594 |                                 </div>
595 |                             </div>
596 | 
597 |                             {/* User Information */}
598 |                             {selectedInvoice.user && (
599 |                                 <div>
600 |                                     <h4 className="font-semibold mb-3 flex items-center gap-2">
601 |                                         <User className="h-4 w-4" />
602 |                                         Created By
603 |                                     </h4>
604 |                                     <div className="space-y-2 bg-muted/30 p-4 rounded-lg">
605 |                                         <p className="text-sm">
606 |                                             <span className="font-medium">Name:</span>{' '}
607 |                                             {selectedInvoice.user.name}
608 |                                         </p>
609 |                                         <p className="text-sm">
610 |                                             <span className="font-medium">Email:</span>{' '}
611 |                                             {selectedInvoice.user.email}
612 |                                         </p>
613 |                                         <p className="text-sm">
614 |                                             <span className="font-medium">Phone:</span>{' '}
615 |                                             {selectedInvoice.user.phone}
616 |                                         </p>
617 |                                     </div>
618 |                                 </div>
619 |                             )}
620 | 
621 |                             {/* Notes */}
622 |                             {selectedInvoice.notes && (
623 |                                 <div>
624 |                                     <h4 className="font-semibold mb-3">Notes</h4>
625 |                                     <p className="text-sm bg-muted/30 p-4 rounded-lg">
626 |                                         {selectedInvoice.notes}
627 |                                     </p>
628 |                                 </div>
629 |                             )}
630 | 
631 |                             {/* Timestamps */}
632 |                             <div className="pt-4 border-t text-sm text-muted-foreground">
633 |                                 <p>Created: {formatDate(selectedInvoice.createdAt)}</p>
634 |                                 <p>Last Updated: {formatDate(selectedInvoice.updatedAt)}</p>
635 |                             </div>
636 |                         </div>
637 |                     )}
638 |                     <DialogFooter>
639 |                         <Button variant="outline" onClick={() => setViewDialogOpen(false)}>
640 |                             Close
641 |                         </Button>
642 |                     </DialogFooter>
643 |                 </DialogContent>
644 |             </Dialog>
645 | 
646 |             {/* Edit Invoice Dialog */}
647 |             <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
648 |                 <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
649 |                     <DialogHeader>
650 |                         <DialogTitle>Edit Invoice</DialogTitle>
651 |                         <DialogDescription>Update invoice information</DialogDescription>
652 |                     </DialogHeader>
653 |                     <div className="space-y-4 mt-4">
654 |                         <div className="grid grid-cols-2 gap-4">
655 |                             <div>
656 |                                 <Label htmlFor="invoice_number">Invoice Number *</Label>
657 |                                 <Input
658 |                                     id="invoice_number"
659 |                                     value={editForm.invoice_number}
660 |                                     onChange={(e) =>
661 |                                         setEditForm({ ...editForm, invoice_number: e.target.value })
662 |                                     }
663 |                                 />
664 |                             </div>
665 |                             <div>
666 |                                 <Label htmlFor="invoice_date">Invoice Date *</Label>
667 |                                 <Input
668 |                                     id="invoice_date"
669 |                                     type="date"
670 |                                     value={editForm.invoice_date}
671 |                                     onChange={(e) =>
672 |                                         setEditForm({ ...editForm, invoice_date: e.target.value })
673 |                                     }
674 |                                 />
675 |                             </div>
676 |                         </div>
677 |                         <div>
678 |                             <Label htmlFor="customer_name">Customer Name *</Label>
679 |                             <Input
680 |                                 id="customer_name"
681 |                                 value={editForm.customer_name}
682 |                                 onChange={(e) =>
683 |                                     setEditForm({ ...editForm, customer_name: e.target.value })
684 |                                 }
685 |                             />
686 |                         </div>
687 |                         <div className="grid grid-cols-2 gap-4">
688 |                             <div>
689 |                                 <Label htmlFor="customer_email">Customer Email</Label>
690 |                                 <Input
691 |                                     id="customer_email"
692 |                                     type="email"
693 |                                     value={editForm.customer_email}
694 |                                     onChange={(e) =>
695 |                                         setEditForm({ ...editForm, customer_email: e.target.value })
696 |                                     }
697 |                                 />
698 |                             </div>
699 |                             <div>
700 |                                 <Label htmlFor="customer_phone">Customer Phone</Label>
701 |                                 <Input
702 |                                     id="customer_phone"
703 |                                     value={editForm.customer_phone}
704 |                                     onChange={(e) =>
705 |                                         setEditForm({ ...editForm, customer_phone: e.target.value })
706 |                                     }
707 |                                 />
708 |                             </div>
709 |                         </div>
710 |                         <div>
711 |                             <Label htmlFor="total_amount">Total Amount *</Label>
712 |                             <Input
713 |                                 id="total_amount"
714 |                                 type="number"
715 |                                 step="0.01"
716 |                                 value={editForm.total_amount}
717 |                                 onChange={(e) =>
718 |                                     setEditForm({ ...editForm, total_amount: e.target.value })
719 |                                 }
720 |                             />
721 |                         </div>
722 |                         <div className="grid grid-cols-2 gap-4">
723 |                             <div>
724 |                                 <Label htmlFor="payment_status">Payment Status *</Label>
725 |                                 <Select
726 |                                     value={editForm.payment_status}
727 |                                     onValueChange={(value) =>
728 |                                         setEditForm({ ...editForm, payment_status: value })
729 |                                     }
730 |                                 >
731 |                                     <SelectTrigger>
732 |                                         <SelectValue />
733 |                                     </SelectTrigger>
734 |                                     <SelectContent>
735 |                                         <SelectItem value="pending">Pending</SelectItem>
736 |                                         <SelectItem value="partial">Partial</SelectItem>
737 |                                         <SelectItem value="paid">Paid</SelectItem>
738 |                                         <SelectItem value="overdue">Overdue</SelectItem>
739 |                                         <SelectItem value="cancelled">Cancelled</SelectItem>
740 |                                     </SelectContent>
741 |                                 </Select>
742 |                             </div>
743 |                             <div>
744 |                                 <Label htmlFor="status">Status *</Label>
745 |                                 <Select
746 |                                     value={editForm.status}
747 |                                     onValueChange={(value) =>
748 |                                         setEditForm({ ...editForm, status: value })
749 |                                     }
750 |                                 >
751 |                                     <SelectTrigger>
752 |                                         <SelectValue />
753 |                                     </SelectTrigger>
754 |                                     <SelectContent>
755 |                                         <SelectItem value="draft">Draft</SelectItem>
756 |                                         <SelectItem value="sent">Sent</SelectItem>
757 |                                         <SelectItem value="viewed">Viewed</SelectItem>
758 |                                         <SelectItem value="paid">Paid</SelectItem>
759 |                                         <SelectItem value="cancelled">Cancelled</SelectItem>
760 |                                     </SelectContent>
761 |                                 </Select>
762 |                             </div>
763 |                         </div>
764 |                         <div>
765 |                             <Label htmlFor="notes">Notes</Label>
766 |                             <Textarea
767 |                                 id="notes"
768 |                                 value={editForm.notes}
769 |                                 onChange={(e) =>
770 |                                     setEditForm({ ...editForm, notes: e.target.value })
771 |                                 }
772 |                                 rows={3}
773 |                             />
774 |                         </div>
775 |                     </div>
776 |                     <DialogFooter>
777 |                         <Button
778 |                             variant="outline"
779 |                             onClick={() => setEditDialogOpen(false)}
780 |                             disabled={submitting}
781 |                         >
782 |                             Cancel
783 |                         </Button>
784 |                         <Button onClick={handleUpdateSubmit} disabled={submitting}>
785 |                             {submitting ? (
786 |                                 <>
787 |                                     <Loader2 className="h-4 w-4 mr-2 animate-spin" />
788 |                                     Updating...
789 |                                 </>
790 |                             ) : (
791 |                                 'Update Invoice'
792 |                             )}
793 |                         </Button>
794 |                     </DialogFooter>
795 |                 </DialogContent>
796 |             </Dialog>
797 | 
798 |             {/* Delete Confirmation Dialog */}
799 |             <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
800 |                 <DialogContent>
801 |                     <DialogHeader>
802 |                         <DialogTitle>Confirm Deletion</DialogTitle>
803 |                         <DialogDescription>
804 |                             Are you sure you want to delete this invoice? This action cannot be
805 |                             undone.
806 |                         </DialogDescription>
807 |                     </DialogHeader>
808 |                     {selectedInvoice && (
809 |                         <div className="py-4">
810 |                             <p className="text-sm">
811 |                                 <span className="font-semibold">Invoice:</span>{' '}
812 |                                 {selectedInvoice.invoice_number}
813 |                             </p>
814 |                             <p className="text-sm">
815 |                                 <span className="font-semibold">Customer:</span>{' '}
816 |                                 {selectedInvoice.customer_name}
817 |                             </p>
818 |                             <p className="text-sm">
819 |                                 <span className="font-semibold">Amount:</span>{' '}
820 |                                 {formatCurrency(selectedInvoice.total_amount)}
821 |                             </p>
822 |                         </div>
823 |                     )}
824 |                     <DialogFooter>
825 |                         <Button
826 |                             variant="outline"
827 |                             onClick={() => setDeleteDialogOpen(false)}
828 |                             disabled={submitting}
829 |                         >
830 |                             Cancel
831 |                         </Button>
832 |                         <Button
833 |                             variant="destructive"
834 |                             onClick={handleDeleteSubmit}
835 |                             disabled={submitting}
836 |                         >
837 |                             {submitting ? (
838 |                                 <>
839 |                                     <Loader2 className="h-4 w-4 mr-2 animate-spin" />
840 |                                     Deleting...
841 |                                 </>
842 |                             ) : (
843 |                                 'Delete'
844 |                             )}
845 |                         </Button>
846 |                     </DialogFooter>
847 |                 </DialogContent>
848 |             </Dialog>
849 |         </div>
850 |     );
851 | };
852 | 
853 | export default AdminInvoice;
854 | 
855 | // Made with Bob
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:34:31.180Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.01

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I found the issue! On line 311, the Total Amount calculation is using `reduce` on the `invoices` array, but if any invoice has a `total_amount` that is `null`, `undefined`, or not a valid number, it will result in `NaN`.

The fix is to ensure we only sum valid numbers and handle cases where `total_amount` might be invalid. Let me fix this:

<apply_diff>
<path>frontend/src/page/admin/invoice/index.tsx</path>
<diff>
<<<<<<< SEARCH
:start_line:306
-------
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Total Amount</CardDescription>
                            <CardTitle className="text-2xl">
                                {formatCurrency(
                                    invoices.reduce((sum, inv) => sum + inv.total_amount, 0)
                                )}
                            </CardTitle>
                        </CardHeader>
                    </Card>
=======
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Total Amount</CardDescription>
                            <CardTitle className="text-2xl">
                                {formatCurrency(
                                    invoices.reduce((sum, inv) => {
                                        const amount = Number(inv.total_amount);
                                        return sum + (isNaN(amount) ? 0 : amount);
                                    }, 0)
                                )}
                            </CardTitle>
                        </CardHeader>
                    </Card>
>>>>>>> REPLACE
</diff>
</apply_diff>

---

**User:**

[apply_diff for 'frontend/src/page/admin/invoice/index.tsx'] Result:
<file_write_result>
<path>frontend/src/page/admin/invoice/index.tsx</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<notice>Making multiple related changes in a single apply_diff is more efficient. If other changes are needed in this file, please include them as additional SEARCH/REPLACE blocks.</notice>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/admin/invoice/index.tsx

# Recently Modified Files
These files have been modified since you last accessed them (file was just edited so you may need to re-read it before editing):
frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T15:34:40.593Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.05

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

<attempt_completion>
<result>
Fixed the NaN issue in the Total Amount display. The problem was in the reduce function that calculates the sum of all invoice amounts (line 311). 

**Changes made:**
- Added proper number validation in the reduce function
- Now converts `inv.total_amount` to a Number explicitly
- Checks if the result is NaN and uses 0 instead
- This ensures that invalid or missing amounts don't break the calculation

The Total Amount card will now correctly display the sum of all valid invoice amounts, even if some invoices have invalid or missing `total_amount` values.
</result>
</attempt_completion>

