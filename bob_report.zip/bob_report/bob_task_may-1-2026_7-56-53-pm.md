**User:**

<task>
'frontend/' (see below for folder content)  configure the prettier and eslint in the frontend project
</task>

<folder_content path="frontend/">
├── .gitignore
├── .yarn/
├── .yarnrc.yml
├── README.md
├── eslint.config.js
├── index.html
├── node_modules/
├── package.json
├── public/
├── src/
├── tsconfig.app.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
└── yarn.lock

<file_content path="frontend/.gitignore">
 1 | # Logs
 2 | logs
 3 | *.log
 4 | npm-debug.log*
 5 | yarn-debug.log*
 6 | yarn-error.log*
 7 | pnpm-debug.log*
 8 | lerna-debug.log*
 9 | 
10 | node_modules
11 | dist
12 | dist-ssr
13 | *.local
14 | 
15 | # Editor directories and files
16 | .vscode/*
17 | !.vscode/extensions.json
18 | .idea
19 | .DS_Store
20 | *.suo
21 | *.ntvs*
22 | *.njsproj
23 | *.sln
24 | *.sw?

</file_content>

<file_content path="frontend/.yarnrc.yml">
1 | nodeLinker: "node-modules"

</file_content>

<file_content path="frontend/README.md">
 1 | # React + TypeScript + Vite
 2 | 
 3 | This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.
 4 | 
 5 | Currently, two official plugins are available:
 6 | 
 7 | - [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
 8 | - [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)
 9 | 
10 | ## React Compiler
11 | 
12 | The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).
13 | 
14 | ## Expanding the ESLint configuration
15 | 
16 | If you are developing a production application, we recommend updating the configuration to enable type-aware lint rules:
17 | 
18 | ```js
19 | export default defineConfig([
20 |   globalIgnores(['dist']),
21 |   {
22 |     files: ['**/*.{ts,tsx}'],
23 |     extends: [
24 |       // Other configs...
25 | 
26 |       // Remove tseslint.configs.recommended and replace with this
27 |       tseslint.configs.recommendedTypeChecked,
28 |       // Alternatively, use this for stricter rules
29 |       tseslint.configs.strictTypeChecked,
30 |       // Optionally, add this for stylistic rules
31 |       tseslint.configs.stylisticTypeChecked,
32 | 
33 |       // Other configs...
34 |     ],
35 |     languageOptions: {
36 |       parserOptions: {
37 |         project: ['./tsconfig.node.json', './tsconfig.app.json'],
38 |         tsconfigRootDir: import.meta.dirname,
39 |       },
40 |       // other options...
41 |     },
42 |   },
43 | ])
44 | ```
45 | 
46 | You can also install [eslint-plugin-react-x](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-x) and [eslint-plugin-react-dom](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-dom) for React-specific lint rules:
47 | 
48 | ```js
49 | // eslint.config.js
50 | import reactX from 'eslint-plugin-react-x'
51 | import reactDom from 'eslint-plugin-react-dom'
52 | 
53 | export default defineConfig([
54 |   globalIgnores(['dist']),
55 |   {
56 |     files: ['**/*.{ts,tsx}'],
57 |     extends: [
58 |       // Other configs...
59 |       // Enable lint rules for React
60 |       reactX.configs['recommended-typescript'],
61 |       // Enable lint rules for React DOM
62 |       reactDom.configs.recommended,
63 |     ],
64 |     languageOptions: {
65 |       parserOptions: {
66 |         project: ['./tsconfig.node.json', './tsconfig.app.json'],
67 |         tsconfigRootDir: import.meta.dirname,
68 |       },
69 |       // other options...
70 |     },
71 |   },
72 | ])
73 | ```

</file_content>

<file_content path="frontend/eslint.config.js">
 1 | import js from '@eslint/js'
 2 | import globals from 'globals'
 3 | import reactHooks from 'eslint-plugin-react-hooks'
 4 | import reactRefresh from 'eslint-plugin-react-refresh'
 5 | import tseslint from 'typescript-eslint'
 6 | import { defineConfig, globalIgnores } from 'eslint/config'
 7 | 
 8 | export default defineConfig([
 9 |   globalIgnores(['dist']),
10 |   {
11 |     files: ['**/*.{ts,tsx}'],
12 |     extends: [
13 |       js.configs.recommended,
14 |       tseslint.configs.recommended,
15 |       reactHooks.configs.flat.recommended,
16 |       reactRefresh.configs.vite,
17 |     ],
18 |     languageOptions: {
19 |       globals: globals.browser,
20 |     },
21 |   },
22 | ])

</file_content>

<file_content path="frontend/index.html">
 1 | <!doctype html>
 2 | <html lang="en">
 3 |   <head>
 4 |     <meta charset="UTF-8" />
 5 |     <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
 6 |     <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 7 |     <title>frontend</title>
 8 |   </head>
 9 |   <body>
10 |     <div id="root"></div>
11 |     <script type="module" src="/src/main.tsx"></script>
12 |   </body>
13 | </html>

</file_content>

<file_content path="frontend/package.json">
 1 | {
 2 |   "name": "frontend",
 3 |   "private": true,
 4 |   "version": "0.0.0",
 5 |   "type": "module",
 6 |   "scripts": {
 7 |     "dev": "vite",
 8 |     "build": "tsc -b && vite build",
 9 |     "lint": "eslint .",
10 |     "preview": "vite preview"
11 |   },
12 |   "dependencies": {
13 |     "react": "^19.2.5",
14 |     "react-dom": "^19.2.5"
15 |   },
16 |   "devDependencies": {
17 |     "@eslint/js": "^10.0.1",
18 |     "@types/node": "^24.12.2",
19 |     "@types/react": "^19.2.14",
20 |     "@types/react-dom": "^19.2.3",
21 |     "@vitejs/plugin-react": "^6.0.1",
22 |     "eslint": "^10.2.1",
23 |     "eslint-plugin-react-hooks": "^7.1.1",
24 |     "eslint-plugin-react-refresh": "^0.5.2",
25 |     "globals": "^17.5.0",
26 |     "typescript": "~6.0.2",
27 |     "typescript-eslint": "^8.58.2",
28 |     "vite": "^8.0.10"
29 |   }
30 | }

</file_content>

<file_content path="frontend/tsconfig.app.json">
 1 | {
 2 |   "compilerOptions": {
 3 |     "tsBuildInfoFile": "./node_modules/.tmp/tsconfig.app.tsbuildinfo",
 4 |     "target": "es2023",
 5 |     "lib": ["ES2023", "DOM"],
 6 |     "module": "esnext",
 7 |     "types": ["vite/client"],
 8 |     "skipLibCheck": true,
 9 | 
10 |     /* Bundler mode */
11 |     "moduleResolution": "bundler",
12 |     "allowImportingTsExtensions": true,
13 |     "verbatimModuleSyntax": true,
14 |     "moduleDetection": "force",
15 |     "noEmit": true,
16 |     "jsx": "react-jsx",
17 | 
18 |     /* Linting */
19 |     "noUnusedLocals": true,
20 |     "noUnusedParameters": true,
21 |     "erasableSyntaxOnly": true,
22 |     "noFallthroughCasesInSwitch": true
23 |   },
24 |   "include": ["src"]
25 | }

</file_content>

<file_content path="frontend/tsconfig.json">
1 | {
2 |   "files": [],
3 |   "references": [
4 |     { "path": "./tsconfig.app.json" },
5 |     { "path": "./tsconfig.node.json" }
6 |   ]
7 | }

</file_content>

<file_content path="frontend/tsconfig.node.json">
 1 | {
 2 |   "compilerOptions": {
 3 |     "tsBuildInfoFile": "./node_modules/.tmp/tsconfig.node.tsbuildinfo",
 4 |     "target": "es2023",
 5 |     "lib": ["ES2023"],
 6 |     "module": "esnext",
 7 |     "types": ["node"],
 8 |     "skipLibCheck": true,
 9 | 
10 |     /* Bundler mode */
11 |     "moduleResolution": "bundler",
12 |     "allowImportingTsExtensions": true,
13 |     "verbatimModuleSyntax": true,
14 |     "moduleDetection": "force",
15 |     "noEmit": true,
16 | 
17 |     /* Linting */
18 |     "noUnusedLocals": true,
19 |     "noUnusedParameters": true,
20 |     "erasableSyntaxOnly": true,
21 |     "noFallthroughCasesInSwitch": true
22 |   },
23 |   "include": ["vite.config.ts"]
24 | }

</file_content>

<file_content path="frontend/vite.config.ts">
1 | import { defineConfig } from 'vite'
2 | import react from '@vitejs/plugin-react'
3 | 
4 | // https://vite.dev/config/
5 | export default defineConfig({
6 |   plugins: [react()],
7 | })

</file_content>

<file_content path="frontend/yarn.lock">
   1 | # This file is generated by running "yarn install" inside your project.
   2 | # Manual changes might be lost - proceed with caution!
   3 | 
   4 | __metadata:
   5 |   version: 8
   6 |   cacheKey: 10c0
   7 | 
   8 | "@babel/code-frame@npm:^7.28.6, @babel/code-frame@npm:^7.29.0":
   9 |   version: 7.29.0
  10 |   resolution: "@babel/code-frame@npm:7.29.0"
  11 |   dependencies:
  12 |     "@babel/helper-validator-identifier": "npm:^7.28.5"
  13 |     js-tokens: "npm:^4.0.0"
  14 |     picocolors: "npm:^1.1.1"
  15 |   checksum: 10c0/d34cc504e7765dfb576a663d97067afb614525806b5cad1a5cc1a7183b916fec8ff57fa233585e3926fd5a9e6b31aae6df91aa81ae9775fb7a28f658d3346f0d
  16 |   languageName: node
  17 |   linkType: hard
  18 | 
  19 | "@babel/compat-data@npm:^7.28.6":
  20 |   version: 7.29.3
  21 |   resolution: "@babel/compat-data@npm:7.29.3"
  22 |   checksum: 10c0/81bddd53ce1b1395576fbb7cb739631a976f6b421cd260e6cf2715a9691b9a0ec12ca5c4e1bb88088e60dc87875f6e4ef7fa8674f1dc96ae1bd7c357416605a7
  23 |   languageName: node
  24 |   linkType: hard
  25 | 
  26 | "@babel/core@npm:^7.24.4":
  27 |   version: 7.29.0
  28 |   resolution: "@babel/core@npm:7.29.0"
  29 |   dependencies:
  30 |     "@babel/code-frame": "npm:^7.29.0"
  31 |     "@babel/generator": "npm:^7.29.0"
  32 |     "@babel/helper-compilation-targets": "npm:^7.28.6"
  33 |     "@babel/helper-module-transforms": "npm:^7.28.6"
  34 |     "@babel/helpers": "npm:^7.28.6"
  35 |     "@babel/parser": "npm:^7.29.0"
  36 |     "@babel/template": "npm:^7.28.6"
  37 |     "@babel/traverse": "npm:^7.29.0"
  38 |     "@babel/types": "npm:^7.29.0"
  39 |     "@jridgewell/remapping": "npm:^2.3.5"
  40 |     convert-source-map: "npm:^2.0.0"
  41 |     debug: "npm:^4.1.0"
  42 |     gensync: "npm:^1.0.0-beta.2"
  43 |     json5: "npm:^2.2.3"
  44 |     semver: "npm:^6.3.1"
  45 |   checksum: 10c0/5127d2e8e842ae409e11bcbb5c2dff9874abf5415e8026925af7308e903f4f43397341467a130490d1a39884f461bc2b67f3063bce0be44340db89687fd852aa
  46 |   languageName: node
  47 |   linkType: hard
  48 | 
  49 | "@babel/generator@npm:^7.29.0":
  50 |   version: 7.29.1
  51 |   resolution: "@babel/generator@npm:7.29.1"
  52 |   dependencies:
  53 |     "@babel/parser": "npm:^7.29.0"
  54 |     "@babel/types": "npm:^7.29.0"
  55 |     "@jridgewell/gen-mapping": "npm:^0.3.12"
  56 |     "@jridgewell/trace-mapping": "npm:^0.3.28"
  57 |     jsesc: "npm:^3.0.2"
  58 |   checksum: 10c0/349086e6876258ef3fb2823030fee0f6c0eb9c3ebe35fc572e16997f8c030d765f636ddc6299edae63e760ea6658f8ee9a2edfa6d6b24c9a80c917916b973551
  59 |   languageName: node
  60 |   linkType: hard
  61 | 
  62 | "@babel/helper-compilation-targets@npm:^7.28.6":
  63 |   version: 7.28.6
  64 |   resolution: "@babel/helper-compilation-targets@npm:7.28.6"
  65 |   dependencies:
  66 |     "@babel/compat-data": "npm:^7.28.6"
  67 |     "@babel/helper-validator-option": "npm:^7.27.1"
  68 |     browserslist: "npm:^4.24.0"
  69 |     lru-cache: "npm:^5.1.1"
  70 |     semver: "npm:^6.3.1"
  71 |   checksum: 10c0/3fcdf3b1b857a1578e99d20508859dbd3f22f3c87b8a0f3dc540627b4be539bae7f6e61e49d931542fe5b557545347272bbdacd7f58a5c77025a18b745593a50
  72 |   languageName: node
  73 |   linkType: hard
  74 | 
  75 | "@babel/helper-globals@npm:^7.28.0":
  76 |   version: 7.28.0
  77 |   resolution: "@babel/helper-globals@npm:7.28.0"
  78 |   checksum: 10c0/5a0cd0c0e8c764b5f27f2095e4243e8af6fa145daea2b41b53c0c1414fe6ff139e3640f4e2207ae2b3d2153a1abd346f901c26c290ee7cb3881dd922d4ee9232
  79 |   languageName: node
  80 |   linkType: hard
  81 | 
  82 | "@babel/helper-module-imports@npm:^7.28.6":
  83 |   version: 7.28.6
  84 |   resolution: "@babel/helper-module-imports@npm:7.28.6"
  85 |   dependencies:
  86 |     "@babel/traverse": "npm:^7.28.6"
  87 |     "@babel/types": "npm:^7.28.6"
  88 |   checksum: 10c0/b49d8d8f204d9dbfd5ac70c54e533e5269afb3cea966a9d976722b13e9922cc773a653405f53c89acb247d5aebdae4681d631a3ae3df77ec046b58da76eda2ac
  89 |   languageName: node
  90 |   linkType: hard
  91 | 
  92 | "@babel/helper-module-transforms@npm:^7.28.6":
  93 |   version: 7.28.6
  94 |   resolution: "@babel/helper-module-transforms@npm:7.28.6"
  95 |   dependencies:
  96 |     "@babel/helper-module-imports": "npm:^7.28.6"
  97 |     "@babel/helper-validator-identifier": "npm:^7.28.5"
  98 |     "@babel/traverse": "npm:^7.28.6"
  99 |   peerDependencies:
 100 |     "@babel/core": ^7.0.0
 101 |   checksum: 10c0/6f03e14fc30b287ce0b839474b5f271e72837d0cafe6b172d759184d998fbee3903a035e81e07c2c596449e504f453463d58baa65b6f40a37ded5bec74620b2b
 102 |   languageName: node
 103 |   linkType: hard
 104 | 
 105 | "@babel/helper-string-parser@npm:^7.27.1":
 106 |   version: 7.27.1
 107 |   resolution: "@babel/helper-string-parser@npm:7.27.1"
 108 |   checksum: 10c0/8bda3448e07b5583727c103560bcf9c4c24b3c1051a4c516d4050ef69df37bb9a4734a585fe12725b8c2763de0a265aa1e909b485a4e3270b7cfd3e4dbe4b602
 109 |   languageName: node
 110 |   linkType: hard
 111 | 
 112 | "@babel/helper-validator-identifier@npm:^7.28.5":
 113 |   version: 7.28.5
 114 |   resolution: "@babel/helper-validator-identifier@npm:7.28.5"
 115 |   checksum: 10c0/42aaebed91f739a41f3d80b72752d1f95fd7c72394e8e4bd7cdd88817e0774d80a432451bcba17c2c642c257c483bf1d409dd4548883429ea9493a3bc4ab0847
 116 |   languageName: node
 117 |   linkType: hard
 118 | 
 119 | "@babel/helper-validator-option@npm:^7.27.1":
 120 |   version: 7.27.1
 121 |   resolution: "@babel/helper-validator-option@npm:7.27.1"
 122 |   checksum: 10c0/6fec5f006eba40001a20f26b1ef5dbbda377b7b68c8ad518c05baa9af3f396e780bdfded24c4eef95d14bb7b8fd56192a6ed38d5d439b97d10efc5f1a191d148
 123 |   languageName: node
 124 |   linkType: hard
 125 | 
 126 | "@babel/helpers@npm:^7.28.6":
 127 |   version: 7.29.2
 128 |   resolution: "@babel/helpers@npm:7.29.2"
 129 |   dependencies:
 130 |     "@babel/template": "npm:^7.28.6"
 131 |     "@babel/types": "npm:^7.29.0"
 132 |   checksum: 10c0/dab0e65b9318b2502a62c58bc0913572318595eec0482c31f0ad416b72636e6698a1d7c57cd2791d4528eb8c548bca88d338dc4d2a55a108dc1f6702f9bc5512
 133 |   languageName: node
 134 |   linkType: hard
 135 | 
 136 | "@babel/parser@npm:^7.24.4, @babel/parser@npm:^7.28.6, @babel/parser@npm:^7.29.0":
 137 |   version: 7.29.3
 138 |   resolution: "@babel/parser@npm:7.29.3"
 139 |   dependencies:
 140 |     "@babel/types": "npm:^7.29.0"
 141 |   bin:
 142 |     parser: ./bin/babel-parser.js
 143 |   checksum: 10c0/f06920c819550c0db689e4c5b626bf55ba3cebf80ebe9ccfa434e134036cf3de50951fe759f74abb2dae381989239860bde46d4600328578ad1f7114c3711a6d
 144 |   languageName: node
 145 |   linkType: hard
 146 | 
 147 | "@babel/template@npm:^7.28.6":
 148 |   version: 7.28.6
 149 |   resolution: "@babel/template@npm:7.28.6"
 150 |   dependencies:
 151 |     "@babel/code-frame": "npm:^7.28.6"
 152 |     "@babel/parser": "npm:^7.28.6"
 153 |     "@babel/types": "npm:^7.28.6"
 154 |   checksum: 10c0/66d87225ed0bc77f888181ae2d97845021838c619944877f7c4398c6748bcf611f216dfd6be74d39016af502bca876e6ce6873db3c49e4ac354c56d34d57e9f5
 155 |   languageName: node
 156 |   linkType: hard
 157 | 
 158 | "@babel/traverse@npm:^7.28.6, @babel/traverse@npm:^7.29.0":
 159 |   version: 7.29.0
 160 |   resolution: "@babel/traverse@npm:7.29.0"
 161 |   dependencies:
 162 |     "@babel/code-frame": "npm:^7.29.0"
 163 |     "@babel/generator": "npm:^7.29.0"
 164 |     "@babel/helper-globals": "npm:^7.28.0"
 165 |     "@babel/parser": "npm:^7.29.0"
 166 |     "@babel/template": "npm:^7.28.6"
 167 |     "@babel/types": "npm:^7.29.0"
 168 |     debug: "npm:^4.3.1"
 169 |   checksum: 10c0/f63ef6e58d02a9fbf3c0e2e5f1c877da3e0bc57f91a19d2223d53e356a76859cbaf51171c9211c71816d94a0e69efa2732fd27ffc0e1bbc84b636e60932333eb
 170 |   languageName: node
 171 |   linkType: hard
 172 | 
 173 | "@babel/types@npm:^7.28.6, @babel/types@npm:^7.29.0":
 174 |   version: 7.29.0
 175 |   resolution: "@babel/types@npm:7.29.0"
 176 |   dependencies:
 177 |     "@babel/helper-string-parser": "npm:^7.27.1"
 178 |     "@babel/helper-validator-identifier": "npm:^7.28.5"
 179 |   checksum: 10c0/23cc3466e83bcbfab8b9bd0edaafdb5d4efdb88b82b3be6728bbade5ba2f0996f84f63b1c5f7a8c0d67efded28300898a5f930b171bb40b311bca2029c4e9b4f
 180 |   languageName: node
 181 |   linkType: hard
 182 | 
 183 | "@emnapi/core@npm:1.10.0":
 184 |   version: 1.10.0
 185 |   resolution: "@emnapi/core@npm:1.10.0"
 186 |   dependencies:
 187 |     "@emnapi/wasi-threads": "npm:1.2.1"
 188 |     tslib: "npm:^2.4.0"
 189 |   checksum: 10c0/f51d08227857b60632de7714d708124f0e100a1462dde6df8221760939aa3204a73193830371830fac0716f3ccd2129f2cac1b17cd7d7958bc4da9018a296edb
 190 |   languageName: node
 191 |   linkType: hard
 192 | 
 193 | "@emnapi/runtime@npm:1.10.0":
 194 |   version: 1.10.0
 195 |   resolution: "@emnapi/runtime@npm:1.10.0"
 196 |   dependencies:
 197 |     tslib: "npm:^2.4.0"
 198 |   checksum: 10c0/953f14991d1aefb92ee6f8eb27dea725e484791a53a0cb5f47d9e0087b9a2c929ff2e92adf95af15d6ad456db6300c6b761ebf72b50a875b874a83520b3ba093
 199 |   languageName: node
 200 |   linkType: hard
 201 | 
 202 | "@emnapi/wasi-threads@npm:1.2.1":
 203 |   version: 1.2.1
 204 |   resolution: "@emnapi/wasi-threads@npm:1.2.1"
 205 |   dependencies:
 206 |     tslib: "npm:^2.4.0"
 207 |   checksum: 10c0/32fcfa81ab396533b2ec1f4082b1ff779a05d9c836bbbd3f4398405b0e6814c0d9503b7993130e37bc6941dbc1ded49f55e9700ae9ca4e803bab2b5bc5deb331
 208 |   languageName: node
 209 |   linkType: hard
 210 | 
 211 | "@eslint-community/eslint-utils@npm:^4.8.0, @eslint-community/eslint-utils@npm:^4.9.1":
 212 |   version: 4.9.1
 213 |   resolution: "@eslint-community/eslint-utils@npm:4.9.1"
 214 |   dependencies:
 215 |     eslint-visitor-keys: "npm:^3.4.3"
 216 |   peerDependencies:
 217 |     eslint: ^6.0.0 || ^7.0.0 || >=8.0.0
 218 |   checksum: 10c0/dc4ab5e3e364ef27e33666b11f4b86e1a6c1d7cbf16f0c6ff87b1619b3562335e9201a3d6ce806221887ff780ec9d828962a290bb910759fd40a674686503f02
 219 |   languageName: node
 220 |   linkType: hard
 221 | 
 222 | "@eslint-community/regexpp@npm:^4.12.2":
 223 |   version: 4.12.2
 224 |   resolution: "@eslint-community/regexpp@npm:4.12.2"
 225 |   checksum: 10c0/fddcbc66851b308478d04e302a4d771d6917a0b3740dc351513c0da9ca2eab8a1adf99f5e0aa7ab8b13fa0df005c81adeee7e63a92f3effd7d367a163b721c2d
 226 |   languageName: node
 227 |   linkType: hard
 228 | 
 229 | "@eslint/config-array@npm:^0.23.5":
 230 |   version: 0.23.5
 231 |   resolution: "@eslint/config-array@npm:0.23.5"
 232 |   dependencies:
 233 |     "@eslint/object-schema": "npm:^3.0.5"
 234 |     debug: "npm:^4.3.1"
 235 |     minimatch: "npm:^10.2.4"
 236 |   checksum: 10c0/b24833c4c76e78ee075d306cd3f095db46b2db0f90cc13a6ee6e4275f9889731c05bf5403ab5fefb79c756e07ac9184ed0e04570341382f9eccbccc80e6d1a0c
 237 |   languageName: node
 238 |   linkType: hard
 239 | 
 240 | "@eslint/config-helpers@npm:^0.5.5":
 241 |   version: 0.5.5
 242 |   resolution: "@eslint/config-helpers@npm:0.5.5"
 243 |   dependencies:
 244 |     "@eslint/core": "npm:^1.2.1"
 245 |   checksum: 10c0/18889c062cd6bdbd4cd92fe57318c44465ea66184aa0ba204a4420712c66764c64093a7905b6c2ffde23e51b268ca2cec1a39c605d336bebf17ee1ba4f0fc0bb
 246 |   languageName: node
 247 |   linkType: hard
 248 | 
 249 | "@eslint/core@npm:^1.2.1":
 250 |   version: 1.2.1
 251 |   resolution: "@eslint/core@npm:1.2.1"
 252 |   dependencies:
 253 |     "@types/json-schema": "npm:^7.0.15"
 254 |   checksum: 10c0/10979b40588ecfef771fcb5013a542a35fb30692cc95a65f3481b0b36fbd89f5679efeb30d57f4eed35203d859aabace2a620177d6c536f71b299a1af2f3398f
 255 |   languageName: node
 256 |   linkType: hard
 257 | 
 258 | "@eslint/js@npm:^10.0.1":
 259 |   version: 10.0.1
 260 |   resolution: "@eslint/js@npm:10.0.1"
 261 |   peerDependencies:
 262 |     eslint: ^10.0.0
 263 |   peerDependenciesMeta:
 264 |     eslint:
 265 |       optional: true
 266 |   checksum: 10c0/9f3fcaf71ba7fdf65d82e8faad6ecfe97e11801cc3c362b306a88ea1ed1344ae0d35330dddb0e8ad18f010f6687a70b75491b9e01c8af57acd7987cee6b3ec6c
 267 |   languageName: node
 268 |   linkType: hard
 269 | 
 270 | "@eslint/object-schema@npm:^3.0.5":
 271 |   version: 3.0.5
 272 |   resolution: "@eslint/object-schema@npm:3.0.5"
 273 |   checksum: 10c0/1db337431f520b99e9edda64ef5fafd7ec6a029843eeb608753025125b6649d861d843cffafafd3c4e37926d7d5f9ec0c6a8e3665c13c3da2144e8132892e92e
 274 |   languageName: node
 275 |   linkType: hard
 276 | 
 277 | "@eslint/plugin-kit@npm:^0.7.1":
 278 |   version: 0.7.1
 279 |   resolution: "@eslint/plugin-kit@npm:0.7.1"
 280 |   dependencies:
 281 |     "@eslint/core": "npm:^1.2.1"
 282 |     levn: "npm:^0.4.1"
 283 |   checksum: 10c0/335b0c1c46fd906cb50bd5ce442b9cee18dc44342ce35c718ba4a63d1aa51d2797f16a517b2f4fe371ccd777b6862fafb2dc8195e00e69197ef4cb17ab32c01b
 284 |   languageName: node
 285 |   linkType: hard
 286 | 
 287 | "@humanfs/core@npm:^0.19.2":
 288 |   version: 0.19.2
 289 |   resolution: "@humanfs/core@npm:0.19.2"
 290 |   dependencies:
 291 |     "@humanfs/types": "npm:^0.15.0"
 292 |   checksum: 10c0/d0a1d52d7b30c27d49475a53072d1510b81c5803e44b342fb8faf3887f1aa27593a1e6dc76a45268e7892d3f4e198146659281f6b6d55eacf3fd5a38bac30c5c
 293 |   languageName: node
 294 |   linkType: hard
 295 | 
 296 | "@humanfs/node@npm:^0.16.6":
 297 |   version: 0.16.8
 298 |   resolution: "@humanfs/node@npm:0.16.8"
 299 |   dependencies:
 300 |     "@humanfs/core": "npm:^0.19.2"
 301 |     "@humanfs/types": "npm:^0.15.0"
 302 |     "@humanwhocodes/retry": "npm:^0.4.0"
 303 |   checksum: 10c0/56140579db811af4e160b195d45d0f29acf644d192c93fe24c9e594ebf06f19dfc157494a07c84540b8a071c0e4b37209c2362765d31734f4d0be869c2422e25
 304 |   languageName: node
 305 |   linkType: hard
 306 | 
 307 | "@humanfs/types@npm:^0.15.0":
 308 |   version: 0.15.0
 309 |   resolution: "@humanfs/types@npm:0.15.0"
 310 |   checksum: 10c0/fc26b9a024b0e55f7eaf64036df94345bf5d36d6a41ef80ef38e78f1f7430ce26cf435af736adae58913baae18eac3f38c18739054a3d379102015978eae862e
 311 |   languageName: node
 312 |   linkType: hard
 313 | 
 314 | "@humanwhocodes/module-importer@npm:^1.0.1":
 315 |   version: 1.0.1
 316 |   resolution: "@humanwhocodes/module-importer@npm:1.0.1"
 317 |   checksum: 10c0/909b69c3b86d482c26b3359db16e46a32e0fb30bd306a3c176b8313b9e7313dba0f37f519de6aa8b0a1921349e505f259d19475e123182416a506d7f87e7f529
 318 |   languageName: node
 319 |   linkType: hard
 320 | 
 321 | "@humanwhocodes/retry@npm:^0.4.0, @humanwhocodes/retry@npm:^0.4.2":
 322 |   version: 0.4.3
 323 |   resolution: "@humanwhocodes/retry@npm:0.4.3"
 324 |   checksum: 10c0/3775bb30087d4440b3f7406d5a057777d90e4b9f435af488a4923ef249e93615fb78565a85f173a186a076c7706a81d0d57d563a2624e4de2c5c9c66c486ce42
 325 |   languageName: node
 326 |   linkType: hard
 327 | 
 328 | "@isaacs/fs-minipass@npm:^4.0.0":
 329 |   version: 4.0.1
 330 |   resolution: "@isaacs/fs-minipass@npm:4.0.1"
 331 |   dependencies:
 332 |     minipass: "npm:^7.0.4"
 333 |   checksum: 10c0/c25b6dc1598790d5b55c0947a9b7d111cfa92594db5296c3b907e2f533c033666f692a3939eadac17b1c7c40d362d0b0635dc874cbfe3e70db7c2b07cc97a5d2
 334 |   languageName: node
 335 |   linkType: hard
 336 | 
 337 | "@jridgewell/gen-mapping@npm:^0.3.12, @jridgewell/gen-mapping@npm:^0.3.5":
 338 |   version: 0.3.13
 339 |   resolution: "@jridgewell/gen-mapping@npm:0.3.13"
 340 |   dependencies:
 341 |     "@jridgewell/sourcemap-codec": "npm:^1.5.0"
 342 |     "@jridgewell/trace-mapping": "npm:^0.3.24"
 343 |   checksum: 10c0/9a7d65fb13bd9aec1fbab74cda08496839b7e2ceb31f5ab922b323e94d7c481ce0fc4fd7e12e2610915ed8af51178bdc61e168e92a8c8b8303b030b03489b13b
 344 |   languageName: node
 345 |   linkType: hard
 346 | 
 347 | "@jridgewell/remapping@npm:^2.3.5":
 348 |   version: 2.3.5
 349 |   resolution: "@jridgewell/remapping@npm:2.3.5"
 350 |   dependencies:
 351 |     "@jridgewell/gen-mapping": "npm:^0.3.5"
 352 |     "@jridgewell/trace-mapping": "npm:^0.3.24"
 353 |   checksum: 10c0/3de494219ffeb2c5c38711d0d7bb128097edf91893090a2dbc8ee0b55d092bb7347b1fd0f478486c5eab010e855c73927b1666f2107516d472d24a73017d1194
 354 |   languageName: node
 355 |   linkType: hard
 356 | 
 357 | "@jridgewell/resolve-uri@npm:^3.1.0":
 358 |   version: 3.1.2
 359 |   resolution: "@jridgewell/resolve-uri@npm:3.1.2"
 360 |   checksum: 10c0/d502e6fb516b35032331406d4e962c21fe77cdf1cbdb49c6142bcbd9e30507094b18972778a6e27cbad756209cfe34b1a27729e6fa08a2eb92b33943f680cf1e
 361 |   languageName: node
 362 |   linkType: hard
 363 | 
 364 | "@jridgewell/sourcemap-codec@npm:^1.4.14, @jridgewell/sourcemap-codec@npm:^1.5.0":
 365 |   version: 1.5.5
 366 |   resolution: "@jridgewell/sourcemap-codec@npm:1.5.5"
 367 |   checksum: 10c0/f9e538f302b63c0ebc06eecb1dd9918dd4289ed36147a0ddce35d6ea4d7ebbda243cda7b2213b6a5e1d8087a298d5cf630fb2bd39329cdecb82017023f6081a0
 368 |   languageName: node
 369 |   linkType: hard
 370 | 
 371 | "@jridgewell/trace-mapping@npm:^0.3.24, @jridgewell/trace-mapping@npm:^0.3.28":
 372 |   version: 0.3.31
 373 |   resolution: "@jridgewell/trace-mapping@npm:0.3.31"
 374 |   dependencies:
 375 |     "@jridgewell/resolve-uri": "npm:^3.1.0"
 376 |     "@jridgewell/sourcemap-codec": "npm:^1.4.14"
 377 |   checksum: 10c0/4b30ec8cd56c5fd9a661f088230af01e0c1a3888d11ffb6b47639700f71225be21d1f7e168048d6d4f9449207b978a235c07c8f15c07705685d16dc06280e9d9
 378 |   languageName: node
 379 |   linkType: hard
 380 | 
 381 | "@napi-rs/wasm-runtime@npm:^1.1.4":
 382 |   version: 1.1.4
 383 |   resolution: "@napi-rs/wasm-runtime@npm:1.1.4"
 384 |   dependencies:
 385 |     "@tybys/wasm-util": "npm:^0.10.1"
 386 |   peerDependencies:
 387 |     "@emnapi/core": ^1.7.1
 388 |     "@emnapi/runtime": ^1.7.1
 389 |   checksum: 10c0/2e88e1955258949ccf2d18c79975821ad38071b465ef126a5e14110977b97868867b016c1ad046e963cccc42c0bd9db6c8ff5fd1ebb61b87bb3487f339041658
 390 |   languageName: node
 391 |   linkType: hard
 392 | 
 393 | "@oxc-project/types@npm:=0.127.0":
 394 |   version: 0.127.0
 395 |   resolution: "@oxc-project/types@npm:0.127.0"
 396 |   checksum: 10c0/52c0947ac64a9ca119fe971f947e784a35ecd14a072fa3f542a58a5f6c42010b53f2bf92731e39b9899b83c990a9517bbd29d1e5a5b7b489e52616685c6a9278
 397 |   languageName: node
 398 |   linkType: hard
 399 | 
 400 | "@rolldown/binding-android-arm64@npm:1.0.0-rc.17":
 401 |   version: 1.0.0-rc.17
 402 |   resolution: "@rolldown/binding-android-arm64@npm:1.0.0-rc.17"
 403 |   conditions: os=android & cpu=arm64
 404 |   languageName: node
 405 |   linkType: hard
 406 | 
 407 | "@rolldown/binding-darwin-arm64@npm:1.0.0-rc.17":
 408 |   version: 1.0.0-rc.17
 409 |   resolution: "@rolldown/binding-darwin-arm64@npm:1.0.0-rc.17"
 410 |   conditions: os=darwin & cpu=arm64
 411 |   languageName: node
 412 |   linkType: hard
 413 | 
 414 | "@rolldown/binding-darwin-x64@npm:1.0.0-rc.17":
 415 |   version: 1.0.0-rc.17
 416 |   resolution: "@rolldown/binding-darwin-x64@npm:1.0.0-rc.17"
 417 |   conditions: os=darwin & cpu=x64
 418 |   languageName: node
 419 |   linkType: hard
 420 | 
 421 | "@rolldown/binding-freebsd-x64@npm:1.0.0-rc.17":
 422 |   version: 1.0.0-rc.17
 423 |   resolution: "@rolldown/binding-freebsd-x64@npm:1.0.0-rc.17"
 424 |   conditions: os=freebsd & cpu=x64
 425 |   languageName: node
 426 |   linkType: hard
 427 | 
 428 | "@rolldown/binding-linux-arm-gnueabihf@npm:1.0.0-rc.17":
 429 |   version: 1.0.0-rc.17
 430 |   resolution: "@rolldown/binding-linux-arm-gnueabihf@npm:1.0.0-rc.17"
 431 |   conditions: os=linux & cpu=arm
 432 |   languageName: node
 433 |   linkType: hard
 434 | 
 435 | "@rolldown/binding-linux-arm64-gnu@npm:1.0.0-rc.17":
 436 |   version: 1.0.0-rc.17
 437 |   resolution: "@rolldown/binding-linux-arm64-gnu@npm:1.0.0-rc.17"
 438 |   conditions: os=linux & cpu=arm64 & libc=glibc
 439 |   languageName: node
 440 |   linkType: hard
 441 | 
 442 | "@rolldown/binding-linux-arm64-musl@npm:1.0.0-rc.17":
 443 |   version: 1.0.0-rc.17
 444 |   resolution: "@rolldown/binding-linux-arm64-musl@npm:1.0.0-rc.17"
 445 |   conditions: os=linux & cpu=arm64 & libc=musl
 446 |   languageName: node
 447 |   linkType: hard
 448 | 
 449 | "@rolldown/binding-linux-ppc64-gnu@npm:1.0.0-rc.17":
 450 |   version: 1.0.0-rc.17
 451 |   resolution: "@rolldown/binding-linux-ppc64-gnu@npm:1.0.0-rc.17"
 452 |   conditions: os=linux & cpu=ppc64 & libc=glibc
 453 |   languageName: node
 454 |   linkType: hard
 455 | 
 456 | "@rolldown/binding-linux-s390x-gnu@npm:1.0.0-rc.17":
 457 |   version: 1.0.0-rc.17
 458 |   resolution: "@rolldown/binding-linux-s390x-gnu@npm:1.0.0-rc.17"
 459 |   conditions: os=linux & cpu=s390x & libc=glibc
 460 |   languageName: node
 461 |   linkType: hard
 462 | 
 463 | "@rolldown/binding-linux-x64-gnu@npm:1.0.0-rc.17":
 464 |   version: 1.0.0-rc.17
 465 |   resolution: "@rolldown/binding-linux-x64-gnu@npm:1.0.0-rc.17"
 466 |   conditions: os=linux & cpu=x64 & libc=glibc
 467 |   languageName: node
 468 |   linkType: hard
 469 | 
 470 | "@rolldown/binding-linux-x64-musl@npm:1.0.0-rc.17":
 471 |   version: 1.0.0-rc.17
 472 |   resolution: "@rolldown/binding-linux-x64-musl@npm:1.0.0-rc.17"
 473 |   conditions: os=linux & cpu=x64 & libc=musl
 474 |   languageName: node
 475 |   linkType: hard
 476 | 
 477 | "@rolldown/binding-openharmony-arm64@npm:1.0.0-rc.17":
 478 |   version: 1.0.0-rc.17
 479 |   resolution: "@rolldown/binding-openharmony-arm64@npm:1.0.0-rc.17"
 480 |   conditions: os=openharmony & cpu=arm64
 481 |   languageName: node
 482 |   linkType: hard
 483 | 
 484 | "@rolldown/binding-wasm32-wasi@npm:1.0.0-rc.17":
 485 |   version: 1.0.0-rc.17
 486 |   resolution: "@rolldown/binding-wasm32-wasi@npm:1.0.0-rc.17"
 487 |   dependencies:
 488 |     "@emnapi/core": "npm:1.10.0"
 489 |     "@emnapi/runtime": "npm:1.10.0"
 490 |     "@napi-rs/wasm-runtime": "npm:^1.1.4"
 491 |   conditions: cpu=wasm32
 492 |   languageName: node
 493 |   linkType: hard
 494 | 
 495 | "@rolldown/binding-win32-arm64-msvc@npm:1.0.0-rc.17":
 496 |   version: 1.0.0-rc.17
 497 |   resolution: "@rolldown/binding-win32-arm64-msvc@npm:1.0.0-rc.17"
 498 |   conditions: os=win32 & cpu=arm64
 499 |   languageName: node
 500 |   linkType: hard
 501 | 
 502 | "@rolldown/binding-win32-x64-msvc@npm:1.0.0-rc.17":
 503 |   version: 1.0.0-rc.17
 504 |   resolution: "@rolldown/binding-win32-x64-msvc@npm:1.0.0-rc.17"
 505 |   conditions: os=win32 & cpu=x64
 506 |   languageName: node
 507 |   linkType: hard
 508 | 
 509 | "@rolldown/pluginutils@npm:1.0.0-rc.17":
 510 |   version: 1.0.0-rc.17
 511 |   resolution: "@rolldown/pluginutils@npm:1.0.0-rc.17"
 512 |   checksum: 10c0/5e840b20cc531910c093c1ca36e550952cf4936465a50d89f0a98fc9d0dfd7d319d06a10a5f4376209d89e9bf4d60af6cc8363ebf0dcc5e60842f7fef438b2f0
 513 |   languageName: node
 514 |   linkType: hard
 515 | 
 516 | "@rolldown/pluginutils@npm:1.0.0-rc.7":
 517 |   version: 1.0.0-rc.7
 518 |   resolution: "@rolldown/pluginutils@npm:1.0.0-rc.7"
 519 |   checksum: 10c0/9d5490b5805b25bcd1720ca01c4c032b55a0ef953dab36a8dd42c568e82214576baa464f3027cd5dff3fabcfbe3bf3db2251d12b60220f5d1cd2ffde5ee37082
 520 |   languageName: node
 521 |   linkType: hard
 522 | 
 523 | "@tybys/wasm-util@npm:^0.10.1":
 524 |   version: 0.10.1
 525 |   resolution: "@tybys/wasm-util@npm:0.10.1"
 526 |   dependencies:
 527 |     tslib: "npm:^2.4.0"
 528 |   checksum: 10c0/b255094f293794c6d2289300c5fbcafbb5532a3aed3a5ffd2f8dc1828e639b88d75f6a376dd8f94347a44813fd7a7149d8463477a9a49525c8b2dcaa38c2d1e8
 529 |   languageName: node
 530 |   linkType: hard
 531 | 
 532 | "@types/esrecurse@npm:^4.3.1":
 533 |   version: 4.3.1
 534 |   resolution: "@types/esrecurse@npm:4.3.1"
 535 |   checksum: 10c0/90dad74d5da3ad27606d8e8e757322f33171cfeaa15ad558b615cf71bb2a516492d18f55f4816384685a3eb2412142e732bbae9a4a7cd2cf3deb7572aa4ebe03
 536 |   languageName: node
 537 |   linkType: hard
 538 | 
 539 | "@types/estree@npm:^1.0.6, @types/estree@npm:^1.0.8":
 540 |   version: 1.0.8
 541 |   resolution: "@types/estree@npm:1.0.8"
 542 |   checksum: 10c0/39d34d1afaa338ab9763f37ad6066e3f349444f9052b9676a7cc0252ef9485a41c6d81c9c4e0d26e9077993354edf25efc853f3224dd4b447175ef62bdcc86a5
 543 |   languageName: node
 544 |   linkType: hard
 545 | 
 546 | "@types/json-schema@npm:^7.0.15":
 547 |   version: 7.0.15
 548 |   resolution: "@types/json-schema@npm:7.0.15"
 549 |   checksum: 10c0/a996a745e6c5d60292f36731dd41341339d4eeed8180bb09226e5c8d23759067692b1d88e5d91d72ee83dfc00d3aca8e7bd43ea120516c17922cbcb7c3e252db
 550 |   languageName: node
 551 |   linkType: hard
 552 | 
 553 | "@types/node@npm:^24.12.2":
 554 |   version: 24.12.2
 555 |   resolution: "@types/node@npm:24.12.2"
 556 |   dependencies:
 557 |     undici-types: "npm:~7.16.0"
 558 |   checksum: 10c0/710050c42f89075c4479e4e1e4c2532486b0c41b1e2a8a13ad88641c88b88cdaea87414e19224f30028719737bd70e327edcaa184d50e86b9418941edd7eb02b
 559 |   languageName: node
 560 |   linkType: hard
 561 | 
 562 | "@types/react-dom@npm:^19.2.3":
 563 |   version: 19.2.3
 564 |   resolution: "@types/react-dom@npm:19.2.3"
 565 |   peerDependencies:
 566 |     "@types/react": ^19.2.0
 567 |   checksum: 10c0/b486ebe0f4e2fb35e2e108df1d8fc0927ca5d6002d5771e8a739de11239fe62d0e207c50886185253c99eb9dedfeeb956ea7429e5ba17f6693c7acb4c02f8cd1
 568 |   languageName: node
 569 |   linkType: hard
 570 | 
 571 | "@types/react@npm:^19.2.14":
 572 |   version: 19.2.14
 573 |   resolution: "@types/react@npm:19.2.14"
 574 |   dependencies:
 575 |     csstype: "npm:^3.2.2"
 576 |   checksum: 10c0/7d25bf41b57719452d86d2ac0570b659210402707313a36ee612666bf11275a1c69824f8c3ee1fdca077ccfe15452f6da8f1224529b917050eb2d861e52b59b7
 577 |   languageName: node
 578 |   linkType: hard
 579 | 
 580 | "@typescript-eslint/eslint-plugin@npm:8.59.1":
 581 |   version: 8.59.1
 582 |   resolution: "@typescript-eslint/eslint-plugin@npm:8.59.1"
 583 |   dependencies:
 584 |     "@eslint-community/regexpp": "npm:^4.12.2"
 585 |     "@typescript-eslint/scope-manager": "npm:8.59.1"
 586 |     "@typescript-eslint/type-utils": "npm:8.59.1"
 587 |     "@typescript-eslint/utils": "npm:8.59.1"
 588 |     "@typescript-eslint/visitor-keys": "npm:8.59.1"
 589 |     ignore: "npm:^7.0.5"
 590 |     natural-compare: "npm:^1.4.0"
 591 |     ts-api-utils: "npm:^2.5.0"
 592 |   peerDependencies:
 593 |     "@typescript-eslint/parser": ^8.59.1
 594 |     eslint: ^8.57.0 || ^9.0.0 || ^10.0.0
 595 |     typescript: ">=4.8.4 <6.1.0"
 596 |   checksum: 10c0/6dedd272d1aac960df74ab81e38bb4b398ac11b52118c69493a3aeecd15984c83bd4cae89df2e8362fbc2213f0a6d68c00d71dd53868fa1b5e1011290d4ea7b6
 597 |   languageName: node
 598 |   linkType: hard
 599 | 
 600 | "@typescript-eslint/parser@npm:8.59.1":
 601 |   version: 8.59.1
 602 |   resolution: "@typescript-eslint/parser@npm:8.59.1"
 603 |   dependencies:
 604 |     "@typescript-eslint/scope-manager": "npm:8.59.1"
 605 |     "@typescript-eslint/types": "npm:8.59.1"
 606 |     "@typescript-eslint/typescript-estree": "npm:8.59.1"
 607 |     "@typescript-eslint/visitor-keys": "npm:8.59.1"
 608 |     debug: "npm:^4.4.3"
 609 |   peerDependencies:
 610 |     eslint: ^8.57.0 || ^9.0.0 || ^10.0.0
 611 |     typescript: ">=4.8.4 <6.1.0"
 612 |   checksum: 10c0/a20271b96e35fa5a8deea11ec40b30f7987daa5c3402e6e763e474517a25af20749a620490af159c2a65048065dea8a6d5fa3527ccc7a3716c2cd648a05ebc55
 613 |   languageName: node
 614 |   linkType: hard
 615 | 
 616 | "@typescript-eslint/project-service@npm:8.59.1":
 617 |   version: 8.59.1
 618 |   resolution: "@typescript-eslint/project-service@npm:8.59.1"
 619 |   dependencies:
 620 |     "@typescript-eslint/tsconfig-utils": "npm:^8.59.1"
 621 |     "@typescript-eslint/types": "npm:^8.59.1"
 622 |     debug: "npm:^4.4.3"
 623 |   peerDependencies:
 624 |     typescript: ">=4.8.4 <6.1.0"
 625 |   checksum: 10c0/487e60e9696fbae11070fd0591a009c94b932af2a92d37a1a9d9f9eac5bbc2f56fef83f3d4e72349dfdaadf95473bb5fb7332eb13f9296b87b3f14e842f42747
 626 |   languageName: node
 627 |   linkType: hard
 628 | 
 629 | "@typescript-eslint/scope-manager@npm:8.59.1":
 630 |   version: 8.59.1
 631 |   resolution: "@typescript-eslint/scope-manager@npm:8.59.1"
 632 |   dependencies:
 633 |     "@typescript-eslint/types": "npm:8.59.1"
 634 |     "@typescript-eslint/visitor-keys": "npm:8.59.1"
 635 |   checksum: 10c0/05c19039bde67691ad7a558ac61260639593ab0ffd8b73903b0f23c770aa3d79868bc8c1a11cdd5b0c8226e5dcef9ab1d679db46b5c5fe019541216170451614
 636 |   languageName: node
 637 |   linkType: hard
 638 | 
 639 | "@typescript-eslint/tsconfig-utils@npm:8.59.1, @typescript-eslint/tsconfig-utils@npm:^8.59.1":
 640 |   version: 8.59.1
 641 |   resolution: "@typescript-eslint/tsconfig-utils@npm:8.59.1"
 642 |   peerDependencies:
 643 |     typescript: ">=4.8.4 <6.1.0"
 644 |   checksum: 10c0/a3d123edbc39e7bfa3f58f722fe755787e71771d97b03ed80ea0706dcf3f25895e217e61b38049db1b05f246a26c6afb4e4a518bad21e7d1e71bb8dc136084ce
 645 |   languageName: node
 646 |   linkType: hard
 647 | 
 648 | "@typescript-eslint/type-utils@npm:8.59.1":
 649 |   version: 8.59.1
 650 |   resolution: "@typescript-eslint/type-utils@npm:8.59.1"
 651 |   dependencies:
 652 |     "@typescript-eslint/types": "npm:8.59.1"
 653 |     "@typescript-eslint/typescript-estree": "npm:8.59.1"
 654 |     "@typescript-eslint/utils": "npm:8.59.1"
 655 |     debug: "npm:^4.4.3"
 656 |     ts-api-utils: "npm:^2.5.0"
 657 |   peerDependencies:
 658 |     eslint: ^8.57.0 || ^9.0.0 || ^10.0.0
 659 |     typescript: ">=4.8.4 <6.1.0"
 660 |   checksum: 10c0/c5f0f8e53f85ddf796a45b485937b7d5aef5c884fed412ff945392376166242658e4b431bd9633e1e08d6dba7e83b6125283e4866f5a9b4ae61fec355705122d
 661 |   languageName: node
 662 |   linkType: hard
 663 | 
 664 | "@typescript-eslint/types@npm:8.59.1, @typescript-eslint/types@npm:^8.59.1":
 665 |   version: 8.59.1
 666 |   resolution: "@typescript-eslint/types@npm:8.59.1"
 667 |   checksum: 10c0/a0bf98389e8673d4aa1034fdef9bb78f576b3dc6b8f413d4adf07ef6edff4a33fdb916148c3bac2cafdbf282c765eebf253c2a05edf3fda4123b8889921cd518
 668 |   languageName: node
 669 |   linkType: hard
 670 | 
 671 | "@typescript-eslint/typescript-estree@npm:8.59.1":
 672 |   version: 8.59.1
 673 |   resolution: "@typescript-eslint/typescript-estree@npm:8.59.1"
 674 |   dependencies:
 675 |     "@typescript-eslint/project-service": "npm:8.59.1"
 676 |     "@typescript-eslint/tsconfig-utils": "npm:8.59.1"
 677 |     "@typescript-eslint/types": "npm:8.59.1"
 678 |     "@typescript-eslint/visitor-keys": "npm:8.59.1"
 679 |     debug: "npm:^4.4.3"
 680 |     minimatch: "npm:^10.2.2"
 681 |     semver: "npm:^7.7.3"
 682 |     tinyglobby: "npm:^0.2.15"
 683 |     ts-api-utils: "npm:^2.5.0"
 684 |   peerDependencies:
 685 |     typescript: ">=4.8.4 <6.1.0"
 686 |   checksum: 10c0/80b2624185d303741a710ba90e4fcb4e52320c1fc614f62cce785bfb39dfb9560ea5d325ff590d929c689b7dae7c28a598a26e1862477cc108c4ae4e8fe62c78
 687 |   languageName: node
 688 |   linkType: hard
 689 | 
 690 | "@typescript-eslint/utils@npm:8.59.1":
 691 |   version: 8.59.1
 692 |   resolution: "@typescript-eslint/utils@npm:8.59.1"
 693 |   dependencies:
 694 |     "@eslint-community/eslint-utils": "npm:^4.9.1"
 695 |     "@typescript-eslint/scope-manager": "npm:8.59.1"
 696 |     "@typescript-eslint/types": "npm:8.59.1"
 697 |     "@typescript-eslint/typescript-estree": "npm:8.59.1"
 698 |   peerDependencies:
 699 |     eslint: ^8.57.0 || ^9.0.0 || ^10.0.0
 700 |     typescript: ">=4.8.4 <6.1.0"
 701 |   checksum: 10c0/82a3fdb52d5f54622f8796eaeca508c630e65bfb94423645c1097b377fd56cf43b2999a83f11f42924e0cbb93b22faca6e572ee27cf550795b99e22193a0d41c
 702 |   languageName: node
 703 |   linkType: hard
 704 | 
 705 | "@typescript-eslint/visitor-keys@npm:8.59.1":
 706 |   version: 8.59.1
 707 |   resolution: "@typescript-eslint/visitor-keys@npm:8.59.1"
 708 |   dependencies:
 709 |     "@typescript-eslint/types": "npm:8.59.1"
 710 |     eslint-visitor-keys: "npm:^5.0.0"
 711 |   checksum: 10c0/1144426dda53e855698301eae6301ae928785915225e6a775f0b51bf5d67b67e90def7b851e851ce76235cff3e1324132d03c7843a33ce2c4f0eb0764cc2b80a
 712 |   languageName: node
 713 |   linkType: hard
 714 | 
 715 | "@vitejs/plugin-react@npm:^6.0.1":
 716 |   version: 6.0.1
 717 |   resolution: "@vitejs/plugin-react@npm:6.0.1"
 718 |   dependencies:
 719 |     "@rolldown/pluginutils": "npm:1.0.0-rc.7"
 720 |   peerDependencies:
 721 |     "@rolldown/plugin-babel": ^0.1.7 || ^0.2.0
 722 |     babel-plugin-react-compiler: ^1.0.0
 723 |     vite: ^8.0.0
 724 |   peerDependenciesMeta:
 725 |     "@rolldown/plugin-babel":
 726 |       optional: true
 727 |     babel-plugin-react-compiler:
 728 |       optional: true
 729 |   checksum: 10c0/6c42f53a970cb6b0776ba5b4203bb01690ac564c56fca706d4037b50aec965ddc0f11530ab58ab2cd0fbe8c12e14cff6966b22d90391283b4a53294e3ddd478d
 730 |   languageName: node
 731 |   linkType: hard
 732 | 
 733 | "abbrev@npm:^4.0.0":
 734 |   version: 4.0.0
 735 |   resolution: "abbrev@npm:4.0.0"
 736 |   checksum: 10c0/b4cc16935235e80702fc90192e349e32f8ef0ed151ef506aa78c81a7c455ec18375c4125414b99f84b2e055199d66383e787675f0bcd87da7a4dbd59f9eac1d5
 737 |   languageName: node
 738 |   linkType: hard
 739 | 
 740 | "acorn-jsx@npm:^5.3.2":
 741 |   version: 5.3.2
 742 |   resolution: "acorn-jsx@npm:5.3.2"
 743 |   peerDependencies:
 744 |     acorn: ^6.0.0 || ^7.0.0 || ^8.0.0
 745 |   checksum: 10c0/4c54868fbef3b8d58927d5e33f0a4de35f59012fe7b12cf9dfbb345fb8f46607709e1c4431be869a23fb63c151033d84c4198fa9f79385cec34fcb1dd53974c1
 746 |   languageName: node
 747 |   linkType: hard
 748 | 
 749 | "acorn@npm:^8.16.0":
 750 |   version: 8.16.0
 751 |   resolution: "acorn@npm:8.16.0"
 752 |   bin:
 753 |     acorn: bin/acorn
 754 |   checksum: 10c0/c9c52697227661b68d0debaf972222d4f622aa06b185824164e153438afa7b08273432ca43ea792cadb24dada1d46f6f6bb1ef8de9956979288cc1b96bf9914e
 755 |   languageName: node
 756 |   linkType: hard
 757 | 
 758 | "ajv@npm:^6.14.0":
 759 |   version: 6.15.0
 760 |   resolution: "ajv@npm:6.15.0"
 761 |   dependencies:
 762 |     fast-deep-equal: "npm:^3.1.1"
 763 |     fast-json-stable-stringify: "npm:^2.0.0"
 764 |     json-schema-traverse: "npm:^0.4.1"
 765 |     uri-js: "npm:^4.2.2"
 766 |   checksum: 10c0/67966499dd272ecde1c2e467084411132891523d057487587879d39ac04207f4351b7b2324c83198013967fbfa632c1612adc960114a30770fbe07a0773b32c2
 767 |   languageName: node
 768 |   linkType: hard
 769 | 
 770 | "balanced-match@npm:^4.0.2":
 771 |   version: 4.0.4
 772 |   resolution: "balanced-match@npm:4.0.4"
 773 |   checksum: 10c0/07e86102a3eb2ee2a6a1a89164f29d0dbaebd28f2ca3f5ca786f36b8b23d9e417eb3be45a4acf754f837be5ac0a2317de90d3fcb7f4f4dc95720a1f36b26a17b
 774 |   languageName: node
 775 |   linkType: hard
 776 | 
 777 | "baseline-browser-mapping@npm:^2.10.12":
 778 |   version: 2.10.24
 779 |   resolution: "baseline-browser-mapping@npm:2.10.24"
 780 |   bin:
 781 |     baseline-browser-mapping: dist/cli.cjs
 782 |   checksum: 10c0/ae41f20b7d594909eac68e54b876127a456c99e85f49ba928a79c97ea288007617ad6638ddd1e36db45bbacef7b95b0f436d347602b2e1be2047099fcbbd5f37
 783 |   languageName: node
 784 |   linkType: hard
 785 | 
 786 | "brace-expansion@npm:^5.0.5":
 787 |   version: 5.0.5
 788 |   resolution: "brace-expansion@npm:5.0.5"
 789 |   dependencies:
 790 |     balanced-match: "npm:^4.0.2"
 791 |   checksum: 10c0/4d238e14ed4f5cc9c07285550a41cef23121ca08ba99fa9eb5b55b580dcb6bf868b8210aa10526bdc9f8dc97f33ca2a7259039c4cc131a93042beddb424c48e3
 792 |   languageName: node
 793 |   linkType: hard
 794 | 
 795 | "browserslist@npm:^4.24.0":
 796 |   version: 4.28.2
 797 |   resolution: "browserslist@npm:4.28.2"
 798 |   dependencies:
 799 |     baseline-browser-mapping: "npm:^2.10.12"
 800 |     caniuse-lite: "npm:^1.0.30001782"
 801 |     electron-to-chromium: "npm:^1.5.328"
 802 |     node-releases: "npm:^2.0.36"
 803 |     update-browserslist-db: "npm:^1.2.3"
 804 |   bin:
 805 |     browserslist: cli.js
 806 |   checksum: 10c0/c0228b6330f785b7fa59d2d360124ec6d9322f96ed9f3ee1f873e33ecc9503a6f0ffc3b71191a28c4ff6e930b753b30043da1c33844a9548f3018d491f09ce60
 807 |   languageName: node
 808 |   linkType: hard
 809 | 
 810 | "caniuse-lite@npm:^1.0.30001782":
 811 |   version: 1.0.30001791
 812 |   resolution: "caniuse-lite@npm:1.0.30001791"
 813 |   checksum: 10c0/53c8b5dad1c196a5e495405a7d2dc1db58aed9be02f60cf2a2e29d2c8d8cbb6c39beabf958d6aa191ab967ddcf49f22319452256b980bad1e271615acfe58940
 814 |   languageName: node
 815 |   linkType: hard
 816 | 
 817 | "chownr@npm:^3.0.0":
 818 |   version: 3.0.0
 819 |   resolution: "chownr@npm:3.0.0"
 820 |   checksum: 10c0/43925b87700f7e3893296c8e9c56cc58f926411cce3a6e5898136daaf08f08b9a8eb76d37d3267e707d0dcc17aed2e2ebdf5848c0c3ce95cf910a919935c1b10
 821 |   languageName: node
 822 |   linkType: hard
 823 | 
 824 | "convert-source-map@npm:^2.0.0":
 825 |   version: 2.0.0
 826 |   resolution: "convert-source-map@npm:2.0.0"
 827 |   checksum: 10c0/8f2f7a27a1a011cc6cc88cc4da2d7d0cfa5ee0369508baae3d98c260bb3ac520691464e5bbe4ae7cdf09860c1d69ecc6f70c63c6e7c7f7e3f18ec08484dc7d9b
 828 |   languageName: node
 829 |   linkType: hard
 830 | 
 831 | "cross-spawn@npm:^7.0.6":
 832 |   version: 7.0.6
 833 |   resolution: "cross-spawn@npm:7.0.6"
 834 |   dependencies:
 835 |     path-key: "npm:^3.1.0"
 836 |     shebang-command: "npm:^2.0.0"
 837 |     which: "npm:^2.0.1"
 838 |   checksum: 10c0/053ea8b2135caff68a9e81470e845613e374e7309a47731e81639de3eaeb90c3d01af0e0b44d2ab9d50b43467223b88567dfeb3262db942dc063b9976718ffc1
 839 |   languageName: node
 840 |   linkType: hard
 841 | 
 842 | "csstype@npm:^3.2.2":
 843 |   version: 3.2.3
 844 |   resolution: "csstype@npm:3.2.3"
 845 |   checksum: 10c0/cd29c51e70fa822f1cecd8641a1445bed7063697469d35633b516e60fe8c1bde04b08f6c5b6022136bb669b64c63d4173af54864510fbb4ee23281801841a3ce
 846 |   languageName: node
 847 |   linkType: hard
 848 | 
 849 | "debug@npm:^4.1.0, debug@npm:^4.3.1, debug@npm:^4.3.2, debug@npm:^4.4.3":
 850 |   version: 4.4.3
 851 |   resolution: "debug@npm:4.4.3"
 852 |   dependencies:
 853 |     ms: "npm:^2.1.3"
 854 |   peerDependenciesMeta:
 855 |     supports-color:
 856 |       optional: true
 857 |   checksum: 10c0/d79136ec6c83ecbefd0f6a5593da6a9c91ec4d7ddc4b54c883d6e71ec9accb5f67a1a5e96d00a328196b5b5c86d365e98d8a3a70856aaf16b4e7b1985e67f5a6
 858 |   languageName: node
 859 |   linkType: hard
 860 | 
 861 | "deep-is@npm:^0.1.3":
 862 |   version: 0.1.4
 863 |   resolution: "deep-is@npm:0.1.4"
 864 |   checksum: 10c0/7f0ee496e0dff14a573dc6127f14c95061b448b87b995fc96c017ce0a1e66af1675e73f1d6064407975bc4ea6ab679497a29fff7b5b9c4e99cb10797c1ad0b4c
 865 |   languageName: node
 866 |   linkType: hard
 867 | 
 868 | "detect-libc@npm:^2.0.3":
 869 |   version: 2.1.2
 870 |   resolution: "detect-libc@npm:2.1.2"
 871 |   checksum: 10c0/acc675c29a5649fa1fb6e255f993b8ee829e510b6b56b0910666949c80c364738833417d0edb5f90e4e46be17228b0f2b66a010513984e18b15deeeac49369c4
 872 |   languageName: node
 873 |   linkType: hard
 874 | 
 875 | "electron-to-chromium@npm:^1.5.328":
 876 |   version: 1.5.348
 877 |   resolution: "electron-to-chromium@npm:1.5.348"
 878 |   checksum: 10c0/d9637b3ba53c0c8bc2430f65ff7f368403cdeb1fc9bfef2e44eabe4c0515bea244feedf3fd1848c474fe9586eba81d88507f24e0bdf0e21480b30439319b9509
 879 |   languageName: node
 880 |   linkType: hard
 881 | 
 882 | "env-paths@npm:^2.2.0":
 883 |   version: 2.2.1
 884 |   resolution: "env-paths@npm:2.2.1"
 885 |   checksum: 10c0/285325677bf00e30845e330eec32894f5105529db97496ee3f598478e50f008c5352a41a30e5e72ec9de8a542b5a570b85699cd63bd2bc646dbcb9f311d83bc4
 886 |   languageName: node
 887 |   linkType: hard
 888 | 
 889 | "escalade@npm:^3.2.0":
 890 |   version: 3.2.0
 891 |   resolution: "escalade@npm:3.2.0"
 892 |   checksum: 10c0/ced4dd3a78e15897ed3be74e635110bbf3b08877b0a41be50dcb325ee0e0b5f65fc2d50e9845194d7c4633f327e2e1c6cce00a71b617c5673df0374201d67f65
 893 |   languageName: node
 894 |   linkType: hard
 895 | 
 896 | "escape-string-regexp@npm:^4.0.0":
 897 |   version: 4.0.0
 898 |   resolution: "escape-string-regexp@npm:4.0.0"
 899 |   checksum: 10c0/9497d4dd307d845bd7f75180d8188bb17ea8c151c1edbf6b6717c100e104d629dc2dfb687686181b0f4b7d732c7dfdc4d5e7a8ff72de1b0ca283a75bbb3a9cd9
 900 |   languageName: node
 901 |   linkType: hard
 902 | 
 903 | "eslint-plugin-react-hooks@npm:^7.1.1":
 904 |   version: 7.1.1
 905 |   resolution: "eslint-plugin-react-hooks@npm:7.1.1"
 906 |   dependencies:
 907 |     "@babel/core": "npm:^7.24.4"
 908 |     "@babel/parser": "npm:^7.24.4"
 909 |     hermes-parser: "npm:^0.25.1"
 910 |     zod: "npm:^3.25.0 || ^4.0.0"
 911 |     zod-validation-error: "npm:^3.5.0 || ^4.0.0"
 912 |   peerDependencies:
 913 |     eslint: ^3.0.0 || ^4.0.0 || ^5.0.0 || ^6.0.0 || ^7.0.0 || ^8.0.0-0 || ^9.0.0 || ^10.0.0
 914 |   checksum: 10c0/cee8454915d71ac5d70a0d8f4f260e76eaf45fcd4162747dd4282b792ee5616d187351dabe6cdcff9040c79d0cec625635c4fd0777276be119efa88ebe058525
 915 |   languageName: node
 916 |   linkType: hard
 917 | 
 918 | "eslint-plugin-react-refresh@npm:^0.5.2":
 919 |   version: 0.5.2
 920 |   resolution: "eslint-plugin-react-refresh@npm:0.5.2"
 921 |   peerDependencies:
 922 |     eslint: ^9 || ^10
 923 |   checksum: 10c0/6e5b1b8ad673535ea1134fa16ecda986c389a045b87ca935e6c5f69070b1889218f3116bfb8b793ec10f37c286f28904d0b5b1d62a76760e465aa32e73e6010e
 924 |   languageName: node
 925 |   linkType: hard
 926 | 
 927 | "eslint-scope@npm:^9.1.2":
 928 |   version: 9.1.2
 929 |   resolution: "eslint-scope@npm:9.1.2"
 930 |   dependencies:
 931 |     "@types/esrecurse": "npm:^4.3.1"
 932 |     "@types/estree": "npm:^1.0.8"
 933 |     esrecurse: "npm:^4.3.0"
 934 |     estraverse: "npm:^5.2.0"
 935 |   checksum: 10c0/9fb8bca5a73e5741efb6cec84467027b6cb6f4203ff9b43a938e272c5cd30800bde46a5c20dfd1609f840225f0b62b7673be391b20acadf8658ca9fa4729b3dd
 936 |   languageName: node
 937 |   linkType: hard
 938 | 
 939 | "eslint-visitor-keys@npm:^3.4.3":
 940 |   version: 3.4.3
 941 |   resolution: "eslint-visitor-keys@npm:3.4.3"
 942 |   checksum: 10c0/92708e882c0a5ffd88c23c0b404ac1628cf20104a108c745f240a13c332a11aac54f49a22d5762efbffc18ecbc9a580d1b7ad034bf5f3cc3307e5cbff2ec9820
 943 |   languageName: node
 944 |   linkType: hard
 945 | 
 946 | "eslint-visitor-keys@npm:^5.0.0, eslint-visitor-keys@npm:^5.0.1":
 947 |   version: 5.0.1
 948 |   resolution: "eslint-visitor-keys@npm:5.0.1"
 949 |   checksum: 10c0/16190bdf2cbae40a1109384c94450c526a79b0b9c3cb21e544256ed85ac48a4b84db66b74a6561d20fe6ab77447f150d711c2ad5ad74df4fcc133736bce99678
 950 |   languageName: node
 951 |   linkType: hard
 952 | 
 953 | "eslint@npm:^10.2.1":
 954 |   version: 10.2.1
 955 |   resolution: "eslint@npm:10.2.1"
 956 |   dependencies:
 957 |     "@eslint-community/eslint-utils": "npm:^4.8.0"
 958 |     "@eslint-community/regexpp": "npm:^4.12.2"
 959 |     "@eslint/config-array": "npm:^0.23.5"
 960 |     "@eslint/config-helpers": "npm:^0.5.5"
 961 |     "@eslint/core": "npm:^1.2.1"
 962 |     "@eslint/plugin-kit": "npm:^0.7.1"
 963 |     "@humanfs/node": "npm:^0.16.6"
 964 |     "@humanwhocodes/module-importer": "npm:^1.0.1"
 965 |     "@humanwhocodes/retry": "npm:^0.4.2"
 966 |     "@types/estree": "npm:^1.0.6"
 967 |     ajv: "npm:^6.14.0"
 968 |     cross-spawn: "npm:^7.0.6"
 969 |     debug: "npm:^4.3.2"
 970 |     escape-string-regexp: "npm:^4.0.0"
 971 |     eslint-scope: "npm:^9.1.2"
 972 |     eslint-visitor-keys: "npm:^5.0.1"
 973 |     espree: "npm:^11.2.0"
 974 |     esquery: "npm:^1.7.0"
 975 |     esutils: "npm:^2.0.2"
 976 |     fast-deep-equal: "npm:^3.1.3"
 977 |     file-entry-cache: "npm:^8.0.0"
 978 |     find-up: "npm:^5.0.0"
 979 |     glob-parent: "npm:^6.0.2"
 980 |     ignore: "npm:^5.2.0"
 981 |     imurmurhash: "npm:^0.1.4"
 982 |     is-glob: "npm:^4.0.0"
 983 |     json-stable-stringify-without-jsonify: "npm:^1.0.1"
 984 |     minimatch: "npm:^10.2.4"
 985 |     natural-compare: "npm:^1.4.0"
 986 |     optionator: "npm:^0.9.3"
 987 |   peerDependencies:
 988 |     jiti: "*"
 989 |   peerDependenciesMeta:
 990 |     jiti:
 991 |       optional: true
 992 |   bin:
 993 |     eslint: bin/eslint.js
 994 |   checksum: 10c0/176795a3794a785502fa5cd14a9609264c2be5405552d20fed3e499bd465c29639c91ac44619ae66787b0fb7494e72d112550a2136a735d92a26bc6a7af4915c
 995 |   languageName: node
 996 |   linkType: hard
 997 | 
 998 | "espree@npm:^11.2.0":
 999 |   version: 11.2.0
1000 |   resolution: "espree@npm:11.2.0"


[File truncated: showing 1000 of 2000 total lines. The file is too large and may exhaust the context window if read in full.]
</file_content>
</folder_content>
<environment_details>
# VSCode Visible Files
frontend/vite.config.ts

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/vite.config.ts

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:25.223Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.00

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
frontend/
frontend/.gitignore
frontend/.yarnrc.yml
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/README.md
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.css
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I'll help you configure Prettier and ESLint in the frontend project. Let me start by examining the current configuration and then set up Prettier properly.

<read_file>
<args>
<file>
<path>frontend/package.json</path>
</file>
<file>
<path>frontend/eslint.config.js</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 'frontend/package.json', 'frontend/eslint.config.js'] Result:
<files>
<file><path>frontend/package.json</path>
<content lines="1-30">
 1 | {
 2 |   "name": "frontend",
 3 |   "private": true,
 4 |   "version": "0.0.0",
 5 |   "type": "module",
 6 |   "scripts": {
 7 |     "dev": "vite",
 8 |     "build": "tsc -b && vite build",
 9 |     "lint": "eslint .",
10 |     "preview": "vite preview"
11 |   },
12 |   "dependencies": {
13 |     "react": "^19.2.5",
14 |     "react-dom": "^19.2.5"
15 |   },
16 |   "devDependencies": {
17 |     "@eslint/js": "^10.0.1",
18 |     "@types/node": "^24.12.2",
19 |     "@types/react": "^19.2.14",
20 |     "@types/react-dom": "^19.2.3",
21 |     "@vitejs/plugin-react": "^6.0.1",
22 |     "eslint": "^10.2.1",
23 |     "eslint-plugin-react-hooks": "^7.1.1",
24 |     "eslint-plugin-react-refresh": "^0.5.2",
25 |     "globals": "^17.5.0",
26 |     "typescript": "~6.0.2",
27 |     "typescript-eslint": "^8.58.2",
28 |     "vite": "^8.0.10"
29 |   }
30 | }
</content>
</file>
<file><path>frontend/eslint.config.js</path>
<content lines="1-22">
 1 | import js from '@eslint/js'
 2 | import globals from 'globals'
 3 | import reactHooks from 'eslint-plugin-react-hooks'
 4 | import reactRefresh from 'eslint-plugin-react-refresh'
 5 | import tseslint from 'typescript-eslint'
 6 | import { defineConfig, globalIgnores } from 'eslint/config'
 7 | 
 8 | export default defineConfig([
 9 |   globalIgnores(['dist']),
10 |   {
11 |     files: ['**/*.{ts,tsx}'],
12 |     extends: [
13 |       js.configs.recommended,
14 |       tseslint.configs.recommended,
15 |       reactHooks.configs.flat.recommended,
16 |       reactRefresh.configs.vite,
17 |     ],
18 |     languageOptions: {
19 |       globals: globals.browser,
20 |     },
21 |   },
22 | ])
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/vite.config.ts

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/vite.config.ts

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:29.860Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.07

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[ ] Install Prettier and related packages
[ ] Create Prettier configuration file
[ ] Integrate Prettier with ESLint
[ ] Update ESLint configuration
[ ] Add format scripts to package.json
[ ] Create .prettierignore file
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/vite.config.ts

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/vite.config.ts

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:36.685Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.15

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Pending |
| 2 | Create Prettier configuration file | Pending |
| 3 | Integrate Prettier with ESLint | Pending |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<execute_command>
<command>cd frontend && yarn add -D prettier eslint-config-prettier eslint-plugin-prettier</command>
</execute_command>

---

**User:**

[execute_command for 'cd frontend && yarn add -D prettier eslint-config-prettier eslint-plugin-prettier'] Result:
Command is still running in terminal  from '/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project'.


You will be updated on the terminal status and new output in the future.
<environment_details>
# VSCode Visible Files
frontend/vite.config.ts

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/vite.config.ts

# Recently Modified Files
These files have been modified since you last accessed them (file was just edited so you may need to re-read it before editing):
frontend/package.json

# Actively Running Terminals
## Terminal 1 (Active)
### Working Directory: `/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project`
### Original command: `cd frontend && yarn add -D prettier eslint-config-prettier eslint-plugin-prettier`
### New Output
➤ YN0000: └ Completed in 0s 995ms
➤ YN0000: ┌ Link step
➤ YN0000: └ Completed in 0s 284ms
➤ YN0000: · Done in 1s 894ms


# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:47.453Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.22

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Pending |
| 2 | Create Prettier configuration file | Pending |
| 3 | Integrate Prettier with ESLint | Pending |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[x] Install Prettier and related packages
[-] Create Prettier configuration file
[ ] Integrate Prettier with ESLint
[ ] Update ESLint configuration
[ ] Add format scripts to package.json
[ ] Create .prettierignore file
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/vite.config.ts

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/vite.config.ts

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:51.667Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.30

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | In Progress |
| 3 | Integrate Prettier with ESLint | Pending |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<write_to_file>
<path>frontend/.prettierrc.json</path>
<content>
{
  "semi": true,
  "trailingComma": "es5",
  "singleQuote": true,
  "printWidth": 80,
  "tabWidth": 2,
  "useTabs": false,
  "arrowParens": "always",
  "endOfLine": "lf",
  "bracketSpacing": true,
  "jsxSingleQuote": false,
  "jsxBracketSameLine": false
}
</content>
<line_count>13</line_count>
</write_to_file>

---

**User:**

[write_to_file for 'frontend/.prettierrc.json'] Result:
<file_write_result>
<path>frontend/.prettierrc.json</path>
<operation>created</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<environment_details>
# VSCode Visible Files
frontend/.prettierrc.json

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:25:59.736Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.38

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
frontend/
frontend/.gitignore
frontend/.prettierrc.json
frontend/.yarnrc.yml
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/README.md
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.css
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | In Progress |
| 3 | Integrate Prettier with ESLint | Pending |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[x] Install Prettier and related packages
[x] Create Prettier configuration file
[-] Integrate Prettier with ESLint
[ ] Update ESLint configuration
[ ] Add format scripts to package.json
[ ] Create .prettierignore file
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/.prettierrc.json

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:11.562Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.46

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Integrate Prettier with ESLint | In Progress |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<write_to_file>
<path>frontend/.prettierignore</path>
<content>
# Dependencies
node_modules
.yarn

# Build outputs
dist
dist-ssr
build
*.local

# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

# Editor directories and files
.vscode
.idea
.DS_Store
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?

# Lock files
package-lock.json
yarn.lock

# Environment files
.env
.env.local
.env.*.local

# Coverage
coverage
*.lcov
.nyc_output
</content>
<line_count>44</line_count>
</write_to_file>

---

**User:**

[write_to_file for 'frontend/.prettierignore'] Result:
<file_write_result>
<path>frontend/.prettierignore</path>
<operation>created</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<environment_details>
# VSCode Visible Files
frontend/.prettierignore

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:17.464Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.54

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Integrate Prettier with ESLint | In Progress |
| 4 | Update ESLint configuration | Pending |
| 5 | Add format scripts to package.json | Pending |
| 6 | Create .prettierignore file | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[x] Install Prettier and related packages
[x] Create Prettier configuration file
[x] Create .prettierignore file
[-] Update ESLint configuration
[ ] Add format scripts to package.json
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/.prettierignore

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:21.118Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.63

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Create .prettierignore file | Completed |
| 4 | Update ESLint configuration | In Progress |
| 5 | Add format scripts to package.json | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<apply_diff>
<path>frontend/eslint.config.js</path>
<diff>
<<<<<<< SEARCH
:start_line:1
-------
import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import tseslint from 'typescript-eslint'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      globals: globals.browser,
    },
  },
])
=======
import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import tseslint from 'typescript-eslint'
import { defineConfig, globalIgnores } from 'eslint/config'
import eslintPluginPrettier from 'eslint-plugin-prettier/recommended'

export default defineConfig([
  globalIgnores(['dist', 'node_modules', '.yarn']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
      eslintPluginPrettier,
    ],
    languageOptions: {
      globals: globals.browser,
    },
    rules: {
      'prettier/prettier': 'error',
      '@typescript-eslint/no-unused-vars': [
        'error',
        {
          argsIgnorePattern: '^_',
          varsIgnorePattern: '^_',
        },
      ],
    },
  },
])
>>>>>>> REPLACE
</diff>
</apply_diff>

---

**User:**

[apply_diff for 'frontend/eslint.config.js'] Result:
<file_write_result>
<path>frontend/eslint.config.js</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<notice>Making multiple related changes in a single apply_diff is more efficient. If other changes are needed in this file, please include them as additional SEARCH/REPLACE blocks.</notice>
<environment_details>
# VSCode Visible Files
frontend/eslint.config.js

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore,frontend/eslint.config.js

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:31.525Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.71

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Create .prettierignore file | Completed |
| 4 | Update ESLint configuration | In Progress |
| 5 | Add format scripts to package.json | Pending |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[x] Install Prettier and related packages
[x] Create Prettier configuration file
[x] Create .prettierignore file
[x] Update ESLint configuration
[-] Add format scripts to package.json
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/eslint.config.js

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore,frontend/eslint.config.js

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:35.337Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.80

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Create .prettierignore file | Completed |
| 4 | Update ESLint configuration | Completed |
| 5 | Add format scripts to package.json | In Progress |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<apply_diff>
<path>frontend/package.json</path>
<diff>
<<<<<<< SEARCH
:start_line:6
-------
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint .",
    "preview": "vite preview"
  },
=======
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint .",
    "lint:fix": "eslint . --fix",
    "format": "prettier --write \"src/**/*.{ts,tsx,js,jsx,json,css,scss,md}\"",
    "format:check": "prettier --check \"src/**/*.{ts,tsx,js,jsx,json,css,scss,md}\"",
    "preview": "vite preview"
  },
>>>>>>> REPLACE
</diff>
</apply_diff>

---

**User:**

[apply_diff for 'frontend/package.json'] Result:
<file_write_result>
<path>frontend/package.json</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<notice>Making multiple related changes in a single apply_diff is more efficient. If other changes are needed in this file, please include them as additional SEARCH/REPLACE blocks.</notice>
<environment_details>
# VSCode Visible Files
frontend/package.json

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore,frontend/eslint.config.js,frontend/package.json

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:42.049Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.89

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Create .prettierignore file | Completed |
| 4 | Update ESLint configuration | Completed |
| 5 | Add format scripts to package.json | In Progress |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<update_todo_list>
<todos>
[x] Install Prettier and related packages
[x] Create Prettier configuration file
[x] Create .prettierignore file
[x] Update ESLint configuration
[x] Add format scripts to package.json
</todos>
</update_todo_list>

---

**User:**

[update_todo_list] Result:
Todo list updated successfully.
<environment_details>
# VSCode Visible Files
frontend/package.json

# VSCode Open Tabs
README.md,frontend/.yarnrc.yml,frontend/.prettierrc.json,frontend/.prettierignore,frontend/eslint.config.js,frontend/package.json

# Current Time
Current time in ISO 8601 UTC format: 2026-05-01T14:26:45.336Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.98

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
====

REMINDERS

Below is your current list of reminders for this task. Keep them updated as you progress.

| # | Content | Status |
|---|---------|--------|
| 1 | Install Prettier and related packages | Completed |
| 2 | Create Prettier configuration file | Completed |
| 3 | Create .prettierignore file | Completed |
| 4 | Update ESLint configuration | Completed |
| 5 | Add format scripts to package.json | Completed |


IMPORTANT: When task status changes, remember to call the `update_todo_list` tool to update your progress.

</environment_details>

---

**Assistant:**

<attempt_completion>
<result>
Successfully configured Prettier and ESLint in the frontend project:

**✅ Completed Tasks:**

1. **Installed Prettier packages:**
   - `prettier` - Code formatter
   - `eslint-config-prettier` - Disables ESLint rules that conflict with Prettier
   - `eslint-plugin-prettier` - Runs Prettier as an ESLint rule

2. **Created `.prettierrc.json`** with sensible defaults:
   - Single quotes, semicolons, 2-space indentation
   - 80 character line width
   - Trailing commas in ES5-compatible locations

3. **Created `.prettierignore`** to exclude:
   - Build outputs (dist, build)
   - Dependencies (node_modules, .yarn)
   - Lock files and logs

4. **Updated `eslint.config.js`:**
   - Integrated Prettier with ESLint
   - Added `prettier/prettier` as an error rule
   - Configured TypeScript unused vars to allow `_` prefix
   - Added more directories to global ignores

5. **Added npm scripts to `package.json`:**
   - `yarn lint` - Run ESLint
   - `yarn lint:fix` - Auto-fix ESLint issues
   - `yarn format` - Format code with Prettier
   - `yarn format:check` - Check formatting without modifying files

**Usage:**
- Format code: `yarn format`
- Check formatting: `yarn format:check`
- Lint code: `yarn lint`
- Auto-fix linting issues: `yarn lint:fix`
</result>
</attempt_completion>

