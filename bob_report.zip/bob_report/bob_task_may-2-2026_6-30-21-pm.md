**User:**

<task>
'frontend/src/page/admin/invoice/index.tsx' (see below for file content) check the backend controller where the adminInvoice for and create a page for it
</task>

<file_content path="frontend/src/page/admin/invoice/index.tsx">
1 | const AdminInvoice = () => {
2 |     return (
3 |         <div>Admin Invoice Page</div>
4 |     )
5 | }
6 | 
7 | export default AdminInvoice;

</file_content>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/transaction/index.tsx,frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T12:58:52.091Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.00

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
backend/.editorconfig
backend/.env.example
backend/.gitattributes
backend/.gitignore
backend/.prettierignore
backend/.prettierrc.json
backend/.yarnrc.yml
backend/eslint.config.js
backend/package.json
backend/README.md
backend/tsconfig.json
backend/yarn.lock
backend/.yarn/
backend/src/
backend/src/index.ts
backend/src/config/
backend/src/config/db.ts
backend/src/config/env.ts
backend/src/controller/
backend/src/controller/auth/
backend/src/controller/auth/index.ts
backend/src/controller/billing_detail/
backend/src/controller/billing_detail/index.ts
backend/src/controller/invoice/
backend/src/controller/invoice/index.ts
backend/src/controller/payment_methods/
backend/src/controller/payment_methods/index.ts
backend/src/controller/transaction/
backend/src/controller/transaction/index.ts
backend/src/controller/user/
backend/src/controller/user/index.ts
backend/src/middleware/
backend/src/middleware/auth.ts
backend/src/middleware/error.ts
backend/src/middleware/permission.ts
backend/src/models/
backend/src/models/billing_detail.ts
backend/src/models/index.ts
backend/src/models/invoice.ts
backend/src/models/otp.ts
backend/src/models/payment_method.ts
backend/src/models/transaction.ts
backend/src/models/user.ts
backend/src/routes/
backend/src/routes/index.ts
backend/src/routes/auth/
backend/src/routes/auth/index.ts
backend/src/routes/billing_details/
backend/src/routes/billing_details/index.ts
backend/src/routes/invoice/
backend/src/routes/invoice/index.ts
backend/src/routes/payment_methods/
backend/src/routes/payment_methods/index.ts
backend/src/routes/transaction/
backend/src/routes/transaction/index.ts
backend/src/routes/user/
backend/src/routes/user/index.ts
backend/src/services/
backend/src/services/smtp.ts
backend/src/utils/
backend/src/utils/bcrypt.ts
backend/src/utils/error.ts
backend/src/utils/generate-otp.ts
backend/src/utils/jwt.ts
backend/src/utils/logger.ts
backend/src/utils/reminder.ts
backend/src/views/
backend/src/views/auth/
backend/src/views/auth/forgot-password.ejs
backend/src/views/auth/login.ejs
backend/src/views/auth/signup.ejs
backend/src/views/invoice/
backend/src/views/invoice/invoice.ejs
backend/src/views/reminder/
backend/src/views/reminder/reminder.ejs
frontend/
frontend/.env.example
frontend/.gitignore
frontend/.prettierignore
frontend/.prettierrc.json
frontend/.yarnrc.yml
frontend/components.json
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/postcss.config.js
frontend/README.md
frontend/tailwind.config.js
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
frontend/src/components/
frontend/src/components/custom/
frontend/src/components/custom/navbar/
frontend/src/components/custom/navbar/index.tsx
frontend/src/components/custom/page-loader/
frontend/src/components/custom/page-loader/index.tsx
frontend/src/components/custom/sidebar/
frontend/src/components/custom/sidebar/index.tsx
frontend/src/components/ui/
frontend/src/components/ui/accordion.tsx
frontend/src/components/ui/alert.tsx
frontend/src/components/ui/badge.tsx
frontend/src/components/ui/button.tsx
frontend/src/components/ui/card.tsx
frontend/src/components/ui/checkbox.tsx
frontend/src/components/ui/dialog.tsx
frontend/src/components/ui/dropdown-menu.tsx
frontend/src/components/ui/form.tsx
frontend/src/components/ui/index.ts
frontend/src/components/ui/input.tsx
frontend/src/components/ui/label.tsx
frontend/src/components/ui/radio-group.tsx
frontend/src/components/ui/select.tsx
frontend/src/components/ui/switch.tsx
frontend/src/components/ui/tabs.tsx
frontend/src/components/ui/textarea.tsx
frontend/src/components/ui/tooltip.tsx
frontend/src/data/
frontend/src/data/mockInvoices.ts
frontend/src/lib/
frontend/src/lib/utils.ts
frontend/src/page/
frontend/src/page/layout.tsx
frontend/src/page/admin/
frontend/src/page/admin/billing_detail/
frontend/src/page/admin/billing_detail/index.tsx
frontend/src/page/admin/invoice/
frontend/src/page/admin/invoice/index.tsx
frontend/src/page/admin/payment_method/
frontend/src/page/admin/payment_method/index.tsx
frontend/src/page/admin/transcation/
frontend/src/page/admin/transcation/index.tsx
frontend/src/page/auth/
frontend/src/page/auth/forgot-password/
frontend/src/page/auth/forgot-password/index.tsx
frontend/src/page/auth/login/
frontend/src/page/auth/login/index.tsx
frontend/src/page/auth/signup/
frontend/src/page/auth/signup/index.tsx
frontend/src/page/billing_detail/
frontend/src/page/billing_detail/index.tsx
frontend/src/page/billing_detail/new/
frontend/src/page/billing_detail/new/index.tsx
frontend/src/page/home/
frontend/src/page/home/index.tsx
frontend/src/page/invoice/
frontend/src/page/invoice/index.tsx
frontend/src/page/payment_method/
frontend/src/page/payment_method/index.tsx
frontend/src/page/payment_method/new/
frontend/src/page/payment_method/new/index.tsx
frontend/src/page/profile/
frontend/src/page/profile/index.tsx
frontend/src/page/transaction/
frontend/src/page/transaction/index.tsx
frontend/src/service/
frontend/src/service/api.ts
frontend/src/service/auth/
frontend/src/service/auth/index.ts
frontend/src/service/auth/interface.ts
frontend/src/service/billing_details/
frontend/src/service/billing_details/index.ts
frontend/src/service/billing_details/interface.ts
frontend/src/service/invoice/
frontend/src/service/invoice/index.ts
frontend/src/service/invoice/interface.ts
frontend/src/service/payment_methods/
frontend/src/service/payment_methods/index.ts
frontend/src/service/payment_methods/interface.ts
frontend/src/service/transaction/
frontend/src/service/transaction/index.ts
frontend/src/service/transaction/interface.ts
frontend/src/service/user/
frontend/src/service/user/index.ts
frontend/src/service/user/interface.ts
frontend/src/store/
frontend/src/store/index.ts
frontend/src/store/auth/
frontend/src/store/auth/index.ts
frontend/src/store/nav-toggle/index.ts
frontend/src/utils/AutoRedirect.tsx
frontend/src/utils/PermissionRoute.tsx
frontend/src/utils/ProtectedRoute.tsx

(File list truncated. Use list_files on specific subdirectories if you need to explore further.)
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I'll help you check the backend controller for admin invoice and create a proper page for it. Let me start by examining the backend invoice controller and routes.

<read_file>
<args>
<file>
<path>backend/src/controller/invoice/index.ts</path>
</file>
<file>
<path>backend/src/routes/invoice/index.ts</path>
</file>
<file>
<path>backend/src/models/invoice.ts</path>
</file>
<file>
<path>frontend/src/service/invoice/index.ts</path>
</file>
<file>
<path>frontend/src/service/invoice/interface.ts</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 5 files] Result:
<files>
<file><path>backend/src/controller/invoice/index.ts</path>
<content lines="1-492">
  1 | import { Request, Response, NextFunction } from "express";
  2 | import { throwCustomError } from "../../utils/error";
  3 | import { Invoice, User } from "../../models";
  4 | import { sequelize } from "../../config/db";
  5 | import { sendEmail } from "../../services/smtp";
  6 | 
  7 | // Get all invoices (Admin only)
  8 | export const getAllInvoices = async (
  9 |     req: Request,
 10 |     res: Response,
 11 |     next: NextFunction
 12 | ) => {
 13 |     try {
 14 |         // Pagination parameters
 15 |         const page = parseInt(req.query.page as string) || 1;
 16 |         const limit = parseInt(req.query.limit as string) || 10;
 17 |         const offset = (page - 1) * limit;
 18 | 
 19 |         // Get total count
 20 |         const totalCount = await Invoice.count();
 21 | 
 22 |         // Get paginated invoices
 23 |         const invoices = await Invoice.findAll({
 24 |             include: [
 25 |                 {
 26 |                     model: User,
 27 |                     as: "user",
 28 |                     attributes: ["id", "name", "email", "phone"]
 29 |                 }
 30 |             ],
 31 |             order: [["createdAt", "DESC"]],
 32 |             limit,
 33 |             offset
 34 |         });
 35 | 
 36 |         // Calculate pagination metadata
 37 |         const totalPages = Math.ceil(totalCount / limit);
 38 | 
 39 |         res.status(200).json({
 40 |             message: "Invoices retrieved successfully!",
 41 |             data: invoices,
 42 |             pagination: {
 43 |                 currentPage: page,
 44 |                 totalPages,
 45 |                 totalCount,
 46 |                 limit,
 47 |                 hasNextPage: page < totalPages,
 48 |                 hasPreviousPage: page > 1
 49 |             }
 50 |         });
 51 |     }
 52 |     catch (err) {
 53 |         next(err);
 54 |     }
 55 | }
 56 | 
 57 | // Get invoices by authenticated user
 58 | export const getUserInvoices = async (
 59 |     req: Request & { user?: { id: string }},
 60 |     res: Response,
 61 |     next: NextFunction
 62 | ) => {
 63 |     try {
 64 |         const userId = req.user?.id;
 65 | 
 66 |         if (!userId) {
 67 |             return throwCustomError(401, "Unauthorized");
 68 |         }
 69 | 
 70 |         // Pagination parameters
 71 |         const page = parseInt(req.query.page as string) || 1;
 72 |         const limit = parseInt(req.query.limit as string) || 10;
 73 |         const offset = (page - 1) * limit;
 74 | 
 75 |         // Get total count for user
 76 |         const totalCount = await Invoice.count({ where: { userId } });
 77 | 
 78 |         // Get paginated invoices for the authenticated user
 79 |         const invoices = await Invoice.findAll({
 80 |             where: { userId },
 81 |             include: [
 82 |                 {
 83 |                     model: User,
 84 |                     as: "user",
 85 |                     attributes: ["id", "name", "email", "phone"]
 86 |                 }
 87 |             ],
 88 |             order: [["createdAt", "DESC"]],
 89 |             limit,
 90 |             offset
 91 |         });
 92 | 
 93 |         // Calculate pagination metadata
 94 |         const totalPages = Math.ceil(totalCount / limit);
 95 | 
 96 |         res.status(200).json({
 97 |             message: "User invoices retrieved successfully!",
 98 |             data: invoices,
 99 |             pagination: {
100 |                 currentPage: page,
101 |                 totalPages,
102 |                 totalCount,
103 |                 limit,
104 |                 hasNextPage: page < totalPages,
105 |                 hasPreviousPage: page > 1
106 |             }
107 |         });
108 |     }
109 |     catch (err) {
110 |         next(err);
111 |     }
112 | }
113 | 
114 | // Get single invoice by ID
115 | export const getInvoiceById = async (
116 |     req: Request & { user?: { id: string }},
117 |     res: Response,
118 |     next: NextFunction
119 | ) => {
120 |     try {
121 |         const { id } = req.params;
122 |         const userId = req.user?.id;
123 | 
124 |         if (!userId) {
125 |             return throwCustomError(401, "Unauthorized");
126 |         }
127 | 
128 |         if (!id) {
129 |             return throwCustomError(400, "Invoice ID is required!");
130 |         }
131 | 
132 |         const invoice = await Invoice.findOne({
133 |             where: { id, userId },
134 |             include: [
135 |                 {
136 |                     model: User,
137 |                     as: "user",
138 |                     attributes: ["id", "name", "email", "phone"]
139 |                 }
140 |             ]
141 |         });
142 | 
143 |         if (!invoice) {
144 |             return throwCustomError(404, "Invoice not found!");
145 |         }
146 | 
147 |         res.status(200).json({
148 |             message: "Invoice retrieved successfully!",
149 |             data: invoice
150 |         });
151 |     }
152 |     catch (err) {
153 |         next(err);
154 |     }
155 | }
156 | 
157 | // Create invoice
158 | export const createInvoice = async (
159 |     req: Request & { user?: { id: string }},
160 |     res: Response,
161 |     next: NextFunction
162 | ) => {
163 |     const transaction = await sequelize.transaction();
164 |     try {
165 |         const userId = req.user?.id;
166 | 
167 |         if (!userId) {
168 |             return throwCustomError(401, "Unauthorized");
169 |         }
170 | 
171 |         const {
172 |             invoice_number,
173 |             invoice_date,
174 |             customer_name,
175 |             customer_email,
176 |             customer_phone,
177 |             total_amount,
178 |             payment_status,
179 |             notes,
180 |             status
181 |         } = req.body;
182 | 
183 |         // Validate required fields
184 |         if (!invoice_number || !customer_name || !total_amount) {
185 |             return throwCustomError(400, "Invoice number, customer name, and total amount are required!");
186 |         }
187 | 
188 |         // Check if invoice number already exists
189 |         const existingInvoice = await Invoice.findOne({
190 |             where: { invoice_number },
191 |             transaction
192 |         });
193 | 
194 |         if (existingInvoice) {
195 |             await transaction.rollback();
196 |             return throwCustomError(400, "Invoice number already exists!");
197 |         }
198 | 
199 |         // Create invoice for the authenticated user
200 |         const invoice = await Invoice.create(
201 |             {
202 |                 invoice_number,
203 |                 invoice_date: invoice_date || new Date(),
204 |                 customer_name,
205 |                 customer_email,
206 |                 customer_phone,
207 |                 total_amount,
208 |                 payment_status: payment_status || "pending",
209 |                 notes,
210 |                 status: status || "draft",
211 |                 userId
212 |             },
213 |             { transaction }
214 |         );
215 | 
216 |         await transaction.commit();
217 | 
218 |         // Fetch the created invoice with user information
219 |         const createdInvoice = await Invoice.findOne({
220 |             where: { id: invoice.get("id") },
221 |             include: [
222 |                 {
223 |                     model: User,
224 |                     as: "user",
225 |                     attributes: ["id", "name", "email", "phone"]
226 |                 }
227 |             ]
228 |         });
229 | 
230 |         // Send email to customer if email is provided
231 |         if (customer_email) {
232 |             try {
233 |                 await sendEmail({
234 |                     to: customer_email,
235 |                     subject: `Invoice ${invoice_number} - ${customer_name}`,
236 |                     template: "invoice/invoice",
237 |                     context: {
238 |                         invoice_number: invoice_number,
239 |                         invoice_date: invoice_date || new Date().toISOString(),
240 |                         customer_name: customer_name,
241 |                         customer_email: customer_email || "",
242 |                         customer_phone: customer_phone || "",
243 |                         total_amount: total_amount.toString(),
244 |                         payment_status: payment_status || "pending",
245 |                         notes: notes || "",
246 |                         status: status || "draft"
247 |                     }
248 |                 });
249 |             } catch (emailError) {
250 |                 // Log email error but don't fail the invoice creation
251 |                 console.error("Failed to send invoice email:", emailError);
252 |             }
253 |         }
254 | 
255 |         res.status(201).json({
256 |             message: "Invoice created successfully!",
257 |             data: createdInvoice
258 |         });
259 |     }
260 |     catch (err) {
261 |         await transaction.rollback();
262 |         next(err);
263 |     }
264 | }
265 | 
266 | // Update invoice
267 | export const updateInvoice = async (
268 |     req: Request & { user?: { id: string }},
269 |     res: Response,
270 |     next: NextFunction
271 | ) => {
272 |     const transaction = await sequelize.transaction();
273 |     try {
274 |         const { id } = req.params;
275 |         const userId = req.user?.id;
276 |         const updateData = req.body;
277 | 
278 |         if (!userId) {
279 |             return throwCustomError(401, "Unauthorized");
280 |         }
281 | 
282 |         if (!id) {
283 |             return throwCustomError(400, "Invoice ID is required!");
284 |         }
285 | 
286 |         // Find the invoice belonging to the authenticated user
287 |         const invoice = await Invoice.findOne({
288 |             where: { id, userId },
289 |             transaction
290 |         });
291 | 
292 |         if (!invoice) {
293 |             await transaction.rollback();
294 |             return throwCustomError(404, "Invoice not found!");
295 |         }
296 | 
297 |         // If updating invoice_number, check for duplicates
298 |         if (updateData.invoice_number && updateData.invoice_number !== invoice.get("invoice_number")) {
299 |             const existingInvoice = await Invoice.findOne({
300 |                 where: { invoice_number: updateData.invoice_number },
301 |                 transaction
302 |             });
303 | 
304 |             if (existingInvoice) {
305 |                 await transaction.rollback();
306 |                 return throwCustomError(400, "Invoice number already exists!");
307 |             }
308 |         }
309 | 
310 |         // Update the invoice
311 |         await invoice.update(updateData, { transaction });
312 | 
313 |         await transaction.commit();
314 | 
315 |         // Fetch the updated invoice with user information
316 |         const updatedInvoice = await Invoice.findOne({
317 |             where: { id },
318 |             include: [
319 |                 {
320 |                     model: User,
321 |                     as: "user",
322 |                     attributes: ["id", "name", "email", "phone"]
323 |                 }
324 |             ]
325 |         });
326 | 
327 |         res.status(200).json({
328 |             message: "Invoice updated successfully!",
329 |             data: updatedInvoice
330 |         });
331 |     }
332 |     catch (err) {
333 |         await transaction.rollback();
334 |         next(err);
335 |     }
336 | }
337 | 
338 | // Delete invoice
339 | export const deleteInvoice = async (
340 |     req: Request & { user?: { id: string }},
341 |     res: Response,
342 |     next: NextFunction
343 | ) => {
344 |     const transaction = await sequelize.transaction();
345 |     try {
346 |         const { id } = req.params;
347 |         const userId = req.user?.id;
348 | 
349 |         if (!userId) {
350 |             return throwCustomError(401, "Unauthorized");
351 |         }
352 | 
353 |         if (!id) {
354 |             return throwCustomError(400, "Invoice ID is required!");
355 |         }
356 | 
357 |         // Find the invoice belonging to the authenticated user
358 |         const invoice = await Invoice.findOne({
359 |             where: { id, userId },
360 |             transaction
361 |         });
362 | 
363 |         if (!invoice) {
364 |             await transaction.rollback();
365 |             return throwCustomError(404, "Invoice not found!");
366 |         }
367 | 
368 |         // Delete the invoice
369 |         await invoice.destroy({ transaction });
370 | 
371 |         await transaction.commit();
372 | 
373 |         res.status(200).json({
374 |             message: "Invoice deleted successfully!",
375 |             data: { id }
376 |         });
377 |     }
378 |     catch (err) {
379 |         await transaction.rollback();
380 |         next(err);
381 |     }
382 | }
383 | 
384 | // Admin: Update any invoice
385 | export const adminUpdateInvoice = async (
386 |     req: Request,
387 |     res: Response,
388 |     next: NextFunction
389 | ) => {
390 |     const transaction = await sequelize.transaction();
391 |     try {
392 |         const { id } = req.params;
393 |         const updateData = req.body;
394 | 
395 |         if (!id) {
396 |             return throwCustomError(400, "Invoice ID is required!");
397 |         }
398 | 
399 |         // Find the invoice
400 |         const invoice = await Invoice.findOne({
401 |             where: { id },
402 |             transaction
403 |         });
404 | 
405 |         if (!invoice) {
406 |             await transaction.rollback();
407 |             return throwCustomError(404, "Invoice not found!");
408 |         }
409 | 
410 |         // If updating invoice_number, check for duplicates
411 |         if (updateData.invoice_number && updateData.invoice_number !== invoice.get("invoice_number")) {
412 |             const existingInvoice = await Invoice.findOne({
413 |                 where: { invoice_number: updateData.invoice_number },
414 |                 transaction
415 |             });
416 | 
417 |             if (existingInvoice) {
418 |                 await transaction.rollback();
419 |                 return throwCustomError(400, "Invoice number already exists!");
420 |             }
421 |         }
422 | 
423 |         // Update the invoice
424 |         await invoice.update(updateData, { transaction });
425 | 
426 |         await transaction.commit();
427 | 
428 |         // Fetch the updated invoice with user information
429 |         const updatedInvoice = await Invoice.findOne({
430 |             where: { id },
431 |             include: [
432 |                 {
433 |                     model: User,
434 |                     as: "user",
435 |                     attributes: ["id", "name", "email", "phone"]
436 |                 }
437 |             ]
438 |         });
439 | 
440 |         res.status(200).json({
441 |             message: "Invoice updated successfully!",
442 |             data: updatedInvoice
443 |         });
444 |     }
445 |     catch (err) {
446 |         await transaction.rollback();
447 |         next(err);
448 |     }
449 | }
450 | 
451 | // Admin: Delete any invoice
452 | export const adminDeleteInvoice = async (
453 |     req: Request,
454 |     res: Response,
455 |     next: NextFunction
456 | ) => {
457 |     const transaction = await sequelize.transaction();
458 |     try {
459 |         const { id } = req.params;
460 | 
461 |         if (!id) {
462 |             return throwCustomError(400, "Invoice ID is required!");
463 |         }
464 | 
465 |         // Find the invoice
466 |         const invoice = await Invoice.findOne({
467 |             where: { id },
468 |             transaction
469 |         });
470 | 
471 |         if (!invoice) {
472 |             await transaction.rollback();
473 |             return throwCustomError(404, "Invoice not found!");
474 |         }
475 | 
476 |         // Delete the invoice
477 |         await invoice.destroy({ transaction });
478 | 
479 |         await transaction.commit();
480 | 
481 |         res.status(200).json({
482 |             message: "Invoice deleted successfully!",
483 |             data: { id }
484 |         });
485 |     }
486 |     catch (err) {
487 |         await transaction.rollback();
488 |         next(err);
489 |     }
490 | }
491 | 
492 | // Made with Bob
</content>
</file>
<file><path>backend/src/routes/invoice/index.ts</path>
<content lines="1-40">
 1 | import { Router } from "express";
 2 | import {
 3 |     getAllInvoices,
 4 |     getUserInvoices,
 5 |     getInvoiceById,
 6 |     createInvoice,
 7 |     updateInvoice,
 8 |     deleteInvoice,
 9 |     adminUpdateInvoice,
10 |     adminDeleteInvoice
11 | } from "../../controller/invoice";
12 | import { authenticate } from "../../middleware/auth";
13 | import { permission } from "../../middleware/permission";
14 | 
15 | const router = Router();
16 | 
17 | // Admin routes - require authentication and admin permission
18 | router.route("/admin").get(authenticate, permission, getAllInvoices);
19 | router.route("/admin/:id").put(authenticate, permission, adminUpdateInvoice);
20 | router.route("/admin/:id").delete(authenticate, permission, adminDeleteInvoice);
21 | 
22 | // User routes - require authentication only
23 | // Get all invoices for authenticated user
24 | router.route("/").get(authenticate, getUserInvoices);
25 | 
26 | // Get single invoice by ID (user can only access their own invoices)
27 | router.route("/:id").get(authenticate, getInvoiceById);
28 | 
29 | // Create new invoice
30 | router.route("/").post(authenticate, createInvoice);
31 | 
32 | // Update invoice (user can only update their own invoices)
33 | router.route("/:id").put(authenticate, updateInvoice);
34 | 
35 | // Delete invoice (user can only delete their own invoices)
36 | router.route("/:id").delete(authenticate, deleteInvoice);
37 | 
38 | export default router;
39 | 
40 | // Made with Bob
</content>
</file>
<file><path>backend/src/models/invoice.ts</path>
<content lines="1-69">
 1 | import { DataTypes } from "sequelize";
 2 | import { sequelize } from "../config/db";
 3 | 
 4 | const Invoice = sequelize.define(
 5 |     "Invoice",
 6 |     {
 7 |         id: {
 8 |             type: DataTypes.UUID,
 9 |             defaultValue: DataTypes.UUIDV4,
10 |             primaryKey: true,
11 |         },
12 |         invoice_number: {
13 |             type: DataTypes.STRING,
14 |             allowNull: false,
15 |             unique: true,
16 |         },
17 |         invoice_date: {
18 |             type: DataTypes.DATE,
19 |             allowNull: false,
20 |             defaultValue: DataTypes.NOW,
21 |         },
22 |         customer_name: {
23 |             type: DataTypes.STRING,
24 |             allowNull: false,
25 |         },
26 |         customer_email: {
27 |             type: DataTypes.STRING,
28 |             allowNull: true,
29 |         },
30 |         customer_phone: {
31 |             type: DataTypes.STRING,
32 |             allowNull: true,
33 |         },
34 |         total_amount: {
35 |             type: DataTypes.DECIMAL(10, 2),
36 |             allowNull: false,
37 |         },
38 |         payment_status: {
39 |             type: DataTypes.ENUM("pending", "partial", "paid", "overdue", "cancelled"),
40 |             allowNull: false,
41 |             defaultValue: "pending",
42 |         },
43 |         notes: {
44 |             type: DataTypes.TEXT,
45 |             allowNull: true,
46 |         },
47 |         status: {
48 |             type: DataTypes.ENUM("draft", "sent", "viewed", "paid", "cancelled"),
49 |             allowNull: false,
50 |             defaultValue: "draft",
51 |         },
52 |         userId: {
53 |             type: DataTypes.UUID,
54 |             allowNull: false,
55 |             references: {
56 |                 model: "users",
57 |                 key: "id",
58 |             }
59 |         },
60 |     },
61 |     {
62 |         tableName: "invoices",
63 |         timestamps: true,
64 |     }
65 | );
66 | 
67 | export { Invoice };
68 | 
69 | // Made with Bob
</content>
</file>
<file><path>frontend/src/service/invoice/index.ts</path>
<content lines="1-76">
 1 | import api from "../api";
 2 | import type { 
 3 |     ICreateInvoice, 
 4 |     IUpdateInvoice, 
 5 |     IGetAllInvoicesQuery,
 6 |     IGetUserInvoicesQuery
 7 | } from "./interface";
 8 | 
 9 | // Admin: Get all invoices with pagination
10 | const getAllInvoices = async (query?: IGetAllInvoicesQuery) => {
11 |     const params = new URLSearchParams();
12 |     if (query?.page) params.append('page', query.page.toString());
13 |     if (query?.limit) params.append('limit', query.limit.toString());
14 |     
15 |     const response = await api.get(`/invoice?${params.toString()}`);
16 |     return response.data;
17 | }
18 | 
19 | // User: Get user's invoices with pagination
20 | const getUserInvoices = async (query?: IGetUserInvoicesQuery) => {
21 |     const params = new URLSearchParams();
22 |     if (query?.page) params.append('page', query.page.toString());
23 |     if (query?.limit) params.append('limit', query.limit.toString());
24 |     
25 |     const response = await api.get(`/invoice/user?${params.toString()}`);
26 |     return response.data;
27 | }
28 | 
29 | // User: Get invoice by ID
30 | const getInvoiceById = async (id: string) => {
31 |     const response = await api.get(`/invoice/${id}`);
32 |     return response.data;
33 | }
34 | 
35 | // User: Create invoice
36 | const createInvoice = async (payload: ICreateInvoice) => {
37 |     const response = await api.post(`/invoice`, payload);
38 |     return response.data;
39 | }
40 | 
41 | // User: Update invoice
42 | const updateInvoice = async (id: string, payload: IUpdateInvoice) => {
43 |     const response = await api.put(`/invoice/${id}`, payload);
44 |     return response.data;
45 | }
46 | 
47 | // User: Delete invoice
48 | const deleteInvoice = async (id: string) => {
49 |     const response = await api.delete(`/invoice/${id}`);
50 |     return response.data;
51 | }
52 | 
53 | // Admin: Update any invoice
54 | const adminUpdateInvoice = async (id: string, payload: IUpdateInvoice) => {
55 |     const response = await api.put(`/invoice/admin/${id}`, payload);
56 |     return response.data;
57 | }
58 | 
59 | // Admin: Delete any invoice
60 | const adminDeleteInvoice = async (id: string) => {
61 |     const response = await api.delete(`/invoice/admin/${id}`);
62 |     return response.data;
63 | }
64 | 
65 | export {
66 |     getAllInvoices,
67 |     getUserInvoices,
68 |     getInvoiceById,
69 |     createInvoice,
70 |     updateInvoice,
71 |     deleteInvoice,
72 |     adminUpdateInvoice,
73 |     adminDeleteInvoice
74 | }
75 | 
76 | // Made with Bob
</content>
</file>
<file><path>frontend/src/service/invoice/interface.ts</path>
<content lines="1-35">
 1 | export interface ICreateInvoice {
 2 |     invoice_number: string;
 3 |     invoice_date?: string;
 4 |     customer_name: string;
 5 |     customer_email?: string;
 6 |     customer_phone?: string;
 7 |     total_amount: number;
 8 |     payment_status?: string;
 9 |     notes?: string;
10 |     status?: string;
11 | }
12 | 
13 | export interface IUpdateInvoice {
14 |     invoice_number?: string;
15 |     invoice_date?: string;
16 |     customer_name?: string;
17 |     customer_email?: string;
18 |     customer_phone?: string;
19 |     total_amount?: number;
20 |     payment_status?: string;
21 |     notes?: string;
22 |     status?: string;
23 | }
24 | 
25 | export interface IGetAllInvoicesQuery {
26 |     page?: number;
27 |     limit?: number;
28 | }
29 | 
30 | export interface IGetUserInvoicesQuery {
31 |     page?: number;
32 |     limit?: number;
33 | }
34 | 
35 | // Made with Bob
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/transaction/index.tsx,frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T12:58:56.198Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.01

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

Now let me check similar admin pages to understand the structure and styling patterns used in this project.

<read_file>
<args>
<file>
<path>frontend/src/page/admin/transcation/index.tsx</path>
</file>
<file>
<path>frontend/src/page/admin/billing_detail/index.tsx</path>
</file>
<file>
<path>frontend/src/page/invoice/index.tsx</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 'frontend/src/page/admin/transcation/index.tsx', 'frontend/src/page/admin/billing_detail/index.tsx', 'frontend/src/page/invoice/index.tsx'] Result:
<files>
<file><path>frontend/src/page/admin/transcation/index.tsx</path>
<content lines="1-501">
  1 | import { useEffect, useState } from 'react';
  2 | import { getAllTransactions } from '@/service/transaction';
  3 | import type { ITransaction } from '@/service/transaction/interface';
  4 | import {
  5 |     Accordion,
  6 |     AccordionContent,
  7 |     AccordionItem,
  8 |     AccordionTrigger,
  9 | } from '@/components/ui/accordion';
 10 | import {
 11 |     Card,
 12 |     CardContent,
 13 |     CardDescription,
 14 |     CardHeader,
 15 |     CardTitle,
 16 | } from '@/components/ui/card';
 17 | import { Badge } from '@/components/ui/badge';
 18 | import { Button } from '@/components/ui/button';
 19 | import { Calendar, ArrowRight, DollarSign, RefreshCw } from 'lucide-react';
 20 | 
 21 | interface GroupedTransactions {
 22 |     [key: string]: ITransaction[];
 23 | }
 24 | 
 25 | // Mock transaction data for testing
 26 | const MOCK_TRANSACTIONS: ITransaction[] = [
 27 |     {
 28 |         _id: '507f1f77bcf86cd799439011',
 29 |         payer_bank_account_id: 'BA001',
 30 |         payee_bank_account_id: 'BA002',
 31 |         payer_name: 'John Smith',
 32 |         payer_email: 'john.smith@example.com',
 33 |         payee_name: 'Acme Corporation',
 34 |         payee_email: 'billing@acme.com',
 35 |         invoiceId: 'INV-2024-001',
 36 |         amount: 1250.00,
 37 |         transaction_date: '2024-04-15T10:30:00Z',
 38 |         status: 'completed',
 39 |         createdAt: '2024-04-15T10:30:00Z',
 40 |         updatedAt: '2024-04-15T10:30:00Z',
 41 |     },
 42 |     {
 43 |         _id: '507f1f77bcf86cd799439012',
 44 |         payer_bank_account_id: 'BA003',
 45 |         payee_bank_account_id: 'BA004',
 46 |         payer_name: 'Sarah Johnson',
 47 |         payer_email: 'sarah.j@company.com',
 48 |         payee_name: 'Tech Solutions Inc',
 49 |         payee_email: 'payments@techsolutions.com',
 50 |         invoiceId: 'INV-2024-002',
 51 |         amount: 3500.50,
 52 |         transaction_date: '2024-04-20T14:45:00Z',
 53 |         status: 'pending',
 54 |         createdAt: '2024-04-20T14:45:00Z',
 55 |         updatedAt: '2024-04-20T14:45:00Z',
 56 |     },
 57 |     {
 58 |         _id: '507f1f77bcf86cd799439013',
 59 |         payer_bank_account_id: 'BA005',
 60 |         payee_bank_account_id: 'BA006',
 61 |         payer_name: 'Michael Brown',
 62 |         payer_email: 'mbrown@business.com',
 63 |         payee_name: 'Global Services Ltd',
 64 |         payee_email: 'finance@globalservices.com',
 65 |         invoiceId: 'INV-2024-003',
 66 |         amount: 875.25,
 67 |         transaction_date: '2024-04-22T09:15:00Z',
 68 |         status: 'completed',
 69 |         createdAt: '2024-04-22T09:15:00Z',
 70 |         updatedAt: '2024-04-22T09:15:00Z',
 71 |     },
 72 |     {
 73 |         _id: '507f1f77bcf86cd799439014',
 74 |         payer_bank_account_id: 'BA007',
 75 |         payee_bank_account_id: 'BA008',
 76 |         payer_name: 'Emily Davis',
 77 |         payer_email: 'emily.davis@startup.io',
 78 |         payee_name: 'Cloud Hosting Pro',
 79 |         payee_email: 'billing@cloudhosting.com',
 80 |         invoiceId: 'INV-2024-004',
 81 |         amount: 299.99,
 82 |         transaction_date: '2024-03-28T16:20:00Z',
 83 |         status: 'failed',
 84 |         createdAt: '2024-03-28T16:20:00Z',
 85 |         updatedAt: '2024-03-28T16:20:00Z',
 86 |     },
 87 |     {
 88 |         _id: '507f1f77bcf86cd799439015',
 89 |         payer_bank_account_id: 'BA009',
 90 |         payee_bank_account_id: 'BA010',
 91 |         payer_name: 'David Wilson',
 92 |         payer_email: 'dwilson@enterprise.com',
 93 |         payee_name: 'Marketing Agency Plus',
 94 |         payee_email: 'accounts@marketingplus.com',
 95 |         invoiceId: 'INV-2024-005',
 96 |         amount: 5200.00,
 97 |         transaction_date: '2024-03-15T11:00:00Z',
 98 |         status: 'completed',
 99 |         createdAt: '2024-03-15T11:00:00Z',
100 |         updatedAt: '2024-03-15T11:00:00Z',
101 |     },
102 |     {
103 |         _id: '507f1f77bcf86cd799439016',
104 |         payer_bank_account_id: 'BA011',
105 |         payee_bank_account_id: 'BA012',
106 |         payer_name: 'Lisa Anderson',
107 |         payer_email: 'lisa.a@consulting.com',
108 |         payee_name: 'Office Supplies Co',
109 |         payee_email: 'sales@officesupplies.com',
110 |         invoiceId: 'INV-2024-006',
111 |         amount: 450.75,
112 |         transaction_date: '2024-03-10T13:30:00Z',
113 |         status: 'completed',
114 |         createdAt: '2024-03-10T13:30:00Z',
115 |         updatedAt: '2024-03-10T13:30:00Z',
116 |     },
117 |     {
118 |         _id: '507f1f77bcf86cd799439017',
119 |         payer_bank_account_id: 'BA013',
120 |         payee_bank_account_id: 'BA014',
121 |         payer_name: 'Robert Taylor',
122 |         payer_email: 'rtaylor@finance.com',
123 |         payee_name: 'Legal Services Group',
124 |         payee_email: 'billing@legalservices.com',
125 |         invoiceId: 'INV-2024-007',
126 |         amount: 2800.00,
127 |         transaction_date: '2024-02-25T10:00:00Z',
128 |         status: 'pending',
129 |         createdAt: '2024-02-25T10:00:00Z',
130 |         updatedAt: '2024-02-25T10:00:00Z',
131 |     },
132 |     {
133 |         _id: '507f1f77bcf86cd799439018',
134 |         payer_bank_account_id: 'BA015',
135 |         payee_bank_account_id: 'BA016',
136 |         payer_name: 'Jennifer Martinez',
137 |         payer_email: 'jmartinez@retail.com',
138 |         payee_name: 'Shipping Solutions',
139 |         payee_email: 'payments@shippingsolutions.com',
140 |         invoiceId: 'INV-2024-008',
141 |         amount: 1150.50,
142 |         transaction_date: '2024-02-18T15:45:00Z',
143 |         status: 'completed',
144 |         createdAt: '2024-02-18T15:45:00Z',
145 |         updatedAt: '2024-02-18T15:45:00Z',
146 |     },
147 |     {
148 |         _id: '507f1f77bcf86cd799439019',
149 |         payer_bank_account_id: 'BA017',
150 |         payee_bank_account_id: 'BA018',
151 |         payer_name: 'Christopher Lee',
152 |         payer_email: 'clee@manufacturing.com',
153 |         payee_name: 'Equipment Rentals Inc',
154 |         payee_email: 'billing@equipmentrentals.com',
155 |         invoiceId: 'INV-2024-009',
156 |         amount: 4500.00,
157 |         transaction_date: '2024-02-05T09:30:00Z',
158 |         status: 'cancelled',
159 |         createdAt: '2024-02-05T09:30:00Z',
160 |         updatedAt: '2024-02-05T09:30:00Z',
161 |     },
162 |     {
163 |         _id: '507f1f77bcf86cd799439020',
164 |         payer_bank_account_id: 'BA019',
165 |         payee_bank_account_id: 'BA020',
166 |         payer_name: 'Amanda White',
167 |         payer_email: 'awhite@healthcare.com',
168 |         payee_name: 'Medical Supplies Direct',
169 |         payee_email: 'orders@medicalsupplies.com',
170 |         invoiceId: 'INV-2024-010',
171 |         amount: 6750.25,
172 |         transaction_date: '2024-01-30T12:00:00Z',
173 |         status: 'completed',
174 |         createdAt: '2024-01-30T12:00:00Z',
175 |         updatedAt: '2024-01-30T12:00:00Z',
176 |     },
177 | ];
178 | 
179 | const AdminTransaction = () => {
180 |     const [transactions, setTransactions] = useState<ITransaction[]>([]);
181 |     const [loading, setLoading] = useState(true);
182 |     const [error, setError] = useState<string | null>(null);
183 |     const [useMockData, setUseMockData] = useState(false);
184 | 
185 |     useEffect(() => {
186 |         fetchTransactions();
187 |     }, []);
188 | 
189 |     const fetchTransactions = async () => {
190 |         try {
191 |             setLoading(true);
192 |             setError(null);
193 |             const response = await getAllTransactions({ limit: 1000 });
194 |             const fetchedTransactions = response.data.transactions || [];
195 |             
196 |             // Use mock data if no transactions are returned
197 |             if (fetchedTransactions.length === 0) {
198 |                 setTransactions(MOCK_TRANSACTIONS);
199 |                 setUseMockData(true);
200 |             } else {
201 |                 setTransactions(fetchedTransactions);
202 |                 setUseMockData(false);
203 |             }
204 |         } catch (err: any) {
205 |             // Use mock data on error for testing
206 |             setTransactions(MOCK_TRANSACTIONS);
207 |             setUseMockData(true);
208 |             setError(null); // Clear error when using mock data
209 |         } finally {
210 |             setLoading(false);
211 |         }
212 |     };
213 | 
214 |     const toggleMockData = () => {
215 |         if (useMockData) {
216 |             fetchTransactions();
217 |         } else {
218 |             setTransactions(MOCK_TRANSACTIONS);
219 |             setUseMockData(true);
220 |         }
221 |     };
222 | 
223 |     // Group transactions by month
224 |     const groupTransactionsByMonth = (transactions: ITransaction[]): GroupedTransactions => {
225 |         return transactions.reduce((acc: GroupedTransactions, transaction) => {
226 |             const date = new Date(transaction.transaction_date);
227 |             const monthYear = date.toLocaleDateString('en-US', { 
228 |                 year: 'numeric', 
229 |                 month: 'long' 
230 |             });
231 |             
232 |             if (!acc[monthYear]) {
233 |                 acc[monthYear] = [];
234 |             }
235 |             acc[monthYear].push(transaction);
236 |             return acc;
237 |         }, {});
238 |     };
239 | 
240 |     // Sort months in descending order (most recent first)
241 |     const getSortedMonths = (groupedTransactions: GroupedTransactions): string[] => {
242 |         return Object.keys(groupedTransactions).sort((a, b) => {
243 |             const dateA = new Date(a);
244 |             const dateB = new Date(b);
245 |             return dateB.getTime() - dateA.getTime();
246 |         });
247 |     };
248 | 
249 |     const formatDate = (dateString: string) => {
250 |         return new Date(dateString).toLocaleDateString('en-US', {
251 |             year: 'numeric',
252 |             month: 'short',
253 |             day: 'numeric',
254 |             hour: '2-digit',
255 |             minute: '2-digit',
256 |         });
257 |     };
258 | 
259 |     const formatCurrency = (amount: number) => {
260 |         return new Intl.NumberFormat('en-US', {
261 |             style: 'currency',
262 |             currency: 'USD',
263 |         }).format(amount);
264 |     };
265 | 
266 |     const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
267 |         switch (status.toLowerCase()) {
268 |             case 'completed':
269 |             case 'success':
270 |                 return 'default';
271 |             case 'pending':
272 |                 return 'secondary';
273 |             case 'failed':
274 |             case 'cancelled':
275 |                 return 'destructive';
276 |             default:
277 |                 return 'outline';
278 |         }
279 |     };
280 | 
281 |     if (loading) {
282 |         return (
283 |             <div className="flex items-center justify-center min-h-[400px]">
284 |                 <div className="text-center">
285 |                     <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
286 |                     <p className="mt-4 text-muted-foreground">Loading transactions...</p>
287 |                 </div>
288 |             </div>
289 |         );
290 |     }
291 | 
292 |     if (error) {
293 |         return (
294 |             <div className="flex items-center justify-center min-h-[400px]">
295 |                 <Card className="w-full max-w-md">
296 |                     <CardHeader>
297 |                         <CardTitle className="text-destructive">Error</CardTitle>
298 |                         <CardDescription>{error}</CardDescription>
299 |                     </CardHeader>
300 |                 </Card>
301 |             </div>
302 |         );
303 |     }
304 | 
305 |     if (transactions.length === 0) {
306 |         return (
307 |             <div className="flex items-center justify-center min-h-[400px]">
308 |                 <Card className="w-full max-w-md">
309 |                     <CardHeader>
310 |                         <CardTitle>No Transactions</CardTitle>
311 |                         <CardDescription>
312 |                             There are no transactions to display at this time.
313 |                         </CardDescription>
314 |                     </CardHeader>
315 |                 </Card>
316 |             </div>
317 |         );
318 |     }
319 | 
320 |     const groupedTransactions = groupTransactionsByMonth(transactions);
321 |     const sortedMonths = getSortedMonths(groupedTransactions);
322 | 
323 |     return (
324 |         <div className="container mx-auto py-6 px-4 max-w-7xl">
325 |             <div className="mb-6 space-y-4">
326 |                 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
327 |                     <div>
328 |                         <h1 className="text-3xl font-bold tracking-tight">All Transactions</h1>
329 |                         <p className="text-muted-foreground mt-2">
330 |                             View and manage all transactions grouped by month
331 |                         </p>
332 |                     </div>
333 |                     <div className="flex items-center gap-2">
334 |                         {useMockData && (
335 |                             <Badge variant="secondary" className="text-xs">
336 |                                 Mock Data
337 |                             </Badge>
338 |                         )}
339 |                         <Button
340 |                             variant="outline"
341 |                             size="sm"
342 |                             onClick={toggleMockData}
343 |                             className="gap-2"
344 |                         >
345 |                             <RefreshCw className="h-4 w-4" />
346 |                             {useMockData ? 'Load Real Data' : 'Use Mock Data'}
347 |                         </Button>
348 |                     </div>
349 |                 </div>
350 | 
351 |                 {/* Summary Cards */}
352 |                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
353 |                     <Card>
354 |                         <CardHeader className="pb-2">
355 |                             <CardDescription>Total Transactions</CardDescription>
356 |                             <CardTitle className="text-2xl">{transactions.length}</CardTitle>
357 |                         </CardHeader>
358 |                     </Card>
359 |                     <Card>
360 |                         <CardHeader className="pb-2">
361 |                             <CardDescription>Total Amount</CardDescription>
362 |                             <CardTitle className="text-2xl">
363 |                                 {formatCurrency(transactions.reduce((sum, t) => sum + t.amount, 0))}
364 |                             </CardTitle>
365 |                         </CardHeader>
366 |                     </Card>
367 |                     <Card>
368 |                         <CardHeader className="pb-2">
369 |                             <CardDescription>Completed</CardDescription>
370 |                             <CardTitle className="text-2xl text-green-600">
371 |                                 {transactions.filter(t => t.status.toLowerCase() === 'completed').length}
372 |                             </CardTitle>
373 |                         </CardHeader>
374 |                     </Card>
375 |                     <Card>
376 |                         <CardHeader className="pb-2">
377 |                             <CardDescription>Pending</CardDescription>
378 |                             <CardTitle className="text-2xl text-yellow-600">
379 |                                 {transactions.filter(t => t.status.toLowerCase() === 'pending').length}
380 |                             </CardTitle>
381 |                         </CardHeader>
382 |                     </Card>
383 |                 </div>
384 |             </div>
385 | 
386 |             <Accordion type="multiple" className="w-full space-y-4">
387 |                 {sortedMonths.map((month) => {
388 |                     const monthTransactions = groupedTransactions[month];
389 |                     const totalAmount = monthTransactions.reduce(
390 |                         (sum, t) => sum + t.amount,
391 |                         0
392 |                     );
393 | 
394 |                     return (
395 |                         <AccordionItem
396 |                             key={month}
397 |                             value={month}
398 |                             className="border rounded-lg px-4 bg-card"
399 |                         >
400 |                             <AccordionTrigger className="hover:no-underline py-4">
401 |                                 <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between w-full pr-4 gap-2">
402 |                                     <div className="flex items-center gap-3">
403 |                                         <Calendar className="h-5 w-5 text-primary flex-shrink-0" />
404 |                                         <div className="text-left">
405 |                                             <h3 className="text-base sm:text-lg font-semibold">{month}</h3>
406 |                                             <p className="text-xs sm:text-sm text-muted-foreground">
407 |                                                 {monthTransactions.length} transaction
408 |                                                 {monthTransactions.length !== 1 ? 's' : ''}
409 |                                             </p>
410 |                                         </div>
411 |                                     </div>
412 |                                     <div className="flex items-center gap-2 sm:ml-auto">
413 |                                         <DollarSign className="h-4 w-4 text-muted-foreground" />
414 |                                         <span className="font-semibold text-sm sm:text-base">
415 |                                             {formatCurrency(totalAmount)}
416 |                                         </span>
417 |                                     </div>
418 |                                 </div>
419 |                             </AccordionTrigger>
420 |                             <AccordionContent>
421 |                                 <div className="space-y-3 pt-4">
422 |                                     {monthTransactions.map((transaction) => (
423 |                                         <Card key={transaction._id} className="overflow-hidden hover:shadow-md transition-shadow">
424 |                                             <CardContent className="p-4 sm:p-6">
425 |                                                 <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
426 |                                                     <div className="flex-1 space-y-3">
427 |                                                         {/* Status and Date */}
428 |                                                         <div className="flex flex-wrap items-center gap-2 sm:gap-3">
429 |                                                             <Badge
430 |                                                                 variant={getStatusVariant(transaction.status)}
431 |                                                                 className="capitalize"
432 |                                                             >
433 |                                                                 {transaction.status}
434 |                                                             </Badge>
435 |                                                             <span className="text-xs sm:text-sm text-muted-foreground">
436 |                                                                 {formatDate(transaction.transaction_date)}
437 |                                                             </span>
438 |                                                         </div>
439 |                                                         
440 |                                                         {/* Payer and Payee Info */}
441 |                                                         <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-2 text-sm">
442 |                                                             <div className="flex-1 min-w-0">
443 |                                                                 <p className="font-medium text-sm sm:text-base truncate">
444 |                                                                     {transaction.payer_name}
445 |                                                                 </p>
446 |                                                                 <p className="text-muted-foreground text-xs truncate">
447 |                                                                     {transaction.payer_email}
448 |                                                                 </p>
449 |                                                             </div>
450 |                                                             <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0 hidden sm:block" />
451 |                                                             <div className="flex items-center gap-2 sm:hidden">
452 |                                                                 <ArrowRight className="h-3 w-3 text-muted-foreground" />
453 |                                                                 <span className="text-xs text-muted-foreground">to</span>
454 |                                                             </div>
455 |                                                             <div className="flex-1 min-w-0">
456 |                                                                 <p className="font-medium text-sm sm:text-base truncate">
457 |                                                                     {transaction.payee_name}
458 |                                                                 </p>
459 |                                                                 <p className="text-muted-foreground text-xs truncate">
460 |                                                                     {transaction.payee_email}
461 |                                                                 </p>
462 |                                                             </div>
463 |                                                         </div>
464 | 
465 |                                                         {/* Transaction Details */}
466 |                                                         <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-xs text-muted-foreground pt-2 border-t">
467 |                                                             <span className="flex items-center gap-1">
468 |                                                                 <span className="font-medium">Invoice:</span>
469 |                                                                 <span className="font-mono">{transaction.invoiceId}</span>
470 |                                                             </span>
471 |                                                             <span className="flex items-center gap-1">
472 |                                                                 <span className="font-medium">ID:</span>
473 |                                                                 <span className="font-mono">{transaction._id.slice(-8)}</span>
474 |                                                             </span>
475 |                                                         </div>
476 |                                                     </div>
477 |                                                     
478 |                                                     {/* Amount */}
479 |                                                     <div className="text-left lg:text-right lg:pl-4 border-t lg:border-t-0 lg:border-l pt-3 lg:pt-0">
480 |                                                         <p className="text-xs text-muted-foreground mb-1">Amount</p>
481 |                                                         <p className="text-xl sm:text-2xl font-bold text-primary">
482 |                                                             {formatCurrency(transaction.amount)}
483 |                                                         </p>
484 |                                                     </div>
485 |                                                 </div>
486 |                                             </CardContent>
487 |                                         </Card>
488 |                                     ))}
489 |                                 </div>
490 |                             </AccordionContent>
491 |                         </AccordionItem>
492 |                     );
493 |                 })}
494 |             </Accordion>
495 |         </div>
496 |     );
497 | };
498 | 
499 | export default AdminTransaction;
500 | 
501 | // Made with Bob
</content>
</file>
<file><path>frontend/src/page/admin/billing_detail/index.tsx</path>
<content lines="1-347">
  1 | import { useState } from 'react';
  2 | // import { getAllUsers, deleteUser } from '@/service/user';
  3 | import type { IUser } from '@/service/user/interface';
  4 | import { Button } from '@/components/ui/button';
  5 | import {
  6 |     Card,
  7 |     CardContent,
  8 |     CardDescription,
  9 |     CardHeader,
 10 |     CardTitle,
 11 | } from '@/components/ui/card';
 12 | import {
 13 |     Dialog,
 14 |     DialogContent,
 15 |     DialogDescription,
 16 |     DialogFooter,
 17 |     DialogHeader,
 18 |     DialogTitle,
 19 | } from '@/components/ui/dialog';
 20 | import { Trash2, Eye, Loader2 } from 'lucide-react';
 21 | 
 22 | // Mock employee data
 23 | const MOCK_EMPLOYEES: IUser[] = [
 24 |     {
 25 |         id: '1',
 26 |         name: 'John Doe',
 27 |         email: 'john.doe@example.com',
 28 |         phone: '+1 (555) 123-4567',
 29 |         role: 'employee',
 30 |         isVerify: true,
 31 |         createdAt: '2024-01-15T10:30:00Z',
 32 |         updatedAt: '2024-04-20T14:45:00Z',
 33 |     },
 34 |     {
 35 |         id: '2',
 36 |         name: 'Jane Smith',
 37 |         email: 'jane.smith@example.com',
 38 |         phone: '+1 (555) 234-5678',
 39 |         role: 'employee',
 40 |         isVerify: true,
 41 |         createdAt: '2024-02-10T09:15:00Z',
 42 |         updatedAt: '2024-04-18T11:20:00Z',
 43 |     },
 44 |     {
 45 |         id: '3',
 46 |         name: 'Michael Johnson',
 47 |         email: 'michael.j@example.com',
 48 |         phone: '+1 (555) 345-6789',
 49 |         role: 'employee',
 50 |         isVerify: false,
 51 |         createdAt: '2024-03-05T13:45:00Z',
 52 |         updatedAt: '2024-03-05T13:45:00Z',
 53 |     },
 54 |     {
 55 |         id: '4',
 56 |         name: 'Emily Davis',
 57 |         email: 'emily.davis@example.com',
 58 |         phone: '+1 (555) 456-7890',
 59 |         role: 'employee',
 60 |         isVerify: true,
 61 |         createdAt: '2024-01-20T08:00:00Z',
 62 |         updatedAt: '2024-04-22T16:30:00Z',
 63 |     },
 64 |     {
 65 |         id: '5',
 66 |         name: 'Robert Wilson',
 67 |         email: 'robert.w@example.com',
 68 |         phone: '+1 (555) 567-8901',
 69 |         role: 'employee',
 70 |         isVerify: false,
 71 |         createdAt: '2024-04-01T12:00:00Z',
 72 |         updatedAt: '2024-04-01T12:00:00Z',
 73 |     },
 74 | ];
 75 | 
 76 | const AdminBillingDetail = () => {
 77 |     const [employees, setEmployees] = useState<IUser[]>(MOCK_EMPLOYEES);
 78 |     const [loading, setLoading] = useState(false);
 79 |     const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
 80 |     const [viewDialogOpen, setViewDialogOpen] = useState(false);
 81 |     const [selectedEmployee, setSelectedEmployee] = useState<IUser | null>(null);
 82 |     const [deleting, setDeleting] = useState(false);
 83 |     const [error, setError] = useState<string | null>(null);
 84 |     const [successMessage, setSuccessMessage] = useState<string | null>(null);
 85 | 
 86 |     // Handle delete employee (mock implementation)
 87 |     const handleDelete = () => {
 88 |         if (!selectedEmployee) return;
 89 | 
 90 |         setDeleting(true);
 91 |         setError(null);
 92 |         
 93 |         // Simulate API delay
 94 |         setTimeout(() => {
 95 |             // Remove employee from mock data
 96 |             setEmployees(employees.filter(emp => emp.id !== selectedEmployee.id));
 97 |             setSuccessMessage('Employee deleted successfully');
 98 |             setDeleteDialogOpen(false);
 99 |             setSelectedEmployee(null);
100 |             setDeleting(false);
101 |             
102 |             // Clear success message after 3 seconds
103 |             setTimeout(() => setSuccessMessage(null), 3000);
104 |         }, 500);
105 |     };
106 | 
107 |     // Open delete dialog
108 |     const openDeleteDialog = (employee: IUser) => {
109 |         setSelectedEmployee(employee);
110 |         setDeleteDialogOpen(true);
111 |     };
112 | 
113 |     // Open view dialog
114 |     const openViewDialog = (employee: IUser) => {
115 |         setSelectedEmployee(employee);
116 |         setViewDialogOpen(true);
117 |     };
118 | 
119 |     // Format date
120 |     const formatDate = (dateString: string) => {
121 |         return new Date(dateString).toLocaleDateString('en-US', {
122 |             year: 'numeric',
123 |             month: 'short',
124 |             day: 'numeric',
125 |             hour: '2-digit',
126 |             minute: '2-digit',
127 |         });
128 |     };
129 | 
130 |     return (
131 |         <div className="container mx-auto py-8 px-4">
132 |             {/* Success Message */}
133 |             {successMessage && (
134 |                 <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md">
135 |                     {successMessage}
136 |                 </div>
137 |             )}
138 | 
139 |             {/* Error Message */}
140 |             {error && (
141 |                 <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
142 |                     {error}
143 |                 </div>
144 |             )}
145 | 
146 |             <Card>
147 |                 <CardHeader>
148 |                     <CardTitle>Manage Employees</CardTitle>
149 |                     <CardDescription>
150 |                         View and manage all registered employees (non-admin users)
151 |                     </CardDescription>
152 |                 </CardHeader>
153 |                 <CardContent>
154 |                     {loading ? (
155 |                         <div className="flex justify-center items-center py-12">
156 |                             <Loader2 className="h-8 w-8 animate-spin text-primary" />
157 |                         </div>
158 |                     ) : employees.length === 0 ? (
159 |                         <div className="text-center py-12 text-muted-foreground">
160 |                             No employees found
161 |                         </div>
162 |                     ) : (
163 |                         <div className="overflow-x-auto">
164 |                             <table className="w-full border-collapse">
165 |                                 <thead>
166 |                                     <tr className="border-b bg-muted/50">
167 |                                         <th className="text-left p-4 font-semibold">Name</th>
168 |                                         <th className="text-left p-4 font-semibold">Email</th>
169 |                                         <th className="text-left p-4 font-semibold">Phone</th>
170 |                                         <th className="text-left p-4 font-semibold">Status</th>
171 |                                         <th className="text-left p-4 font-semibold">Joined</th>
172 |                                         <th className="text-center p-4 font-semibold">Actions</th>
173 |                                     </tr>
174 |                                 </thead>
175 |                                 <tbody>
176 |                                     {employees.map((employee) => (
177 |                                         <tr
178 |                                             key={employee.id}
179 |                                             className="border-b hover:bg-muted/30 transition-colors"
180 |                                         >
181 |                                             <td className="p-4">{employee.name}</td>
182 |                                             <td className="p-4">{employee.email}</td>
183 |                                             <td className="p-4">{employee.phone}</td>
184 |                                             <td className="p-4">
185 |                                                 <span
186 |                                                     className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
187 |                                                         employee.isVerify
188 |                                                             ? 'bg-green-100 text-green-800'
189 |                                                             : 'bg-yellow-100 text-yellow-800'
190 |                                                     }`}
191 |                                                 >
192 |                                                     {employee.isVerify ? 'Verified' : 'Pending'}
193 |                                                 </span>
194 |                                             </td>
195 |                                             <td className="p-4 text-sm text-muted-foreground">
196 |                                                 {formatDate(employee.createdAt)}
197 |                                             </td>
198 |                                             <td className="p-4">
199 |                                                 <div className="flex justify-center gap-2">
200 |                                                     <Button
201 |                                                         variant="outline"
202 |                                                         size="sm"
203 |                                                         onClick={() => openViewDialog(employee)}
204 |                                                     >
205 |                                                         <Eye className="h-4 w-4 mr-1" />
206 |                                                         View
207 |                                                     </Button>
208 |                                                     <Button
209 |                                                         variant="destructive"
210 |                                                         size="sm"
211 |                                                         onClick={() => openDeleteDialog(employee)}
212 |                                                     >
213 |                                                         <Trash2 className="h-4 w-4 mr-1" />
214 |                                                         Delete
215 |                                                     </Button>
216 |                                                 </div>
217 |                                             </td>
218 |                                         </tr>
219 |                                     ))}
220 |                                 </tbody>
221 |                             </table>
222 |                         </div>
223 |                     )}
224 |                 </CardContent>
225 |             </Card>
226 | 
227 |             {/* View Employee Dialog */}
228 |             <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
229 |                 <DialogContent>
230 |                     <DialogHeader>
231 |                         <DialogTitle>Employee Details</DialogTitle>
232 |                         <DialogDescription>
233 |                             View detailed information about the employee
234 |                         </DialogDescription>
235 |                     </DialogHeader>
236 |                     {selectedEmployee && (
237 |                         <div className="space-y-4">
238 |                             <div>
239 |                                 <label className="text-sm font-semibold text-muted-foreground">
240 |                                     Name
241 |                                 </label>
242 |                                 <p className="text-base mt-1">{selectedEmployee.name}</p>
243 |                             </div>
244 |                             <div>
245 |                                 <label className="text-sm font-semibold text-muted-foreground">
246 |                                     Email
247 |                                 </label>
248 |                                 <p className="text-base mt-1">{selectedEmployee.email}</p>
249 |                             </div>
250 |                             <div>
251 |                                 <label className="text-sm font-semibold text-muted-foreground">
252 |                                     Phone
253 |                                 </label>
254 |                                 <p className="text-base mt-1">{selectedEmployee.phone}</p>
255 |                             </div>
256 |                             <div>
257 |                                 <label className="text-sm font-semibold text-muted-foreground">
258 |                                     Role
259 |                                 </label>
260 |                                 <p className="text-base mt-1 capitalize">{selectedEmployee.role}</p>
261 |                             </div>
262 |                             <div>
263 |                                 <label className="text-sm font-semibold text-muted-foreground">
264 |                                     Verification Status
265 |                                 </label>
266 |                                 <p className="text-base mt-1">
267 |                                     {selectedEmployee.isVerify ? 'Verified' : 'Not Verified'}
268 |                                 </p>
269 |                             </div>
270 |                             <div>
271 |                                 <label className="text-sm font-semibold text-muted-foreground">
272 |                                     Joined Date
273 |                                 </label>
274 |                                 <p className="text-base mt-1">
275 |                                     {formatDate(selectedEmployee.createdAt)}
276 |                                 </p>
277 |                             </div>
278 |                             <div>
279 |                                 <label className="text-sm font-semibold text-muted-foreground">
280 |                                     Last Updated
281 |                                 </label>
282 |                                 <p className="text-base mt-1">
283 |                                     {formatDate(selectedEmployee.updatedAt)}
284 |                                 </p>
285 |                             </div>
286 |                         </div>
287 |                     )}
288 |                     <DialogFooter>
289 |                         <Button variant="outline" onClick={() => setViewDialogOpen(false)}>
290 |                             Close
291 |                         </Button>
292 |                     </DialogFooter>
293 |                 </DialogContent>
294 |             </Dialog>
295 | 
296 |             {/* Delete Confirmation Dialog */}
297 |             <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
298 |                 <DialogContent>
299 |                     <DialogHeader>
300 |                         <DialogTitle>Confirm Deletion</DialogTitle>
301 |                         <DialogDescription>
302 |                             Are you sure you want to delete this employee? This action cannot be
303 |                             undone.
304 |                         </DialogDescription>
305 |                     </DialogHeader>
306 |                     {selectedEmployee && (
307 |                         <div className="py-4">
308 |                             <p className="text-sm">
309 |                                 <span className="font-semibold">Name:</span> {selectedEmployee.name}
310 |                             </p>
311 |                             <p className="text-sm">
312 |                                 <span className="font-semibold">Email:</span> {selectedEmployee.email}
313 |                             </p>
314 |                         </div>
315 |                     )}
316 |                     <DialogFooter>
317 |                         <Button
318 |                             variant="outline"
319 |                             onClick={() => setDeleteDialogOpen(false)}
320 |                             disabled={deleting}
321 |                         >
322 |                             Cancel
323 |                         </Button>
324 |                         <Button
325 |                             variant="destructive"
326 |                             onClick={handleDelete}
327 |                             disabled={deleting}
328 |                         >
329 |                             {deleting ? (
330 |                                 <>
331 |                                     <Loader2 className="h-4 w-4 mr-2 animate-spin" />
332 |                                     Deleting...
333 |                                 </>
334 |                             ) : (
335 |                                 'Delete'
336 |                             )}
337 |                         </Button>
338 |                     </DialogFooter>
339 |                 </DialogContent>
340 |             </Dialog>
341 |         </div>
342 |     );
343 | };
344 | 
345 | export default AdminBillingDetail;
346 | 
347 | // Made with Bob
</content>
</file>
<file><path>frontend/src/page/invoice/index.tsx</path>
<content lines="1-446">
  1 | import { useState, useEffect } from 'react';
  2 | import { Eye, FileText, Calendar, User, Mail, Phone, DollarSign, FileCheck } from 'lucide-react';
  3 | import { Card, CardContent } from '@/components/ui/card';
  4 | import { Button } from '@/components/ui/button';
  5 | import { Badge } from '@/components/ui/badge';
  6 | import {
  7 |     Dialog,
  8 |     DialogContent,
  9 |     DialogHeader,
 10 |     DialogTitle,
 11 |     DialogDescription,
 12 | } from '@/components/ui/dialog';
 13 | import { getPaginatedInvoices, getInvoiceById as getMockInvoiceById } from '@/data/mockInvoices';
 14 | 
 15 | interface Invoice {
 16 |     id: string;
 17 |     invoice_number: string;
 18 |     invoice_date: string;
 19 |     customer_name: string;
 20 |     customer_email?: string;
 21 |     customer_phone?: string;
 22 |     total_amount: number;
 23 |     payment_status: string;
 24 |     status: string;
 25 |     notes?: string;
 26 |     created_at?: string;
 27 |     updated_at?: string;
 28 | }
 29 | 
 30 | const Invoice = () => {
 31 |     const [invoices, setInvoices] = useState<Invoice[]>([]);
 32 |     const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
 33 |     const [isDialogOpen, setIsDialogOpen] = useState(false);
 34 |     const [loading, setLoading] = useState(true);
 35 |     const [page, setPage] = useState(1);
 36 |     const [totalPages, setTotalPages] = useState(1);
 37 | 
 38 |     // Fetch invoices
 39 |     useEffect(() => {
 40 |         fetchInvoices();
 41 |     }, [page]);
 42 | 
 43 |     const fetchInvoices = async () => {
 44 |         try {
 45 |             setLoading(true);
 46 |             // Using mock data instead of API call
 47 |             const response = getPaginatedInvoices(page, 10);
 48 |             setInvoices(response.data || []);
 49 |             setTotalPages(response.pagination?.totalPages || 1);
 50 |         } catch (error) {
 51 |             console.error('Error fetching invoices:', error);
 52 |         } finally {
 53 |             setLoading(false);
 54 |         }
 55 |     };
 56 | 
 57 |     // View invoice details
 58 |     const handleViewInvoice = async (invoiceId: string) => {
 59 |         try {
 60 |             // Using mock data instead of API call
 61 |             const invoice = getMockInvoiceById(invoiceId);
 62 |             if (invoice) {
 63 |                 setSelectedInvoice(invoice);
 64 |                 setIsDialogOpen(true);
 65 |             }
 66 |         } catch (error) {
 67 |             console.error('Error fetching invoice details:', error);
 68 |         }
 69 |     };
 70 | 
 71 |     // Get payment status badge variant
 72 |     const getPaymentStatusVariant = (status: string) => {
 73 |         switch (status?.toLowerCase()) {
 74 |             case 'paid':
 75 |                 return 'default';
 76 |             case 'pending':
 77 |                 return 'secondary';
 78 |             case 'overdue':
 79 |                 return 'destructive';
 80 |             default:
 81 |                 return 'outline';
 82 |         }
 83 |     };
 84 | 
 85 |     // Get status badge variant
 86 |     const getStatusVariant = (status: string) => {
 87 |         switch (status?.toLowerCase()) {
 88 |             case 'active':
 89 |                 return 'default';
 90 |             case 'draft':
 91 |                 return 'secondary';
 92 |             case 'cancelled':
 93 |                 return 'destructive';
 94 |             default:
 95 |                 return 'outline';
 96 |         }
 97 |     };
 98 | 
 99 |     // Format date
100 |     const formatDate = (dateString: string) => {
101 |         if (!dateString) return 'N/A';
102 |         return new Date(dateString).toLocaleDateString('en-US', {
103 |             year: 'numeric',
104 |             month: 'short',
105 |             day: 'numeric',
106 |         });
107 |     };
108 | 
109 |     // Format currency
110 |     const formatCurrency = (amount: number) => {
111 |         return new Intl.NumberFormat('en-US', {
112 |             style: 'currency',
113 |             currency: 'USD',
114 |         }).format(amount);
115 |     };
116 | 
117 |     return (
118 |         <div className="mx-auto py-8 px-4 max-w-7xl">
119 |             <div className="mb-6">
120 |                 <h1 className="text-3xl font-bold">Invoices</h1>
121 |                 <p className="text-muted-foreground mt-1">
122 |                     View and manage your invoices
123 |                 </p>
124 |             </div>
125 | 
126 |             {loading ? (
127 |                 <Card>
128 |                     <CardContent className="py-12 text-center">
129 |                         <p className="text-muted-foreground">Loading invoices...</p>
130 |                     </CardContent>
131 |                 </Card>
132 |             ) : invoices.length === 0 ? (
133 |                 <Card>
134 |                     <CardContent className="py-12 text-center">
135 |                         <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
136 |                         <h3 className="text-lg font-semibold mb-2">No invoices found</h3>
137 |                         <p className="text-muted-foreground">
138 |                             You don't have any invoices yet
139 |                         </p>
140 |                     </CardContent>
141 |                 </Card>
142 |             ) : (
143 |                 <>
144 |                     {/* Invoice Table */}
145 |                     <Card>
146 |                         <CardContent className="p-0">
147 |                             <div className="overflow-x-auto">
148 |                                 <table className="w-full">
149 |                                     <thead className="bg-muted/50 border-b">
150 |                                         <tr>
151 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
152 |                                                 Invoice #
153 |                                             </th>
154 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
155 |                                                 Customer
156 |                                             </th>
157 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
158 |                                                 Date
159 |                                             </th>
160 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
161 |                                                 Amount
162 |                                             </th>
163 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
164 |                                                 Payment Status
165 |                                             </th>
166 |                                             <th className="px-6 py-4 text-left text-sm font-semibold">
167 |                                                 Status
168 |                                             </th>
169 |                                             <th className="px-6 py-4 text-center text-sm font-semibold">
170 |                                                 Actions
171 |                                             </th>
172 |                                         </tr>
173 |                                     </thead>
174 |                                     <tbody className="divide-y">
175 |                                         {invoices.map((invoice) => (
176 |                                             <tr
177 |                                                 key={invoice.id}
178 |                                                 className="hover:bg-muted/30 transition-colors"
179 |                                             >
180 |                                                 <td className="px-6 py-4">
181 |                                                     <span className="font-medium">
182 |                                                         {invoice.invoice_number}
183 |                                                     </span>
184 |                                                 </td>
185 |                                                 <td className="px-6 py-4">
186 |                                                     <div>
187 |                                                         <p className="font-medium">
188 |                                                             {invoice.customer_name}
189 |                                                         </p>
190 |                                                         {invoice.customer_email && (
191 |                                                             <p className="text-sm text-muted-foreground">
192 |                                                                 {invoice.customer_email}
193 |                                                             </p>
194 |                                                         )}
195 |                                                     </div>
196 |                                                 </td>
197 |                                                 <td className="px-6 py-4 text-sm">
198 |                                                     {formatDate(invoice.invoice_date)}
199 |                                                 </td>
200 |                                                 <td className="px-6 py-4 font-semibold">
201 |                                                     {formatCurrency(invoice.total_amount)}
202 |                                                 </td>
203 |                                                 <td className="px-6 py-4">
204 |                                                     <Badge
205 |                                                         variant={getPaymentStatusVariant(
206 |                                                             invoice.payment_status
207 |                                                         )}
208 |                                                     >
209 |                                                         {invoice.payment_status}
210 |                                                     </Badge>
211 |                                                 </td>
212 |                                                 <td className="px-6 py-4">
213 |                                                     <Badge
214 |                                                         variant={getStatusVariant(invoice.status)}
215 |                                                     >
216 |                                                         {invoice.status}
217 |                                                     </Badge>
218 |                                                 </td>
219 |                                                 <td className="px-6 py-4 text-center">
220 |                                                     <Button
221 |                                                         variant="ghost"
222 |                                                         size="sm"
223 |                                                         onClick={() => handleViewInvoice(invoice.id)}
224 |                                                     >
225 |                                                         <Eye className="h-4 w-4 mr-2" />
226 |                                                         View
227 |                                                     </Button>
228 |                                                 </td>
229 |                                             </tr>
230 |                                         ))}
231 |                                     </tbody>
232 |                                 </table>
233 |                             </div>
234 |                         </CardContent>
235 |                     </Card>
236 | 
237 |                     {/* Pagination */}
238 |                     {totalPages > 1 && (
239 |                         <div className="mt-6 flex justify-center gap-2">
240 |                             <Button
241 |                                 variant="outline"
242 |                                 onClick={() => setPage((p) => Math.max(1, p - 1))}
243 |                                 disabled={page === 1}
244 |                             >
245 |                                 Previous
246 |                             </Button>
247 |                             <div className="flex items-center px-4">
248 |                                 <span className="text-sm text-muted-foreground">
249 |                                     Page {page} of {totalPages}
250 |                                 </span>
251 |                             </div>
252 |                             <Button
253 |                                 variant="outline"
254 |                                 onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
255 |                                 disabled={page === totalPages}
256 |                             >
257 |                                 Next
258 |                             </Button>
259 |                         </div>
260 |                     )}
261 |                 </>
262 |             )}
263 | 
264 |             {/* View Invoice Dialog */}
265 |             <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
266 |                 <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
267 |                     <DialogHeader>
268 |                         <DialogTitle className="flex items-center gap-2">
269 |                             <FileCheck className="h-5 w-5" />
270 |                             Invoice Details
271 |                         </DialogTitle>
272 |                         <DialogDescription>
273 |                             Complete information about this invoice
274 |                         </DialogDescription>
275 |                     </DialogHeader>
276 | 
277 |                     {selectedInvoice && (
278 |                         <div className="space-y-6 mt-4">
279 |                             {/* Invoice Header */}
280 |                             <div className="flex justify-between items-start pb-4 border-b">
281 |                                 <div>
282 |                                     <h3 className="text-2xl font-bold">
283 |                                         {selectedInvoice.invoice_number}
284 |                                     </h3>
285 |                                     <p className="text-sm text-muted-foreground mt-1">
286 |                                         Invoice Date: {formatDate(selectedInvoice.invoice_date)}
287 |                                     </p>
288 |                                 </div>
289 |                                 <div className="text-right">
290 |                                     <p className="text-sm text-muted-foreground mb-2">
291 |                                         Total Amount
292 |                                     </p>
293 |                                     <p className="text-2xl font-bold">
294 |                                         {formatCurrency(selectedInvoice.total_amount)}
295 |                                     </p>
296 |                                 </div>
297 |                             </div>
298 | 
299 |                             {/* Status Badges */}
300 |                             <div className="flex gap-3">
301 |                                 <div>
302 |                                     <p className="text-sm text-muted-foreground mb-2">
303 |                                         Payment Status
304 |                                     </p>
305 |                                     <Badge
306 |                                         variant={getPaymentStatusVariant(
307 |                                             selectedInvoice.payment_status
308 |                                         )}
309 |                                         className="text-sm px-3 py-1"
310 |                                     >
311 |                                         {selectedInvoice.payment_status}
312 |                                     </Badge>
313 |                                 </div>
314 |                                 <div>
315 |                                     <p className="text-sm text-muted-foreground mb-2">
316 |                                         Invoice Status
317 |                                     </p>
318 |                                     <Badge
319 |                                         variant={getStatusVariant(selectedInvoice.status)}
320 |                                         className="text-sm px-3 py-1"
321 |                                     >
322 |                                         {selectedInvoice.status}
323 |                                     </Badge>
324 |                                 </div>
325 |                             </div>
326 | 
327 |                             {/* Customer Information */}
328 |                             <div>
329 |                                 <h4 className="font-semibold mb-3 flex items-center gap-2">
330 |                                     <User className="h-4 w-4" />
331 |                                     Customer Information
332 |                                 </h4>
333 |                                 <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
334 |                                     <div className="flex items-start gap-3">
335 |                                         <User className="h-5 w-5 text-muted-foreground mt-0.5" />
336 |                                         <div>
337 |                                             <p className="text-sm font-medium text-muted-foreground">
338 |                                                 Name
339 |                                             </p>
340 |                                             <p className="text-base">
341 |                                                 {selectedInvoice.customer_name}
342 |                                             </p>
343 |                                         </div>
344 |                                     </div>
345 | 
346 |                                     {selectedInvoice.customer_email && (
347 |                                         <div className="flex items-start gap-3">
348 |                                             <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
349 |                                             <div>
350 |                                                 <p className="text-sm font-medium text-muted-foreground">
351 |                                                     Email
352 |                                                 </p>
353 |                                                 <p className="text-base">
354 |                                                     {selectedInvoice.customer_email}
355 |                                                 </p>
356 |                                             </div>
357 |                                         </div>
358 |                                     )}
359 | 
360 |                                     {selectedInvoice.customer_phone && (
361 |                                         <div className="flex items-start gap-3">
362 |                                             <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
363 |                                             <div>
364 |                                                 <p className="text-sm font-medium text-muted-foreground">
365 |                                                     Phone
366 |                                                 </p>
367 |                                                 <p className="text-base">
368 |                                                     {selectedInvoice.customer_phone}
369 |                                                 </p>
370 |                                             </div>
371 |                                         </div>
372 |                                     )}
373 |                                 </div>
374 |                             </div>
375 | 
376 |                             {/* Additional Details */}
377 |                             <div>
378 |                                 <h4 className="font-semibold mb-3 flex items-center gap-2">
379 |                                     <FileText className="h-4 w-4" />
380 |                                     Additional Details
381 |                                 </h4>
382 |                                 <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
383 |                                     <div className="flex items-start gap-3">
384 |                                         <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
385 |                                         <div>
386 |                                             <p className="text-sm font-medium text-muted-foreground">
387 |                                                 Invoice Date
388 |                                             </p>
389 |                                             <p className="text-base">
390 |                                                 {formatDate(selectedInvoice.invoice_date)}
391 |                                             </p>
392 |                                         </div>
393 |                                     </div>
394 | 
395 |                                     <div className="flex items-start gap-3">
396 |                                         <DollarSign className="h-5 w-5 text-muted-foreground mt-0.5" />
397 |                                         <div>
398 |                                             <p className="text-sm font-medium text-muted-foreground">
399 |                                                 Total Amount
400 |                                             </p>
401 |                                             <p className="text-base font-semibold">
402 |                                                 {formatCurrency(selectedInvoice.total_amount)}
403 |                                             </p>
404 |                                         </div>
405 |                                     </div>
406 | 
407 |                                     {selectedInvoice.notes && (
408 |                                         <div className="flex items-start gap-3">
409 |                                             <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
410 |                                             <div>
411 |                                                 <p className="text-sm font-medium text-muted-foreground">
412 |                                                     Notes
413 |                                                 </p>
414 |                                                 <p className="text-base">{selectedInvoice.notes}</p>
415 |                                             </div>
416 |                                         </div>
417 |                                     )}
418 |                                 </div>
419 |                             </div>
420 | 
421 |                             {/* Timestamps */}
422 |                             {(selectedInvoice.created_at || selectedInvoice.updated_at) && (
423 |                                 <div className="pt-4 border-t text-sm text-muted-foreground">
424 |                                     {selectedInvoice.created_at && (
425 |                                         <p>
426 |                                             Created: {formatDate(selectedInvoice.created_at)}
427 |                                         </p>
428 |                                     )}
429 |                                     {selectedInvoice.updated_at && (
430 |                                         <p>
431 |                                             Last Updated: {formatDate(selectedInvoice.updated_at)}
432 |                                         </p>
433 |                                     )}
434 |                                 </div>
435 |                             )}
436 |                         </div>
437 |                     )}
438 |                 </DialogContent>
439 |             </Dialog>
440 |         </div>
441 |     );
442 | };
443 | 
444 | export default Invoice;
445 | 
446 | // Made with Bob
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/transaction/index.tsx,frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T12:59:00.882Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.05

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

Now I'll create a comprehensive admin invoice page based on the backend controller and the patterns I've seen in other admin pages. Let me create the page:

<write_to_file>
<path>frontend/src/page/admin/invoice/index.tsx</path>
<content>
import { useEffect, useState } from 'react';
import { getAllInvoices, adminUpdateInvoice, adminDeleteInvoice } from '@/service/invoice';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {
    FileText,
    Eye,
    Edit,
    Trash2,
    Loader2,
    Calendar,
    DollarSign,
    User,
    Mail,
    Phone,
    RefreshCw,
} from 'lucide-react';

interface Invoice {
    id: string;
    invoice_number: string;
    invoice_date: string;
    customer_name: string;
    customer_email?: string;
    customer_phone?: string;
    total_amount: number;
    payment_status: 'pending' | 'partial' | 'paid' | 'overdue' | 'cancelled';
    status: 'draft' | 'sent' | 'viewed' | 'paid' | 'cancelled';
    notes?: string;
    userId: string;
    user?: {
        id: string;
        name: string;
        email: string;
        phone: string;
    };
    createdAt: string;
    updatedAt: string;
}

interface PaginationData {
    currentPage: number;
    totalPages: number;
    totalCount: number;
    limit: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
}

const AdminInvoice = () => {
    const [invoices, setInvoices] = useState<Invoice[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);
    const [pagination, setPagination] = useState<PaginationData>({
        currentPage: 1,
        totalPages: 1,
        totalCount: 0,
        limit: 10,
        hasNextPage: false,
        hasPreviousPage: false,
    });

    // Dialog states
    const [viewDialogOpen, setViewDialogOpen] = useState(false);
    const [editDialogOpen, setEditDialogOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

    // Form states
    const [editForm, setEditForm] = useState({
        invoice_number: '',
        invoice_date: '',
        customer_name: '',
        customer_email: '',
        customer_phone: '',
        total_amount: '',
        payment_status: '',
        status: '',
        notes: '',
    });

    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        fetchInvoices();
    }, [pagination.currentPage]);

    const fetchInvoices = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await getAllInvoices({
                page: pagination.currentPage,
                limit: pagination.limit,
            });
            setInvoices(response.data || []);
            if (response.pagination) {
                setPagination(response.pagination);
            }
        } catch (err: any) {
            setError(err.response?.data?.message || 'Failed to fetch invoices');
        } finally {
            setLoading(false);
        }
    };

    const handleViewInvoice = (invoice: Invoice) => {
        setSelectedInvoice(invoice);
        setViewDialogOpen(true);
    };

    const handleEditInvoice = (invoice: Invoice) => {
        setSelectedInvoice(invoice);
        setEditForm({
            invoice_number: invoice.invoice_number,
            invoice_date: invoice.invoice_date.split('T')[0],
            customer_name: invoice.customer_name,
            customer_email: invoice.customer_email || '',
            customer_phone: invoice.customer_phone || '',
            total_amount: invoice.total_amount.toString(),
            payment_status: invoice.payment_status,
            status: invoice.status,
            notes: invoice.notes || '',
        });
        setEditDialogOpen(true);
    };

    const handleDeleteInvoice = (invoice: Invoice) => {
        setSelectedInvoice(invoice);
        setDeleteDialogOpen(true);
    };

    const handleUpdateSubmit = async () => {
        if (!selectedInvoice) return;

        try {
            setSubmitting(true);
            setError(null);
            await adminUpdateInvoice(selectedInvoice.id, {
                invoice_number: editForm.invoice_number,
                invoice_date: editForm.invoice_date,
                customer_name: editForm.customer_name,
                customer_email: editForm.customer_email || undefined,
                customer_phone: editForm.customer_phone || undefined,
                total_amount: parseFloat(editForm.total_amount),
                payment_status: editForm.payment_status,
                status: editForm.status,
                notes: editForm.notes || undefined,
            });
            setSuccessMessage('Invoice updated successfully');
            setEditDialogOpen(false);
            fetchInvoices();
            setTimeout(() => setSuccessMessage(null), 3000);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Failed to update invoice');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDeleteSubmit = async () => {
        if (!selectedInvoice) return;

        try {
            setSubmitting(true);
            setError(null);
            await adminDeleteInvoice(selectedInvoice.id);
            setSuccessMessage('Invoice deleted successfully');
            setDeleteDialogOpen(false);
            fetchInvoices();
            setTimeout(() => setSuccessMessage(null), 3000);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Failed to delete invoice');
        } finally {
            setSubmitting(false);
        }
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        });
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
        }).format(amount);
    };

    const getPaymentStatusVariant = (
        status: string
    ): 'default' | 'secondary' | 'destructive' | 'outline' => {
        switch (status.toLowerCase()) {
            case 'paid':
                return 'default';
            case 'pending':
            case 'partial':
                return 'secondary';
            case 'overdue':
            case 'cancelled':
                return 'destructive';
            default:
                return 'outline';
        }
    };

    const getStatusVariant = (
        status: string
    ): 'default' | 'secondary' | 'destructive' | 'outline' => {
        switch (status.toLowerCase()) {
            case 'paid':
            case 'sent':
            case 'viewed':
                return 'default';
            case 'draft':
                return 'secondary';
            case 'cancelled':
                return 'destructive';
            default:
                return 'outline';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                    <p className="mt-4 text-muted-foreground">Loading invoices...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="container mx-auto py-6 px-4 max-w-7xl">
            {/* Success Message */}
            {successMessage && (
                <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md">
                    {successMessage}
                </div>
            )}

            {/* Error Message */}
            {error && (
                <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
                    {error}
                </div>
            )}

            <div className="mb-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">All Invoices</h1>
                        <p className="text-muted-foreground mt-2">
                            View and manage all invoices from all users
                        </p>
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={fetchInvoices}
                        className="gap-2"
                    >
                        <RefreshCw className="h-4 w-4" />
                        Refresh
                    </Button>
                </div>

                {/* Summary Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Total Invoices</CardDescription>
                            <CardTitle className="text-2xl">{pagination.totalCount}</CardTitle>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Total Amount</CardDescription>
                            <CardTitle className="text-2xl">
                                {formatCurrency(
                                    invoices.reduce((sum, inv) => sum + inv.total_amount, 0)
                                )}
                            </CardTitle>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Paid</CardDescription>
                            <CardTitle className="text-2xl text-green-600">
                                {invoices.filter((inv) => inv.payment_status === 'paid').length}
                            </CardTitle>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader className="pb-2">
                            <CardDescription>Pending</CardDescription>
                            <CardTitle className="text-2xl text-yellow-600">
                                {invoices.filter((inv) => inv.payment_status === 'pending').length}
                            </CardTitle>
                        </CardHeader>
                    </Card>
                </div>
            </div>

            {/* Invoices Table */}
            <Card>
                <CardHeader>
                    <CardTitle>Invoice List</CardTitle>
                    <CardDescription>
                        Showing {invoices.length} of {pagination.totalCount} invoices
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {invoices.length === 0 ? (
                        <div className="text-center py-12 text-muted-foreground">
                            <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                            <p>No invoices found</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full border-collapse">
                                <thead>
                                    <tr className="border-b bg-muted/50">
                                        <th className="text-left p-4 font-semibold">Invoice #</th>
                                        <th className="text-left p-4 font-semibold">Customer</th>
                                        <th className="text-left p-4 font-semibold">User</th>
                                        <th className="text-left p-4 font-semibold">Date</th>
                                        <th className="text-left p-4 font-semibold">Amount</th>
                                        <th className="text-left p-4 font-semibold">Payment</th>
                                        <th className="text-left p-4 font-semibold">Status</th>
                                        <th className="text-center p-4 font-semibold">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {invoices.map((invoice) => (
                                        <tr
                                            key={invoice.id}
                                            className="border-b hover:bg-muted/30 transition-colors"
                                        >
                                            <td className="p-4 font-medium">
                                                {invoice.invoice_number}
                                            </td>
                                            <td className="p-4">
                                                <div>
                                                    <p className="font-medium">
                                                        {invoice.customer_name}
                                                    </p>
                                                    {invoice.customer_email && (
                                                        <p className="text-sm text-muted-foreground">
                                                            {invoice.customer_email}
                                                        </p>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="p-4">
                                                {invoice.user && (
                                                    <div>
                                                        <p className="font-medium text-sm">
                                                            {invoice.user.name}
                                                        </p>
                                                        <p className="text-xs text-muted-foreground">
                                                            {invoice.user.email}
                                                        </p>
                                                    </div>
                                                )}
                                            </td>
                                            <td className="p-4 text-sm">
                                                {formatDate(invoice.invoice_date)}
                                            </td>
                                            <td className="p-4 font-semibold">
                                                {formatCurrency(invoice.total_amount)}
                                            </td>
                                            <td className="p-4">
                                                <Badge
                                                    variant={getPaymentStatusVariant(
                                                        invoice.payment_status
                                                    )}
                                                    className="capitalize"
                                                >
                                                    {invoice.payment_status}
                                                </Badge>
                                            </td>
                                            <td className="p-4">
                                                <Badge
                                                    variant={getStatusVariant(invoice.status)}
                                                    className="capitalize"
                                                >
                                                    {invoice.status}
                                                </Badge>
                                            </td>
                                            <td className="p-4">
                                                <div className="flex justify-center gap-2">
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleViewInvoice(invoice)}
                                                    >
                                                        <Eye className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleEditInvoice(invoice)}
                                                    >
                                                        <Edit className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleDeleteInvoice(invoice)}
                                                    >
                                                        <Trash2 className="h-4 w-4 text-destructive" />
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
                <div className="mt-6 flex justify-center gap-2">
                    <Button
                        variant="outline"
                        onClick={() =>
                            setPagination((prev) => ({
                                ...prev,
                                currentPage: prev.currentPage - 1,
                            }))
                        }
                        disabled={!pagination.hasPreviousPage}
                    >
                        Previous
                    </Button>
                    <div className="flex items-center px-4">
                        <span className="text-sm text-muted-foreground">
                            Page {pagination.currentPage} of {pagination.totalPages}
                        </span>
                    </div>
                    <Button
                        variant="outline"
                        onClick={() =>
                            setPagination((prev) => ({
                                ...prev,
                                currentPage: prev.currentPage + 1,
                            }))
                        }
                        disabled={!pagination.hasNextPage}
                    >
                        Next
                    </Button>
                </div>
            )}

            {/* View Invoice Dialog */}
            <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <FileText className="h-5 w-5" />
                            Invoice Details
                        </DialogTitle>
                        <DialogDescription>Complete invoice information</DialogDescription>
                    </DialogHeader>
                    {selectedInvoice && (
                        <div className="space-y-6 mt-4">
                            {/* Invoice Header */}
                            <div className="flex justify-between items-start pb-4 border-b">
                                <div>
                                    <h3 className="text-2xl font-bold">
                                        {selectedInvoice.invoice_number}
                                    </h3>
                                    <p className="text-sm text-muted-foreground mt-1">
                                        {formatDate(selectedInvoice.invoice_date)}
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm text-muted-foreground mb-2">
                                        Total Amount
                                    </p>
                                    <p className="text-2xl font-bold">
                                        {formatCurrency(selectedInvoice.total_amount)}
                                    </p>
                                </div>
                            </div>

                            {/* Status Badges */}
                            <div className="flex gap-3">
                                <div>
                                    <p className="text-sm text-muted-foreground mb-2">
                                        Payment Status
                                    </p>
                                    <Badge
                                        variant={getPaymentStatusVariant(
                                            selectedInvoice.payment_status
                                        )}
                                        className="text-sm px-3 py-1 capitalize"
                                    >
                                        {selectedInvoice.payment_status}
                                    </Badge>
                                </div>
                                <div>
                                    <p className="text-sm text-muted-foreground mb-2">
                                        Invoice Status
                                    </p>
                                    <Badge
                                        variant={getStatusVariant(selectedInvoice.status)}
                                        className="text-sm px-3 py-1 capitalize"
                                    >
                                        {selectedInvoice.status}
                                    </Badge>
                                </div>
                            </div>

                            {/* Customer Information */}
                            <div>
                                <h4 className="font-semibold mb-3 flex items-center gap-2">
                                    <User className="h-4 w-4" />
                                    Customer Information
                                </h4>
                                <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
                                    <div className="flex items-start gap-3">
                                        <User className="h-5 w-5 text-muted-foreground mt-0.5" />
                                        <div>
                                            <p className="text-sm font-medium text-muted-foreground">
                                                Name
                                            </p>
                                            <p className="text-base">
                                                {selectedInvoice.customer_name}
                                            </p>
                                        </div>
                                    </div>
                                    {selectedInvoice.customer_email && (
                                        <div className="flex items-start gap-3">
                                            <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
                                            <div>
                                                <p className="text-sm font-medium text-muted-foreground">
                                                    Email
                                                </p>
                                                <p className="text-base">
                                                    {selectedInvoice.customer_email}
                                                </p>
                                            </div>
                                        </div>
                                    )}
                                    {selectedInvoice.customer_phone && (
                                        <div className="flex items-start gap-3">
                                            <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                                            <div>
                                                <p className="text-sm font-medium text-muted-foreground">
                                                    Phone
                                                </p>
                                                <p className="text-base">
                                                    {selectedInvoice.customer_phone}
                                                </p>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* User Information */}
                            {selectedInvoice.user && (
                                <div>
                                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                                        <User className="h-4 w-4" />
                                        Created By
                                    </h4>
                                    <div className="space-y-2 bg-muted/30 p-4 rounded-lg">
                                        <p className="text-sm">
                                            <span className="font-medium">Name:</span>{' '}
                                            {selectedInvoice.user.name}
                                        </p>
                                        <p className="text-sm">
                                            <span className="font-medium">Email:</span>{' '}
                                            {selectedInvoice.user.email}
                                        </p>
                                        <p className="text-sm">
                                            <span className="font-medium">Phone:</span>{' '}
                                            {selectedInvoice.user.phone}
                                        </p>
                                    </div>
                                </div>
                            )}

                            {/* Notes */}
                            {selectedInvoice.notes && (
                                <div>
                                    <h4 className="font-semibold mb-3">Notes</h4>
                                    <p className="text-sm bg-muted/30 p-4 rounded-lg">
                                        {selectedInvoice.notes}
                                    </p>
                                </div>
                            )}

                            {/* Timestamps */}
                            <div className="pt-4 border-t text-sm text-muted-foreground">
                                <p>Created: {formatDate(selectedInvoice.createdAt)}</p>
                                <p>Last Updated: {formatDate(selectedInvoice.updatedAt)}</p>
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setViewDialogOpen(false)}>
                            Close
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Edit Invoice Dialog */}
            <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit Invoice</DialogTitle>
                        <DialogDescription>Update invoice information</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="invoice_number">Invoice Number *</Label>
                                <Input
                                    id="invoice_number"
                                    value={editForm.invoice_number}
                                    onChange={(e) =>
                                        setEditForm({ ...editForm, invoice_number: e.target.value })
                                    }
                                />
                            </div>
                            <div>
                                <Label htmlFor="invoice_date">Invoice Date *</Label>
                                <Input
                                    id="invoice_date"
                                    type="date"
                                    value={editForm.invoice_date}
                                    onChange={(e) =>
                                        setEditForm({ ...editForm, invoice_date: e.target.value })
                                    }
                                />
                            </div>
                        </div>
                        <div>
                            <Label htmlFor="customer_name">Customer Name *</Label>
                            <Input
                                id="customer_name"
                                value={editForm.customer_name}
                                onChange={(e) =>
                                    setEditForm({ ...editForm, customer_name: e.target.value })
                                }
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="customer_email">Customer Email</Label>
                                <Input
                                    id="customer_email"
                                    type="email"
                                    value={editForm.customer_email}
                                    onChange={(e) =>
                                        setEditForm({ ...editForm, customer_email: e.target.value })
                                    }
                                />
                            </div>
                            <div>
                                <Label htmlFor="customer_phone">Customer Phone</Label>
                                <Input
                                    id="customer_phone"
                                    value={editForm.customer_phone}
                                    onChange={(e) =>
                                        setEditForm({ ...editForm, customer_phone: e.target.value })
                                    }
                                />
                            </div>
                        </div>
                        <div>
                            <Label htmlFor="total_amount">Total Amount *</Label>
                            <Input
                                id="total_amount"
                                type="number"
                                step="0.01"
                                value={editForm.total_amount}
                                onChange={(e) =>
                                    setEditForm({ ...editForm, total_amount: e.target.value })
                                }
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="payment_status">Payment Status *</Label>
                                <Select
                                    value={editForm.payment_status}
                                    onValueChange={(value) =>
                                        setEditForm({ ...editForm, payment_status: value })
                                    }
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="pending">Pending</SelectItem>
                                        <SelectItem value="partial">Partial</SelectItem>
                                        <SelectItem value="paid">Paid</SelectItem>
                                        <SelectItem value="overdue">Overdue</SelectItem>
                                        <SelectItem value="cancelled">Cancelled</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label htmlFor="status">Status *</Label>
                                <Select
                                    value={editForm.status}
                                    onValueChange={(value) =>
                                        setEditForm({ ...editForm, status: value })
                                    }
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="draft">Draft</SelectItem>
                                        <SelectItem value="sent">Sent</SelectItem>
                                        <SelectItem value="viewed">Viewed</SelectItem>
                                        <SelectItem value="paid">Paid</SelectItem>
                                        <SelectItem value="cancelled">Cancelled</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <div>
                            <Label htmlFor="notes">Notes</Label>
                            <Textarea
                                id="notes"
                                value={editForm.notes}
                                onChange={(e) =>
                                    setEditForm({ ...editForm, notes: e.target.value })
                                }
                                rows={3}
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button
                            variant="outline"
                            onClick={() => setEditDialogOpen(false)}
                            disabled={submitting}
                        >
                            Cancel
                        </Button>
                        <Button onClick={handleUpdateSubmit} disabled={submitting}>
                            {submitting ? (
                                <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Updating...
                                </>
                            ) : (
                                'Update Invoice'
                            )}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation Dialog */}
            <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to delete this invoice? This action cannot be
                            undone.
                        </DialogDescription>
                    </DialogHeader>
                    {selectedInvoice && (
                        <div className="py-4">
                            <p className="text-sm">
                                <span className="font-semibold">Invoice:</span>{' '}
                                {selectedInvoice.invoice_number}
                            </p>
                            <p className="text-sm">
                                <span className="font-semibold">Customer:</span>{' '}
                                {selectedInvoice.customer_name}
                            </p>
                            <p className="text-sm">
                                <span className="font-semibold">Amount:</span>{' '}
                                {formatCurrency(selectedInvoice.total_amount)}
                            </p>
                        </div>
                    )}
                    <DialogFooter>
                        <Button
                            variant="outline"
                            onClick={() => setDeleteDialogOpen(false)}
                            disabled={submitting}
                        >
                            Cancel
                        </Button>
                        <Button
                            variant="destructive"
                            onClick={handleDeleteSubmit}
                            disabled={submitting}
                        >
                            {submitting ? (
                                <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Deleting...
                                </>
                            ) : (
                                'Delete'
                            )}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default AdminInvoice;

// Made with Bob
</content>
<line_count>1001</line_count>
</write_to_file>

---

**User:**

[write_to_file for 'frontend/src/page/admin/invoice/index.tsx'] Result:
<file_write_result>
<path>frontend/src/page/admin/invoice/index.tsx</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<environment_details>
# VSCode Visible Files
frontend/src/page/admin/invoice/index.tsx

# VSCode Open Tabs
frontend/src/page/transaction/index.tsx,frontend/src/page/admin/invoice/index.tsx

# Recently Modified Files
These files have been modified since you last accessed them (file was just edited so you may need to re-read it before editing):
frontend/src/page/admin/invoice/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T13:00:12.125Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.15

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

<attempt_completion>
<result>
I've successfully created a comprehensive Admin Invoice page based on the backend controller. Here's what was implemented:

## Features Implemented:

### 1. **Data Fetching & Display**
- Fetches all invoices using `getAllInvoices` API with pagination
- Displays invoices in a responsive table format
- Shows invoice details including: invoice number, customer info, user who created it, date, amount, payment status, and invoice status

### 2. **Summary Dashboard**
- Total Invoices count
- Total Amount (sum of all invoices)
- Paid invoices count
- Pending invoices count

### 3. **Admin Actions**
- **View**: View complete invoice details in a dialog
- **Edit**: Update any invoice field using `adminUpdateInvoice` API
- **Delete**: Delete any invoice using `adminDeleteInvoice` API

### 4. **Edit Dialog Features**
- Update invoice number, date, customer details
- Change payment status (pending, partial, paid, overdue, cancelled)
- Change invoice status (draft, sent, viewed, paid, cancelled)
- Update total amount and notes

### 5. **UI/UX Features**
- Loading states with spinner
- Success/error message notifications
- Pagination controls
- Refresh button to reload data
- Color-coded status badges
- Responsive design for mobile/tablet/desktop
- Confirmation dialog for deletions

### 6. **Backend Integration**
The page correctly uses the backend endpoints:
- `GET /invoice/admin` - Get all invoices (with pagination)
- `PUT /invoice/admin/:id` - Update any invoice
- `DELETE /invoice/admin/:id` - Delete any invoice

All features align with the backend controller's `getAllInvoices`, `adminUpdateInvoice`, and `adminDeleteInvoice` functions.
</result>
</attempt_completion>

