**User:**

<task>
'frontend/src/page/profile/index.tsx' (see below for file content) Create a logout button where it will remove the token and navigate to the home page
</task>

<file_content path="frontend/src/page/profile/index.tsx">
  1 | import { useState, useEffect } from 'react';
  2 | import { useForm } from 'react-hook-form';
  3 | import { User, Mail, Phone, Lock, Edit2, X, Check, Shield } from 'lucide-react';
  4 | import { useSelector, useDispatch } from 'react-redux';
  5 | import { Button } from '@/components/ui/button';
  6 | import { Input } from '@/components/ui/input';
  7 | import { Badge } from '@/components/ui/badge';
  8 | import {
  9 |     Form,
 10 |     FormControl,
 11 |     FormField,
 12 |     FormItem,
 13 |     FormLabel,
 14 |     FormMessage,
 15 | } from '@/components/ui/form';
 16 | import {
 17 |     Card,
 18 |     CardContent,
 19 |     CardDescription,
 20 |     CardHeader,
 21 |     CardTitle,
 22 | } from '@/components/ui/card';
 23 | import { Alert } from '@/components/ui/alert';
 24 | import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
 25 | import PageLoader from '@/components/custom/page-loader';
 26 | import { getMe, updateUserDetail } from '@/service/user';
 27 | import { setUser } from '@/store/auth';
 28 | 
 29 | interface ProfileFormValues {
 30 |     name: string;
 31 |     phone: string;
 32 | }
 33 | 
 34 | interface PasswordFormValues {
 35 |     password: string;
 36 |     confirmPassword: string;
 37 | }
 38 | 
 39 | const Profile = () => {
 40 |     const dispatch = useDispatch();
 41 |     const user = useSelector((state: any) => state.auth.user);
 42 |     const [isLoading, setIsLoading] = useState(false);
 43 |     const [isEditMode, setIsEditMode] = useState(false);
 44 |     const [successMessage, setSuccessMessage] = useState('');
 45 |     const [errorMessage, setErrorMessage] = useState('');
 46 |     const [activeTab, setActiveTab] = useState('profile');
 47 | 
 48 |     // Profile form
 49 |     const profileForm = useForm<ProfileFormValues>({
 50 |         defaultValues: {
 51 |             name: user?.name || '',
 52 |             phone: user?.phone || '',
 53 |         },
 54 |     });
 55 | 
 56 |     // Password form
 57 |     const passwordForm = useForm<PasswordFormValues>({
 58 |         defaultValues: {
 59 |             password: '',
 60 |             confirmPassword: '',
 61 |         },
 62 |     });
 63 | 
 64 |     // Fetch user data on mount
 65 |     useEffect(() => {
 66 |         fetchUserData();
 67 |     }, []);
 68 | 
 69 |     const fetchUserData = async () => {
 70 |         setIsLoading(true);
 71 |         try {
 72 |             const response = await getMe();
 73 |             if (response.data) {
 74 |                 dispatch(setUser(response.data));
 75 |                 profileForm.reset({
 76 |                     name: response.data.name,
 77 |                     phone: response.data.phone,
 78 |                 });
 79 |             }
 80 |         } catch (error: any) {
 81 |             setErrorMessage(error.response?.data?.message || 'Failed to fetch user data');
 82 |         } finally {
 83 |             setIsLoading(false);
 84 |         }
 85 |     };
 86 | 
 87 |     const onProfileSubmit = async (data: ProfileFormValues) => {
 88 |         setIsLoading(true);
 89 |         setErrorMessage('');
 90 |         setSuccessMessage('');
 91 | 
 92 |         try {
 93 |             const response = await updateUserDetail({
 94 |                 name: data.name.trim(),
 95 |                 phone: data.phone.trim(),
 96 |             });
 97 | 
 98 |             setSuccessMessage(response.message || 'Profile updated successfully!');
 99 |             setErrorMessage('');
100 |             setIsEditMode(false);
101 | 
102 |             // Update Redux store
103 |             dispatch(setUser({
104 |                 ...user,
105 |                 name: data.name.trim(),
106 |                 phone: data.phone.trim(),
107 |             }));
108 | 
109 |             // Refresh user data
110 |             await fetchUserData();
111 |         } catch (error: any) {
112 |             setErrorMessage(error.response?.data?.message || 'Failed to update profile');
113 |             setSuccessMessage('');
114 |         } finally {
115 |             setIsLoading(false);
116 |         }
117 |     };
118 | 
119 |     const onPasswordSubmit = async (data: PasswordFormValues) => {
120 |         setIsLoading(true);
121 |         setErrorMessage('');
122 |         setSuccessMessage('');
123 | 
124 |         try {
125 |             const response = await updateUserDetail({
126 |                 password: data.password,
127 |             });
128 | 
129 |             setSuccessMessage(response.message || 'Password updated successfully!');
130 |             setErrorMessage('');
131 | 
132 |             // Reset password form
133 |             passwordForm.reset();
134 |         } catch (error: any) {
135 |             setErrorMessage(error.response?.data?.message || 'Failed to update password');
136 |             setSuccessMessage('');
137 |         } finally {
138 |             setIsLoading(false);
139 |         }
140 |     };
141 | 
142 |     const handleCancelEdit = () => {
143 |         setIsEditMode(false);
144 |         profileForm.reset({
145 |             name: user?.name || '',
146 |             phone: user?.phone || '',
147 |         });
148 |         setErrorMessage('');
149 |         setSuccessMessage('');
150 |     };
151 | 
152 |     const isAdmin = user?.role === 'admin';
153 | 
154 |     return (
155 |         <div className="mx-auto py-8 px-4 max-w-4xl">
156 |             <PageLoader isLoading={isLoading} />
157 | 
158 |             {/* Header Section */}
159 |             <div className="mb-8">
160 |                 <div className="flex items-center justify-between">
161 |                     <div>
162 |                         <h1 className="text-3xl font-bold">Profile</h1>
163 |                         <p className="text-muted-foreground mt-1">
164 |                             Manage your account settings and preferences
165 |                         </p>
166 |                     </div>
167 |                     {isAdmin && (
168 |                         <Badge variant="default" className="flex items-center gap-1 px-3 py-1">
169 |                             <Shield className="h-4 w-4" />
170 |                             Admin
171 |                         </Badge>
172 |                     )}
173 |                 </div>
174 |             </div>
175 | 
176 |             {/* Success/Error Messages */}
177 |             {successMessage && (
178 |                 <Alert className="mb-6 bg-green-50 border-green-200">
179 |                     <p className="text-green-800">{successMessage}</p>
180 |                 </Alert>
181 |             )}
182 | 
183 |             {errorMessage && (
184 |                 <Alert className="mb-6 bg-red-50 border-red-200">
185 |                     <p className="text-red-800">{errorMessage}</p>
186 |                 </Alert>
187 |             )}
188 | 
189 |             {/* Tabs for Profile and Password */}
190 |             <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
191 |                 <TabsList className="grid w-full grid-cols-2">
192 |                     <TabsTrigger value="profile">Profile Information</TabsTrigger>
193 |                     <TabsTrigger value="password">Change Password</TabsTrigger>
194 |                 </TabsList>
195 | 
196 |                 {/* Profile Tab */}
197 |                 <TabsContent value="profile">
198 |                     <Card>
199 |                         <CardHeader>
200 |                             <div className="flex items-center justify-between">
201 |                                 <div>
202 |                                     <CardTitle>Personal Information</CardTitle>
203 |                                     <CardDescription>
204 |                                         View and update your profile details
205 |                                     </CardDescription>
206 |                                 </div>
207 |                                 {!isEditMode && (
208 |                                     <Button
209 |                                         variant="outline"
210 |                                         size="sm"
211 |                                         onClick={() => setIsEditMode(true)}
212 |                                         disabled={isLoading}
213 |                                     >
214 |                                         <Edit2 className="h-4 w-4 mr-2" />
215 |                                         Edit Profile
216 |                                     </Button>
217 |                                 )}
218 |                             </div>
219 |                         </CardHeader>
220 |                         <CardContent>
221 |                             {!isEditMode ? (
222 |                                 // View Mode
223 |                                 <div className="space-y-6">
224 |                                     {/* Name */}
225 |                                     <div className="flex items-start gap-4">
226 |                                         <div className="p-2 bg-primary/10 rounded-lg">
227 |                                             <User className="h-5 w-5 text-primary" />
228 |                                         </div>
229 |                                         <div className="flex-1">
230 |                                             <p className="text-sm text-muted-foreground">Name</p>
231 |                                             <p className="text-lg font-medium">{user?.name || 'N/A'}</p>
232 |                                         </div>
233 |                                     </div>
234 | 
235 |                                     {/* Email */}
236 |                                     <div className="flex items-start gap-4">
237 |                                         <div className="p-2 bg-primary/10 rounded-lg">
238 |                                             <Mail className="h-5 w-5 text-primary" />
239 |                                         </div>
240 |                                         <div className="flex-1">
241 |                                             <p className="text-sm text-muted-foreground">Email</p>
242 |                                             <p className="text-lg font-medium">{user?.email || 'N/A'}</p>
243 |                                         </div>
244 |                                     </div>
245 | 
246 |                                     {/* Phone */}
247 |                                     <div className="flex items-start gap-4">
248 |                                         <div className="p-2 bg-primary/10 rounded-lg">
249 |                                             <Phone className="h-5 w-5 text-primary" />
250 |                                         </div>
251 |                                         <div className="flex-1">
252 |                                             <p className="text-sm text-muted-foreground">Phone</p>
253 |                                             <p className="text-lg font-medium">{user?.phone || 'N/A'}</p>
254 |                                         </div>
255 |                                     </div>
256 | 
257 |                                     {/* Role */}
258 |                                     <div className="flex items-start gap-4">
259 |                                         <div className="p-2 bg-primary/10 rounded-lg">
260 |                                             <Shield className="h-5 w-5 text-primary" />
261 |                                         </div>
262 |                                         <div className="flex-1">
263 |                                             <p className="text-sm text-muted-foreground">Role</p>
264 |                                             <p className="text-lg font-medium capitalize">
265 |                                                 {user?.role || 'N/A'}
266 |                                             </p>
267 |                                         </div>
268 |                                     </div>
269 |                                 </div>
270 |                             ) : (
271 |                                 // Edit Mode
272 |                                 <Form {...profileForm}>
273 |                                     <form
274 |                                         onSubmit={profileForm.handleSubmit(onProfileSubmit)}
275 |                                         className="space-y-6"
276 |                                     >
277 |                                         {/* Name Field */}
278 |                                         <FormField
279 |                                             control={profileForm.control}
280 |                                             name="name"
281 |                                             rules={{
282 |                                                 required: 'Name is required',
283 |                                                 minLength: {
284 |                                                     value: 2,
285 |                                                     message: 'Name must be at least 2 characters',
286 |                                                 },
287 |                                             }}
288 |                                             render={({ field }) => (
289 |                                                 <FormItem>
290 |                                                     <FormLabel>Name</FormLabel>
291 |                                                     <FormControl>
292 |                                                         <div className="relative">
293 |                                                             <Input
294 |                                                                 placeholder="Enter your name"
295 |                                                                 disabled={isLoading}
296 |                                                                 {...field}
297 |                                                             />
298 |                                                             <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
299 |                                                         </div>
300 |                                                     </FormControl>
301 |                                                     <FormMessage />
302 |                                                 </FormItem>
303 |                                             )}
304 |                                         />
305 | 
306 |                                         {/* Email Field (Read-only) */}
307 |                                         <div>
308 |                                             <FormLabel>Email</FormLabel>
309 |                                             <div className="relative">
310 |                                                 <Input
311 |                                                     value={user?.email || ''}
312 |                                                     disabled
313 |                                                     className="bg-muted"
314 |                                                 />
315 |                                                 <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
316 |                                             </div>
317 |                                             <p className="text-xs text-muted-foreground mt-1">
318 |                                                 Email cannot be changed
319 |                                             </p>
320 |                                         </div>
321 | 
322 |                                         {/* Phone Field */}
323 |                                         <FormField
324 |                                             control={profileForm.control}
325 |                                             name="phone"
326 |                                             rules={{
327 |                                                 required: 'Phone number is required',
328 |                                                 pattern: {
329 |                                                     value: /^[0-9]{10}$/,
330 |                                                     message: 'Phone number must be 10 digits',
331 |                                                 },
332 |                                             }}
333 |                                             render={({ field }) => (
334 |                                                 <FormItem>
335 |                                                     <FormLabel>Phone</FormLabel>
336 |                                                     <FormControl>
337 |                                                         <div className="relative">
338 |                                                             <Input
339 |                                                                 placeholder="Enter your phone number"
340 |                                                                 maxLength={10}
341 |                                                                 disabled={isLoading}
342 |                                                                 {...field}
343 |                                                             />
344 |                                                             <Phone className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
345 |                                                         </div>
346 |                                                     </FormControl>
347 |                                                     <FormMessage />
348 |                                                 </FormItem>
349 |                                             )}
350 |                                         />
351 | 
352 |                                         {/* Action Buttons */}
353 |                                         <div className="flex gap-4 pt-4">
354 |                                             <Button
355 |                                                 type="submit"
356 |                                                 className="flex-1"
357 |                                                 disabled={isLoading}
358 |                                             >
359 |                                                 <Check className="h-4 w-4 mr-2" />
360 |                                                 {isLoading ? 'Saving...' : 'Save Changes'}
361 |                                             </Button>
362 |                                             <Button
363 |                                                 type="button"
364 |                                                 variant="outline"
365 |                                                 onClick={handleCancelEdit}
366 |                                                 disabled={isLoading}
367 |                                             >
368 |                                                 <X className="h-4 w-4 mr-2" />
369 |                                                 Cancel
370 |                                             </Button>
371 |                                         </div>
372 |                                     </form>
373 |                                 </Form>
374 |                             )}
375 |                         </CardContent>
376 |                     </Card>
377 |                 </TabsContent>
378 | 
379 |                 {/* Password Tab */}
380 |                 <TabsContent value="password">
381 |                     <Card>
382 |                         <CardHeader>
383 |                             <CardTitle>Change Password</CardTitle>
384 |                             <CardDescription>
385 |                                 Update your password to keep your account secure
386 |                             </CardDescription>
387 |                         </CardHeader>
388 |                         <CardContent>
389 |                             <Form {...passwordForm}>
390 |                                 <form
391 |                                     onSubmit={passwordForm.handleSubmit(onPasswordSubmit)}
392 |                                     className="space-y-6"
393 |                                 >
394 |                                     {/* New Password Field */}
395 |                                     <FormField
396 |                                         control={passwordForm.control}
397 |                                         name="password"
398 |                                         rules={{
399 |                                             required: 'Password is required',
400 |                                             minLength: {
401 |                                                 value: 6,
402 |                                                 message: 'Password must be at least 6 characters',
403 |                                             },
404 |                                         }}
405 |                                         render={({ field }) => (
406 |                                             <FormItem>
407 |                                                 <FormLabel>New Password</FormLabel>
408 |                                                 <FormControl>
409 |                                                     <div className="relative">
410 |                                                         <Input
411 |                                                             type="password"
412 |                                                             placeholder="Enter new password"
413 |                                                             disabled={isLoading}
414 |                                                             {...field}
415 |                                                         />
416 |                                                         <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
417 |                                                     </div>
418 |                                                 </FormControl>
419 |                                                 <FormMessage />
420 |                                             </FormItem>
421 |                                         )}
422 |                                     />
423 | 
424 |                                     {/* Confirm Password Field */}
425 |                                     <FormField
426 |                                         control={passwordForm.control}
427 |                                         name="confirmPassword"
428 |                                         rules={{
429 |                                             required: 'Please confirm your password',
430 |                                             validate: (value) =>
431 |                                                 value === passwordForm.getValues('password') ||
432 |                                                 'Passwords do not match',
433 |                                         }}
434 |                                         render={({ field }) => (
435 |                                             <FormItem>
436 |                                                 <FormLabel>Confirm New Password</FormLabel>
437 |                                                 <FormControl>
438 |                                                     <div className="relative">
439 |                                                         <Input
440 |                                                             type="password"
441 |                                                             placeholder="Confirm new password"
442 |                                                             disabled={isLoading}
443 |                                                             {...field}
444 |                                                         />
445 |                                                         <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
446 |                                                     </div>
447 |                                                 </FormControl>
448 |                                                 <FormMessage />
449 |                                             </FormItem>
450 |                                         )}
451 |                                     />
452 | 
453 |                                     {/* Submit Button */}
454 |                                     <div className="pt-4">
455 |                                         <Button
456 |                                             type="submit"
457 |                                             className="w-full border border-1 hover:shadow hover:cursor-pointer"
458 |                                             disabled={isLoading}
459 |                                         >
460 |                                             <Lock className="h-4 w-4 mr-2" />
461 |                                             {isLoading ? 'Updating...' : 'Update Password'}
462 |                                         </Button>
463 |                                     </div>
464 |                                 </form>
465 |                             </Form>
466 |                         </CardContent>
467 |                     </Card>
468 |                 </TabsContent>
469 |             </Tabs>
470 |         </div>
471 |     );
472 | };
473 | 
474 | export default Profile;
475 | 
476 | // Made with Bob

</file_content>
<environment_details>
# VSCode Visible Files
frontend/src/page/profile/index.tsx

# VSCode Open Tabs
frontend/src/page/profile/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T14:42:52.769Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.00

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>


# Current Workspace Directory (/home/ammanrizwan/Documents/Github Repo/ibm-hackathon-project) Files
README.md
backend/
backend/.editorconfig
backend/.env.example
backend/.gitattributes
backend/.gitignore
backend/.prettierignore
backend/.prettierrc.json
backend/.yarnrc.yml
backend/eslint.config.js
backend/package.json
backend/README.md
backend/tsconfig.json
backend/yarn.lock
backend/.yarn/
backend/src/
backend/src/index.ts
backend/src/config/
backend/src/config/db.ts
backend/src/config/env.ts
backend/src/controller/
backend/src/controller/auth/
backend/src/controller/auth/index.ts
backend/src/controller/billing_detail/
backend/src/controller/billing_detail/index.ts
backend/src/controller/invoice/
backend/src/controller/invoice/index.ts
backend/src/controller/payment_methods/
backend/src/controller/payment_methods/index.ts
backend/src/controller/transaction/
backend/src/controller/transaction/index.ts
backend/src/controller/user/
backend/src/controller/user/index.ts
backend/src/middleware/
backend/src/middleware/auth.ts
backend/src/middleware/error.ts
backend/src/middleware/permission.ts
backend/src/models/
backend/src/models/billing_detail.ts
backend/src/models/index.ts
backend/src/models/invoice.ts
backend/src/models/otp.ts
backend/src/models/payment_method.ts
backend/src/models/transaction.ts
backend/src/models/user.ts
backend/src/routes/
backend/src/routes/index.ts
backend/src/routes/auth/
backend/src/routes/auth/index.ts
backend/src/routes/billing_details/
backend/src/routes/billing_details/index.ts
backend/src/routes/invoice/
backend/src/routes/invoice/index.ts
backend/src/routes/payment_methods/
backend/src/routes/payment_methods/index.ts
backend/src/routes/transaction/
backend/src/routes/transaction/index.ts
backend/src/routes/user/
backend/src/routes/user/index.ts
backend/src/services/
backend/src/services/smtp.ts
backend/src/utils/
backend/src/utils/bcrypt.ts
backend/src/utils/error.ts
backend/src/utils/generate-otp.ts
backend/src/utils/jwt.ts
backend/src/utils/logger.ts
backend/src/utils/reminder.ts
backend/src/views/
backend/src/views/auth/
backend/src/views/auth/forgot-password.ejs
backend/src/views/auth/login.ejs
backend/src/views/auth/signup.ejs
backend/src/views/invoice/
backend/src/views/invoice/invoice.ejs
backend/src/views/reminder/
backend/src/views/reminder/reminder.ejs
frontend/
frontend/.env.example
frontend/.gitignore
frontend/.prettierignore
frontend/.prettierrc.json
frontend/.yarnrc.yml
frontend/components.json
frontend/eslint.config.js
frontend/index.html
frontend/package.json
frontend/postcss.config.js
frontend/README.md
frontend/tailwind.config.js
frontend/tsconfig.app.json
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/vite.config.ts
frontend/yarn.lock
frontend/.yarn/
frontend/public/
frontend/public/favicon.svg
frontend/public/icons.svg
frontend/src/
frontend/src/App.tsx
frontend/src/index.css
frontend/src/main.tsx
frontend/src/assets/
frontend/src/assets/hero.png
frontend/src/assets/react.svg
frontend/src/assets/vite.svg
frontend/src/components/
frontend/src/components/custom/
frontend/src/components/custom/navbar/
frontend/src/components/custom/navbar/index.tsx
frontend/src/components/custom/page-loader/
frontend/src/components/custom/page-loader/index.tsx
frontend/src/components/custom/sidebar/
frontend/src/components/custom/sidebar/index.tsx
frontend/src/components/ui/
frontend/src/components/ui/accordion.tsx
frontend/src/components/ui/alert.tsx
frontend/src/components/ui/badge.tsx
frontend/src/components/ui/button.tsx
frontend/src/components/ui/card.tsx
frontend/src/components/ui/checkbox.tsx
frontend/src/components/ui/dialog.tsx
frontend/src/components/ui/dropdown-menu.tsx
frontend/src/components/ui/form.tsx
frontend/src/components/ui/index.ts
frontend/src/components/ui/input.tsx
frontend/src/components/ui/label.tsx
frontend/src/components/ui/radio-group.tsx
frontend/src/components/ui/select.tsx
frontend/src/components/ui/switch.tsx
frontend/src/components/ui/tabs.tsx
frontend/src/components/ui/textarea.tsx
frontend/src/components/ui/tooltip.tsx
frontend/src/data/
frontend/src/data/mockInvoices.ts
frontend/src/lib/
frontend/src/lib/utils.ts
frontend/src/page/
frontend/src/page/layout.tsx
frontend/src/page/admin/
frontend/src/page/admin/invoice/
frontend/src/page/admin/invoice/index.tsx
frontend/src/page/admin/manage_employee/
frontend/src/page/admin/manage_employee/index.tsx
frontend/src/page/admin/payment_method/
frontend/src/page/admin/payment_method/index.tsx
frontend/src/page/admin/transcation/
frontend/src/page/admin/transcation/index.tsx
frontend/src/page/auth/
frontend/src/page/auth/forgot-password/
frontend/src/page/auth/forgot-password/index.tsx
frontend/src/page/auth/login/
frontend/src/page/auth/login/index.tsx
frontend/src/page/auth/signup/
frontend/src/page/auth/signup/index.tsx
frontend/src/page/billing_detail/
frontend/src/page/billing_detail/index.tsx
frontend/src/page/billing_detail/new/
frontend/src/page/billing_detail/new/index.tsx
frontend/src/page/home/
frontend/src/page/home/index.tsx
frontend/src/page/invoice/
frontend/src/page/invoice/index.tsx
frontend/src/page/payment_method/
frontend/src/page/payment_method/index.tsx
frontend/src/page/payment_method/new/
frontend/src/page/payment_method/new/index.tsx
frontend/src/page/profile/
frontend/src/page/profile/index.tsx
frontend/src/page/transaction/
frontend/src/page/transaction/index.tsx
frontend/src/service/
frontend/src/service/api.ts
frontend/src/service/auth/
frontend/src/service/auth/index.ts
frontend/src/service/auth/interface.ts
frontend/src/service/billing_details/
frontend/src/service/billing_details/index.ts
frontend/src/service/billing_details/interface.ts
frontend/src/service/invoice/
frontend/src/service/invoice/index.ts
frontend/src/service/invoice/interface.ts
frontend/src/service/payment_methods/
frontend/src/service/payment_methods/index.ts
frontend/src/service/payment_methods/interface.ts
frontend/src/service/transaction/
frontend/src/service/transaction/index.ts
frontend/src/service/transaction/interface.ts
frontend/src/service/user/
frontend/src/service/user/index.ts
frontend/src/service/user/interface.ts
frontend/src/store/
frontend/src/store/index.ts
frontend/src/store/auth/
frontend/src/store/auth/index.ts
frontend/src/store/nav-toggle/index.ts
frontend/src/utils/AutoRedirect.tsx
frontend/src/utils/PermissionRoute.tsx
frontend/src/utils/ProtectedRoute.tsx

(File list truncated. Use list_files on specific subdirectories if you need to explore further.)
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

I'll help you create a logout button in the profile page. First, let me check the auth store and related files to understand how authentication is managed.

<read_file>
<args>
<file>
<path>frontend/src/store/auth/index.ts</path>
</file>
<file>
<path>frontend/src/service/auth/index.ts</path>
</file>
<file>
<path>frontend/src/utils/ProtectedRoute.tsx</path>
</file>
</args>
</read_file>

---

**User:**

[read_file for 'frontend/src/store/auth/index.ts', 'frontend/src/service/auth/index.ts', 'frontend/src/utils/ProtectedRoute.tsx'] Result:
<files>
<file><path>frontend/src/store/auth/index.ts</path>
<content lines="1-62">
 1 | import { createSlice } from "@reduxjs/toolkit";
 2 | 
 3 | interface IAuthUser {
 4 |     user: {
 5 |         id: string;
 6 |         name: string;
 7 |         email: string;
 8 |         phone: string;
 9 |         role: string;
10 |     },
11 |     token: string
12 | }
13 | 
14 | const initialState: IAuthUser = {
15 |     user: {
16 |         id: null,
17 |         name: null,
18 |         email: null,
19 |         phone: null,
20 |         role: null
21 |     },
22 |     token: null,
23 | }
24 | 
25 | export const authUserDetail = createSlice({
26 |     name: "auth",
27 |     initialState,
28 |     reducers: {
29 |         removeUser: (state) => {
30 |             const detail = {
31 |                 id: null,
32 |                 name: null,
33 |                 email: null,
34 |                 role: null,
35 |                 phone: null
36 |             };
37 |             state.user = detail;
38 |         },
39 |         setUser: (state, action) => {
40 |             const detail = {
41 |                 id: action.payload.id,
42 |                 name: action.payload.name,
43 |                 email: action.payload.email,
44 |                 role: action.payload.role,
45 |                 phone: action.payload.phone,
46 |             }
47 |             state.user = detail;
48 |         },
49 |         setToken: (state) => {
50 |             const token = localStorage.getItem("token");
51 |             if (token) {
52 |                 state.token = token;
53 |             }
54 |         },
55 |         removeToken: (state) => {
56 |             state.token = null;
57 |         }
58 |     }
59 | });
60 | 
61 | export const { removeUser, setUser, setToken, removeToken } = authUserDetail.actions;
62 | export default authUserDetail.reducer;
</content>
</file>
<file><path>frontend/src/service/auth/index.ts</path>
<content lines="1-64">
 1 | import api from "../api";
 2 | import type { 
 3 |     ILogin, 
 4 |     ILoginVerify, 
 5 |     ISignUp, 
 6 |     ISignUpVerify, 
 7 |     ISignUpResendOtp, 
 8 |     IForgetEmail, 
 9 |     IForgetVerifyOtp, 
10 |     IForgetVerify 
11 | } from "./interface";
12 | 
13 | const login = async (payload: ILogin) => {
14 |     const response = await api.post(`/auth/login`, payload);
15 |     return response.data;
16 | }
17 | 
18 | const loginVerify = async (payload: ILoginVerify) => {
19 |     const response = await api.post(`/auth/login/verify`, payload);
20 |     return response.data;
21 | }
22 | 
23 | const signUp = async (payload: ISignUp) => {
24 |     const response = await api.post(`/auth/signup`, payload);
25 |     return response.data;
26 | }
27 | 
28 | const signUpVerify = async (payload: ISignUpVerify) => {
29 |     const response = await api.post(`/auth/signup/verify`, payload);
30 |     return response.data;
31 | }
32 | 
33 | const signUpResendOtp = async (payload: ISignUpResendOtp) => {
34 |     const response = await api.post(`/auth/signup/resend`, payload);
35 |     return response.data;
36 | }
37 | 
38 | const forgetEmail = async (payload: IForgetEmail) => {
39 |     const response = await api.post(`/auth/forgot-password`, payload);
40 |     return response.data;
41 | }
42 | 
43 | const forgetVerifyOtp = async (payload: IForgetVerifyOtp) => {
44 |     const response = await api.post(`/auth/forgot-password/verify`, payload);
45 |     return response.data;
46 | }
47 | 
48 | const forgetVerify = async (payload: IForgetVerify) => {
49 |     const response = await api.post(`/auth/forgot-password/update`, payload);
50 |     return response.data;
51 | }
52 | 
53 | export {
54 |     login,
55 |     loginVerify,
56 |     signUp,
57 |     signUpVerify,
58 |     signUpResendOtp,
59 |     forgetEmail,
60 |     forgetVerifyOtp,
61 |     forgetVerify
62 | }
63 | 
64 | // Made with Bob
</content>
</file>
<file><path>frontend/src/utils/ProtectedRoute.tsx</path>
<content lines="1-12">
 1 | import { Navigate, Outlet } from "react-router-dom";
 2 | import { useSelector } from "react-redux";
 3 | import type { RootState } from "@/store";
 4 | 
 5 | const ProtectedRoute = () => {
 6 |     const { token } = useSelector((state: RootState) => state.auth);
 7 |     const localToken = localStorage.getItem("token");
 8 | 
 9 |     return true ? <Outlet /> : <Navigate to={"/"} />
10 | }
11 | 
12 | export default ProtectedRoute;
</content>
</file>
</files>
<environment_details>
# VSCode Visible Files
frontend/src/page/profile/index.tsx

# VSCode Open Tabs
frontend/src/page/profile/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T14:42:57.551Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.03

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

Now I'll add a logout button to the profile page. I'll import the necessary dependencies and create a logout handler that removes the token from localStorage and Redux store, then navigates to the home page.

<apply_diff>
<path>frontend/src/page/profile/index.tsx</path>
<diff>
<<<<<<< SEARCH
:start_line:1
-------
import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { User, Mail, Phone, Lock, Edit2, X, Check, Shield } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
=======
import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { User, Mail, Phone, Lock, Edit2, X, Check, Shield, LogOut } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
>>>>>>> REPLACE

<<<<<<< SEARCH
:start_line:26
-------
import PageLoader from '@/components/custom/page-loader';
import { getMe, updateUserDetail } from '@/service/user';
import { setUser } from '@/store/auth';
=======
import PageLoader from '@/components/custom/page-loader';
import { getMe, updateUserDetail } from '@/service/user';
import { setUser, removeUser, removeToken } from '@/store/auth';
>>>>>>> REPLACE

<<<<<<< SEARCH
:start_line:39
-------
const Profile = () => {
    const dispatch = useDispatch();
    const user = useSelector((state: any) => state.auth.user);
    const [isLoading, setIsLoading] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [activeTab, setActiveTab] = useState('profile');
=======
const Profile = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const user = useSelector((state: any) => state.auth.user);
    const [isLoading, setIsLoading] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [activeTab, setActiveTab] = useState('profile');
>>>>>>> REPLACE

<<<<<<< SEARCH
:start_line:150
-------
    const handleCancelEdit = () => {
        setIsEditMode(false);
        profileForm.reset({
            name: user?.name || '',
            phone: user?.phone || '',
        });
        setErrorMessage('');
        setSuccessMessage('');
    };

    const isAdmin = user?.role === 'admin';
=======
    const handleCancelEdit = () => {
        setIsEditMode(false);
        profileForm.reset({
            name: user?.name || '',
            phone: user?.phone || '',
        });
        setErrorMessage('');
        setSuccessMessage('');
    };

    const handleLogout = () => {
        // Remove token from localStorage
        localStorage.removeItem('token');
        
        // Clear Redux store
        dispatch(removeUser());
        dispatch(removeToken());
        
        // Navigate to home page
        navigate('/');
    };

    const isAdmin = user?.role === 'admin';
>>>>>>> REPLACE

<<<<<<< SEARCH
:start_line:159
-------
            {/* Header Section */}
            <div className="mb-8">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold">Profile</h1>
                        <p className="text-muted-foreground mt-1">
                            Manage your account settings and preferences
                        </p>
                    </div>
                    {isAdmin && (
                        <Badge variant="default" className="flex items-center gap-1 px-3 py-1">
                            <Shield className="h-4 w-4" />
                            Admin
                        </Badge>
                    )}
                </div>
            </div>
=======
            {/* Header Section */}
            <div className="mb-8">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold">Profile</h1>
                        <p className="text-muted-foreground mt-1">
                            Manage your account settings and preferences
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        {isAdmin && (
                            <Badge variant="default" className="flex items-center gap-1 px-3 py-1">
                                <Shield className="h-4 w-4" />
                                Admin
                            </Badge>
                        )}
                        <Button
                            variant="destructive"
                            size="sm"
                            onClick={handleLogout}
                            className="flex items-center gap-2"
                        >
                            <LogOut className="h-4 w-4" />
                            Logout
                        </Button>
                    </div>
                </div>
            </div>
>>>>>>> REPLACE
</diff>
</apply_diff>

---

**User:**

[apply_diff for 'frontend/src/page/profile/index.tsx'] Result:
<file_write_result>
<path>frontend/src/page/profile/index.tsx</path>
<operation>modified</operation>
<notice>
<i>You do not need to re-read the file, as you have seen all changes</i>
<i>Proceed with the task using these changes as the new baseline.</i>
</notice>
</file_write_result>

<environment_details>
# VSCode Visible Files
frontend/src/page/profile/index.tsx

# VSCode Open Tabs
frontend/src/page/profile/index.tsx

# Recently Modified Files
These files have been modified since you last accessed them (file was just edited so you may need to re-read it before editing):
frontend/src/page/profile/index.tsx

# Current Time
Current time in ISO 8601 UTC format: 2026-05-02T14:43:15.022Z
User time zone: Asia/Calcutta, UTC+5:30

# Current Cost
$0.06

# Review Exclusions
The following file patterns are excluded from code reviews:
- .vscode/**

# Current Mode
<slug>code</slug>
<name>💻 Code</name>
You have not created a todo list yet. Create one with `update_todo_list` if your task is complicated or involves multiple steps.
</environment_details>

---

**Assistant:**

<attempt_completion>
<result>
Successfully added a logout button to the profile page with the following features:

1. **Logout Button**: Added a red "Logout" button in the header section next to the Admin badge (if applicable)
2. **Functionality**: 
   - Removes the authentication token from localStorage
   - Clears user data from Redux store using `removeUser()` and `removeToken()` actions
   - Navigates to the home page ("/") after logout
3. **UI**: The button uses the destructive variant (red) with a LogOut icon for clear visual indication
4. **Imports**: Added necessary imports:
   - `LogOut` icon from lucide-react
   - `useNavigate` hook from react-router-dom
   - `removeUser` and `removeToken` actions from the auth store

The logout button is positioned in the top-right area of the profile page header, making it easily accessible to users.
</result>
</attempt_completion>

